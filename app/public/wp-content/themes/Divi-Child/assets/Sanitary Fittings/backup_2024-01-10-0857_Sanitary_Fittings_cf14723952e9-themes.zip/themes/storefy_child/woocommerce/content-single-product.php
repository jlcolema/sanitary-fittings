<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.0.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<?php
	/**
	 * woocommerce_before_single_product hook.
	 *
	 * @hooked wc_print_notices - 10
	 */
	 do_action( 'woocommerce_before_single_product' );

	 if ( post_password_required() ) {
	 	echo get_the_password_form();
	 	return;
	 }
?>
<div class="container">
<div itemscope itemtype="<?php echo woocommerce_get_product_schema(); ?>" id="product-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="product-container">
		<div class="row">
			<div class="col-sm-6 col-xs-12">
				<div class="product-image-container">
				<?php
					do_action('storefy_woocommerce_template_single_product_image');
				?>
				</div>
			</div>
			<div class="col-sm-6 col-xs-12">
				<div class="summary entry-summary">
				<?php
					do_action( 'storefy_woocommerce_single_product_summary');
				?>
				</div><!-- .summary -->
			</div>
		</div><!-- .product-container -->
	</div>
	<div class="row">
		<div class="divider"></div>
	</div>
	<div class="product-content-container">
		<h3 class="accordian-title on"><?php echo __('Description'); ?><span class="icon-arrow-down"></span></h3>
		<div class="content accordian-content on"><?php echo do_shortcode(get_the_content()); ?></div>
	</div>
<?php 

ob_start();

do_action( 'storefy_woocommerce_after_single_product_summary_sidebar' );
$summary_sidebar=ob_get_clean();

?>
	<div class="row">
	    
		<?php if(!empty($summary_sidebar)):?>
		<div class="col-sm-6 col-xs-12" style="width:100%;">
		<?php else:?>
		<div class="col-lg-12 col-xs-12">
		<?php endif;?>
			<div class="product-summary-main">
			<?php
			do_action( 'storefy_woocommerce_after_single_product_summary');
			?>
			</div>
		</div>
		<?php if(!empty($summary_sidebar)):?>
		<div class="col-sm-6 col-xs-12">
			<div class="product-summary-sidebar" style="padding-left:0px;">
			<?php
			print $summary_sidebar;
			?>
			</div>
		</div>
		<?php endif;?>
	</div>

	<meta itemprop="url" content="<?php the_permalink(); ?>" />

</div><!-- #product-<?php the_ID(); ?> -->
</div>
<?php do_action( 'woocommerce_after_single_product' ); ?>
<div class="woocommerce-related-products">
	<div class="container">
	<?php
	global $product;

	if( ! is_a( $product, 'WC_Product' ) ){
	    $product = wc_get_product(get_the_id());
	}

	woocommerce_related_products( array(
	    'posts_per_page' => 4,
	    'columns'        => 4,
	    'orderby'        => 'rand'
	) );
	?>
	</div>
</div>
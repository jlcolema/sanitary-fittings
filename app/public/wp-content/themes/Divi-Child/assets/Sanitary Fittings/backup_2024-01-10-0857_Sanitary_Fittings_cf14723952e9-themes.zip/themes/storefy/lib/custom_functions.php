<?php
defined('ABSPATH') or die();
/**
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */

function storefy_sanitize_html_class($classes=""){

  if(!empty($classes)){

    $classes_array=@explode(" ",$classes);
    $newclasses=array_filter($classes_array, "sanitize_html_class");
    return join(" ",$newclasses);
  }
  return $classes;
}

function storefy_plugin_is_active( $plugin ) {
  return in_array( $plugin, (array) get_option( 'active_plugins', array() ) ) || storefy_plugin_is_active_for_network( $plugin );
}

function storefy_plugin_is_active_for_network( $plugin ) {
  if ( !is_multisite() )
    return false;

  $plugins = get_site_option( 'active_sitewide_plugins');
  if ( isset($plugins[$plugin]) )
    return true;

  return false;
}

function storefy_get_sidebar_position(){

 
  if(function_exists('is_shop') && ( is_shop() || is_product_category() )){

     $post_id=get_option( 'woocommerce_shop_page_id');
  }
  elseif(is_home()){
      $post_id=get_option( 'page_for_posts');
  }
  elseif (is_page()){
      $post_id= get_the_ID();
  }


  $sidebar_position = isset($post_id) ?get_post_meta( $post_id, '_sidebar_position', true ):'default';


  if(!isset($sidebar_position) || empty($sidebar_position) || $sidebar_position=='default'){

    switch (get_storefy_option('layout')) {
      case 1:
        $sidebar_position = "nosidebar";
        break;
      case 2:
        $sidebar_position = "sidebar-left";
        break;
      case 3:
        $sidebar_position = "sidebar-right";
        break;
      case 4:
        $sidebar_position = "fullwidth";
        break;
      default:
        $sidebar_position = "sidebar-left";
    }


  }

  return $sidebar_position;
}


add_filter('nav_menu_link_attributes','storefy_formatMenuAttibute',2,2);

function storefy_page_attibutes_metabox($posttypes){

  return array('page'=>$posttypes['page'],'essential_grid'=>esc_html__('Page Atribute','storefy'),'post'=>esc_html__('Page Attribute','storefy'),'dtpost'=>esc_html__('Page Attribute','storefy'));
}

add_filter('detheme_page_metaboxes','storefy_page_attibutes_metabox');

function storefy_page_metaboxes_title_show($titles){

  return array('page','essential_grid','post','dtpost');
}

function storefy_page_metaboxes_banner_show($titles){

  return array('page','essential_grid','post','dtpost');

}

add_filter('detheme_page_metaboxes_title','storefy_page_metaboxes_title_show');
add_filter('detheme_page_metaboxes_banner','storefy_page_metaboxes_banner_show');

function storefy_formatMenuAttibute($atts, $item){

  global $dropdownmenu;

  if(in_array('dropdown', $item->classes)){
    $atts['class']="dropdown-toggle";
    $atts['data-toggle']="dropdown";
    $dropdownmenu=$item;
  }
  return $atts;
}

function storefy_createFontelloIconMenu($css,$item,$args=array()){

  $css=@implode(" ",$css);
  $args->link_before="";
  $args->link_after="";
  
  if(preg_match('/([-_a-z-0-9]{0,})icon([-_a-z-0-9]{0,})/', $css, $matches)){
  
    $css=preg_replace('/'.$matches[0].'/', "", $css);
    $item->title="<i class=\"".$matches[0]."\"></i>";
  }
  return @explode(" ",$css);
}


function storefy_createFontelloMenu($css,$item,$args=array()){

  $css=@implode(" ",$css);
  $args->link_before="";
  $args->link_after="";
  
  if(preg_match('/([-_a-z-0-9]{0,})icon([-_a-z-0-9]{0,})/', $css, $matches)){
  
    $css=preg_replace('/'.$matches[0].'/', "", $css);
    $args->link_before.="<i class=\"".$matches[0]."\"></i>";
  }

  $args->link_before.="<span>";
  $args->link_after="</span>";

  return @explode(" ",$css);
}

add_filter( 'nav_menu_css_class', 'storefy_createFontelloMenu', 10, 3 );
add_filter( 'storefy_nav_menu_icon_css_class', 'storefy_createFontelloIconMenu', 10, 3 );


class storefy_iconmenu_walker extends Walker_Nav_Menu {
  function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
    $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

    $class_names = $value = '';

    $classes = empty( $item->classes ) ? array() : (array) $item->classes;
    $classes[] = 'menu-item-' . $item->ID;

    /**
     * Filter the CSS class(es) applied to a menu item's <li>.
     *
     * @since 3.0.0
     *
     * @param array  $classes The CSS classes that are applied to the menu item's <li>.
     * @param object $item    The current menu item.
     * @param array  $args    An array of arguments. @see wp_nav_menu()
     */
    $class_names = join( ' ', apply_filters('storefy_nav_menu_icon_css_class',array_filter( $classes ), $item, $args));
    $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';


    /**
     * Filter the ID applied to a menu item's <li>.
     *
     * @since 3.0.1
     *
     * @param string The ID that is applied to the menu item's <li>.
     * @param object $item The current menu item.
     * @param array $args An array of arguments. @see wp_nav_menu()
     */
    $id = apply_filters( 'nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args );
    $id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

    $output .= $indent . '<li' . $id . $value . $class_names .'>';

    $atts = array();
    $atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
    $atts['target'] = ! empty( $item->target )     ? $item->target     : '';
    $atts['rel']    = ! empty( $item->xfn )        ? $item->xfn        : '';
    $atts['href']   = ! empty( $item->url )        ? $item->url        : '';

    /**
     * Filter the HTML attributes applied to a menu item's <a>.
     *
     * @since 3.6.0
     *
     * @param array $atts {
     *     The HTML attributes applied to the menu item's <a>, empty strings are ignored.
     *
     *     @type string $title  The title attribute.
     *     @type string $target The target attribute.
     *     @type string $rel    The rel attribute.
     *     @type string $href   The href attribute.
     * }
     * @param object $item The current menu item.
     * @param array  $args An array of arguments. @see wp_nav_menu()
     */
    $atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args );

    $attributes = '';
    foreach ( $atts as $attr => $value ) {
      if ( ! empty( $value ) ) {
        $value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
        $attributes .= ' ' . $attr . '="' . $value . '"';
      }
    }

    $item_output = $args->before;
    $item_output .= '<a'. $attributes .'>';
    $item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
    $item_output .= '</a>';
    $item_output .= $args->after;

    /**
     * Filter a menu item's starting output.
     *
     * The menu item's starting output only includes $args->before, the opening <a>,
     * the menu item's title, the closing </a>, and $args->after. Currently, there is
     * no filter for modifying the opening and closing <li> for a menu item.
     *
     * @since 3.0.0
     *
     * @param string $item_output The menu item's starting HTML output.
     * @param object $item        Menu item data object.
     * @param int    $depth       Depth of menu item. Used for padding.
     * @param array  $args        An array of arguments. @see wp_nav_menu()
     */
    $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
  }    
}



function storefy_add_class_to_first_submenu($items) {
  $menuhaschild = array();

  foreach($items as $key => $item) {

    if (in_array('menu-item-has-children',$item->classes)) {
      $menuhaschild[] = $item->ID;
    }

  }

  foreach($menuhaschild as $key => $parent_id) {
    foreach($items as $key => $item) {
      if ($item->menu_item_parent==$parent_id) {
        $item->classes[] = 'menu-item-first-child';
        break;
      }
    }
  }


  return $items;
}

add_filter('wp_nav_menu_objects', 'storefy_add_class_to_first_submenu');

function storefy_tag_cloud_args($args=array()){
  $args['filter']=1;
  return $args;

}

function storefy_tag_cloud($return="",$tags, $args = '' ){

  if(!count($tags))
    return $return;
  $return='<ul class="list-unstyled">';
  foreach ($tags as $tag) {
    $return.='<li class="tag"><a href="'.esc_url($tag->link).'">'.ucwords($tag->name).'</a></li>';
  }
  $return.='</ul>';
  return $return;
}

function storefy_widget_title($title="",$instance=array(),$id=null){

  if(empty($instance['title']))
      return "";
  return $title;
}

add_filter('widget_tag_cloud_args','storefy_tag_cloud_args');
add_filter('wp_generate_tag_cloud','storefy_tag_cloud',1,3);
add_filter('widget_title','storefy_widget_title',1,3);

function storefy_get_avatar_url($get_avatar){
    preg_match("/src='(.*?)'/i", $get_avatar, $matches);
    if (isset($matches[1])) {
      return $matches[1];
    } else {
      return;
    }
}


// Comment Functions
function storefy_comment_form( $args = array(), $post_id = null ) {
  if ( null === $post_id )
    $post_id = get_the_ID();
  else
    $id = $post_id;

  $commenter = wp_get_current_commenter();
  $user = wp_get_current_user();
  $user_identity = $user->exists() ? $user->display_name : '';

  $args = wp_parse_args( $args );
  if ( ! isset( $args['format'] ) )
    $args['format'] = current_theme_supports( 'html5', 'comment-form' ) ? 'html5' : 'xhtml';

  $req      = get_option( 'require_name_email' );
  $aria_req = ( $req ? " aria-required='true'" : '' );
  $html5    = 'html5' === $args['format'];
  
  $fields   =  array(
    'author' => '<div class="row">
                    <div class="form-group col-xs-12 col-sm-4">
                      <input type="text" class="form-control" name="author" id="author" placeholder="'.esc_attr__('full name','storefy').'" required>
                  </div>',
    'email' => '<div class="form-group col-xs-12 col-sm-4">
                      <input type="email" class="form-control"  name="email" id="email" placeholder="'.esc_attr__('email address','storefy').'" required>
                  </div>',
    'url' => '<div class="form-group col-xs-12 col-sm-4">
                  <input type="text" class="form-control icon-user-7" name="url" id="url" placeholder="'.esc_attr__('website','storefy').'">
                </div>
              </div>',
  );

  $required_text = sprintf( ' ' . esc_html__('Required fields are marked %s','storefy'), '<span class="required">*</span>' );
  $defaults = array(
    'fields'               => apply_filters( 'comment_form_default_fields', $fields ),
    'comment_field'        => '<div class="row">
                                  <div class="form-group col-xs-12">
                                    <textarea class="form-control" rows="3" name="comment" id="comment" placeholder="'.esc_html__('your message','storefy').'" required></textarea>
                                  </div>
                              </div>',
    'must_log_in'          => '<p class="must-log-in">' . sprintf( __( 'You must be <a href="%s">logged in</a> to post a comment.','storefy'), wp_login_url( apply_filters( 'the_permalink', get_permalink( $post_id ) ) ) ) . '</p>',
    'logged_in_as'         => '<p class="logged-in-as">' . sprintf( __( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>','storefy'), get_edit_user_link(), $user_identity, wp_logout_url( apply_filters( 'the_permalink', get_permalink( $post_id ) ) ) ) . '</p>',
    'comment_notes_before' => '<p class="comment-notes">' . esc_html__( 'Your email address will not be published.','storefy') . ( $req ? $required_text : '' ) . '</p>',
    'comment_notes_after'  => '',
    'id_form'              => 'commentform',
    'id_submit'            => 'submit',
    'title_reply'          => esc_html__('Leave a Comment','storefy'),
    'title_reply_to'       => esc_html__( 'Leave a Comment to %s','storefy'),
    'cancel_reply_link'    => esc_html__( 'Cancel reply','storefy'),
    'label_submit'         => esc_html__( 'Submit','storefy' ),
    'format'               => 'html5',
  );

  $args = wp_parse_args( $args, apply_filters( 'comment_form_defaults', $defaults ) );

  ?>
    <?php if ( comments_open( $post_id ) ) : ?>
      <?php do_action( 'comment_form_before' ); ?>
      <section id="respond" class="comment-respond">
        <h3 id="reply-title" class="comment-reply-title"><?php comment_form_title( $args['title_reply'], $args['title_reply_to'] ); ?> <small><?php cancel_comment_reply_link( $args['cancel_reply_link'] ); ?></small></h3>
        <?php if ( get_option( 'comment_registration' ) && !is_user_logged_in() ) : ?>
          <?php echo $args['must_log_in']; ?>
          <?php do_action( 'comment_form_must_log_in_after' ); ?>
        <?php else : ?>
          <form action="<?php echo site_url( '/wp-comments-post.php' ); ?>" method="post" id="<?php echo esc_attr( $args['id_form'] ); ?>" class="comment-form"<?php echo ($html5) ? ' novalidate' : ''; ?> data-abide>
            <?php do_action( 'comment_form_top' ); ?>
            <?php 
              if ( is_user_logged_in() ) :
                echo apply_filters( 'comment_form_logged_in', $args['logged_in_as'], $commenter, $user_identity );
                do_action( 'comment_form_logged_in_after', $commenter, $user_identity );
                echo $args['comment_notes_before'];
              else : 
                do_action( 'comment_form_before_fields' );
                foreach ( (array) $args['fields'] as $name => $field ) {
                  echo apply_filters( "comment_form_field_{$name}", $field ) . "\n";
                }
                do_action( 'comment_form_after_fields' );
              endif; 
            ?>
            <?php echo apply_filters( 'comment_form_field_comment', $args['comment_field'] ); ?>
            <?php echo $args['comment_notes_after']; ?>
            <p class="form-submit">
              <input name="submit" type="submit" id="<?php echo esc_attr( $args['id_submit'] ); ?>" value="<?php echo esc_attr( $args['label_submit'] ); ?>" class="round-dark" />
              <?php comment_id_fields( $post_id ); ?>
            </p>
            <?php do_action( 'comment_form', $post_id ); ?>
          </form>
        <?php endif; ?>
      </section><!-- #respond -->
      <?php do_action( 'comment_form_after' ); ?>
    <?php else : ?>
      <?php do_action( 'comment_form_comments_closed' ); ?>
    <?php endif; ?>
  <?php
}

/**
 * Retrieve HTML content for reply to comment link.
 *
 * The default arguments that can be override are 'add_below', 'respond_id',
 * 'reply_text', 'login_text', and 'depth'. The 'login_text' argument will be
 * used, if the user must log in or register first before posting a comment. The
 * 'reply_text' will be used, if they can post a reply. The 'add_below' and
 * 'respond_id' arguments are for the JavaScript moveAddCommentForm() function
 * parameters.
 *
 * @since 2.7.0
 *
 * @param array $args Optional. Override default options.
 * @param int $comment Optional. Comment being replied to.
 * @param int $post Optional. Post that the comment is going to be displayed on.
 * @return string|bool|null Link to show comment form, if successful. False, if comments are closed.
 */
function storefy_get_comment_reply_link($args = array(), $comment = null, $post = null) {
  global $user_ID;

  $defaults = array('add_below' => 'comment', 'respond_id' => 'respond', 'reply_text' => esc_html__('Reply','storefy'),
    'login_text' => esc_html__('Log in to Reply','storefy'), 'depth' => 0, 'before' => '', 'after' => '');

  $args = wp_parse_args($args, $defaults);

  if ( 0 == $args['depth'] || $args['max_depth'] <= $args['depth'] )
    return;

  extract($args, EXTR_SKIP);

  $comment = get_comment($comment);
  if ( empty($post) )
    $post = $comment->comment_post_ID;
  $post = get_post($post);

  if ( !comments_open($post->ID) )
    return false;

  $link = '';

  if ( get_option('comment_registration') && !$user_ID )
    $link = '<a rel="nofollow" class="comment-reply-login" href="' . esc_url( wp_login_url( get_permalink() ) ) . '">' . $login_text . '</a>';
  else 
    $link = "<a class='reply comment-reply-link' href='#' onclick='return addComment.moveForm(\"$add_below-$comment->comment_ID\", \"$comment->comment_ID\", \"$respond_id\", \"$post->ID\")'>$reply_text</a>";
  
  return apply_filters('comment_reply_link', $before . $link . $after, $args, $comment, $post);
}

/**
 * Displays the HTML content for reply to comment link.
 *
 * @since 2.7.0
 * @see storefy_get_comment_reply_link() Echoes result
 *
 * @param array $args Optional. Override default options.
 * @param int $comment Optional. Comment being replied to.
 * @param int $post Optional. Post that the comment is going to be displayed on.
 * @return string|bool|null Link to show comment form, if successful. False, if comments are closed.
 */
function storefy_comment_reply_link($args = array(), $comment = null, $post = null) {
  echo storefy_get_comment_reply_link($args, $comment, $post);
}

if ( ! function_exists( 'storefy_edit_comment_link' ) ) :
  function storefy_edit_comment_link( $link = null, $before = '', $after = '' ) {
    global $comment;

    if ( !current_user_can( 'edit_comment', $comment->comment_ID ) )
      return;

    if ( null === $link )
      $link = esc_html__('Edit This','storefy');

    $link = '<a class="comment-edit-link primary_color_button btn btn-ghost skin-dark" href="' . esc_url(get_edit_comment_link( $comment->comment_ID )) . '">' . $link . '</a>';
    echo $before . apply_filters( 'edit_comment_link', $link, $comment->comment_ID ) . $after;
  }
endif; 

if( ! function_exists( 'storefy_comment_end_callback' )){

  function storefy_comment_end_callback( $comment, $args, $depth){
    ?>
</li>
<?php 
  }

}
if ( ! function_exists( 'storefy_comment' ) ) :
function storefy_comment( $comment, $args, $depth ) {

  $GLOBALS['comment'] = $comment;
  switch ( $comment->comment_type ) :
    case 'pingback' :
    case 'trackback' :
      // Display trackbacks differently than normal comments.
      ?>
      <li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
      <p><?php esc_html_e( 'Pingback:', 'storefy' ); ?> <?php comment_author_link(); ?> <?php edit_comment_link( esc_html__( '(Edit)', 'storefy' ), '<span class="edit-link">', '</span>' ); ?></p>
      </li>
      <?php
    break;
  
    default :
      // Proceed with normal comments.

      ?>
              <li class="comment_item media" id="comment-<?php print $comment->comment_ID; ?>">
                <div class="pull-<?php print is_rtl()?"right":"left";?> text-center">
                  <?php $avatar_url = storefy_get_avatar_url(get_avatar( $comment, 100 )); ?>
                  <a href="<?php echo esc_url(comment_author_url()); ?>"><img src="<?php echo esc_url($avatar_url); ?>" class="author-avatar img-responsive img-circle" alt="<?php comment_author(); ?>" /></a>
                </div>
                <div class="media-body">

                  <div class="dt-meta-comments text-<?php print is_rtl()?"right":"left";?>">
                    <span class="dt-comment-author">By <?php comment_author(); ?></span> /
                    <span class="dt-comment-date"><?php comment_date('d.m.Y') ?></span> /
                    <span class="dt-comment-buttons"><?php storefy_comment_reply_link( array_merge( $args, array( 'reply_text' => esc_html__( 'Reply', 'storefy' ), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
                      <?php storefy_edit_comment_link( esc_html__( 'Edit', 'storefy' ), '', '' ); ?></span> 
                  </div>
                  <div class="col-xs-12 dt-comment-comment"><?php comment_text(); ?></div>
                  
                </div>
      <?php
    break;
  endswitch; // end comment_type check
}
endif; 

// function to display number of posts.
function storefy_get_post_views($postID){

    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return sprintf(esc_html__("%d View",'storefy'),0);
    } elseif ($count<=1) {
        return sprintf(esc_html__("%d View",'storefy'),$count);  
    }


    $output = str_replace('%', number_format_i18n($count),esc_html__('% Views','storefy'));
    return $output;
}

// function to count views.
function storefy_set_post_views($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}

function storefy_post_view_column(){

  $post_types = get_post_types( array(),'names' );

      foreach ( $post_types as $post_type ) {
        if ( in_array($post_type,array('page','attachment','wpcf7_contact_form','vc_grid_item','nav_menu_item','revision')))
            continue;

          add_filter('manage_'.$post_type.'_posts_columns', 'storefy_posts_column_views');
          add_action('manage_'.$post_type.'_posts_custom_column', 'storefy_posts_custom_column_views',5,2);
    }
}

add_action('admin_init','storefy_post_view_column');

function storefy_posts_column_views($defaults){
    $defaults['post_views'] = esc_html__('Views','storefy');
    return $defaults;
}

function storefy_posts_custom_column_views($column_name, $id){

  if($column_name === 'post_views'){
        echo storefy_get_post_views(get_the_ID());
    }
}

if(!function_exists('storefy_is_ssl_mode')){
function storefy_is_ssl_mode(){
  $ssl=strpos("a".site_url(),'https://');

  return (bool)$ssl;
}}

function storefy_maybe_ssl_url($url=""){
  return storefy_is_ssl_mode()?str_replace('http://', 'https://', $url):$url;
}

if (!function_exists('storefy_aq_resize')) {
  function storefy_aq_resize( $url, $width, $height = null, $crop = null, $single = true ) {

    if(!$url OR !($width || $height)) return false;

    //define upload path & dir
    $upload_info = wp_upload_dir();
    $upload_dir = $upload_info['basedir'];
    $upload_url = $upload_info['baseurl'];
    
    //define path of image
    $rel_path = str_replace( str_replace( array( 'http://', 'https://' ),"",$upload_url), '', str_replace( array( 'http://', 'https://' ),"",$url));
    $img_path = $upload_dir . $rel_path;
    
    //check if img path exists, and is an image indeed
    if( !file_exists($img_path) OR !getimagesize($img_path) ) return false;
    
    //get image info
    $info = pathinfo($img_path);
    $ext = $info['extension'];
    list($orig_w,$orig_h) = getimagesize($img_path);
    
    $dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
    if(!$dims){
      return $single?$url:array('0'=>$url,'1'=>$orig_w,'2'=>$orig_h);
    }

    $dst_w = $dims[4];
    $dst_h = $dims[5];

    //use this to check if cropped image already exists, so we can return that instead
    $suffix = "{$dst_w}x{$dst_h}";
    $dst_rel_path = str_replace( '.'.$ext, '', $rel_path);
    $destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

    //if orig size is smaller
    if($width >= $orig_w) {

      if(!$dst_h) :
        //can't resize, so return original url
        $img_url = $url;
        $dst_w = $orig_w;
        $dst_h = $orig_h;
        
      else :
        //else check if cache exists
        if(file_exists($destfilename) && getimagesize($destfilename)) {
          $img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
        } 
        else {

          $imageEditor=wp_get_image_editor( $img_path );

          if(!is_wp_error($imageEditor)){

              $imageEditor->resize($width, $height, $crop );
              $imageEditor->save($destfilename);

              $resized_rel_path = str_replace( $upload_dir, '', $destfilename);
              $img_url = $upload_url . $resized_rel_path;


          }
          else{
              $img_url = $url;
              $dst_w = $orig_w;
              $dst_h = $orig_h;
          }

        }
        
      endif;
      
    }
    //else check if cache exists
    elseif(file_exists($destfilename) && getimagesize($destfilename)) {
      $img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
    } 
    else {

      $imageEditor=wp_get_image_editor( $img_path );

      if(!is_wp_error($imageEditor)){
          $imageEditor->resize($width, $height, $crop );
          $imageEditor->save($destfilename);

          $resized_rel_path = str_replace( $upload_dir, '', $destfilename);
          $img_url = $upload_url . $resized_rel_path;
      }
      else{
          $img_url = $url;
          $dst_w = $orig_w;
          $dst_h = $orig_h;
      }


    }
    
    if(!$single) {
      $image = array (
        '0' => $img_url,
        '1' => $dst_w,
        '2' => $dst_h
      );
      
    } else {
      $image = $img_url;
    }
    
    return $image;
  }
}


function storefy_responsiveVideo($html, $url,$attr=array(),$post_ID=0) {

  $html=storefy_add_video_wmode_transparent($html);

  if (!is_admin() && !preg_match("/flex\-video/mi", $html) ) {
    $html = str_replace('frameborder="0"',' ',$html);
    $html="<div class=\"flex-video widescreen\">".$html."</div>";
  }
  return $html;
}

add_filter('embed_handler_html', 'storefy_responsiveVideo', 92, 3 ); 
add_filter('oembed_dataparse', 'storefy_responsiveVideo', 90, 3 );
add_filter('embed_oembed_html', 'storefy_responsiveVideo', 91, 4 );

function storefy_add_video_wmode_transparent($html) {
   if (strpos($html, "<iframe " ) !== false) {
      $search = array('?feature=oembed');
      $replace = array('?feature=oembed&amp;wmode=transparent&amp;rel=0&amp;autohide=1&amp;showinfo=0');
      $html = str_replace($search, $replace, $html);
      $html = preg_replace('/frameborder/si','style="border:none;" data-border',$html);
      return $html;
   } else {
      return $html;
   }
}

function storefy_makeBottomWidgetColumn($params){

  if('sidebar-bottom'==$params[0]['id']){

    $class="col-sm-4";

    if($col=(int)get_storefy_option('dt-footer-widget-column')){

      switch($col){

          case 2:
                $class='col-md-6 col-sm-6 col-xs-6';
            break;
          case 3:
                $class='col-md-4 col-sm-6 col-xs-6';
            break;
          case 4:
                $class='col-lg-3 col-md-4 col-sm-6 col-xs-6';
            break;
          case 1:
          default:
                $class='col-sm-12';
            break;
      }
    }


    $makerow="";

    $params[0]['before_widget']='<div class="border-left '.$class.' col-'.$col.'">'.$params[0]['before_widget'];
    $params[0]['after_widget']=$params[0]['after_widget'].'</div>'.$makerow;

 }

  return $params;

}

function storefy_protected_meta($protected, $meta_key, $meta_type){

 $protected=(in_array($meta_key,
    array('vc_teaser','slide_template','pagebuilder','masonrycolumn','portfoliocolumn','portfoliotype','post_views_count','show_comment','show_social','sidebar_position','subtitle')
  ))?true:$protected;

  return $protected;
}

add_filter('is_protected_meta','storefy_protected_meta',1,3);
add_filter( 'dynamic_sidebar_params', 'storefy_makeBottomWidgetColumn' );

function storefy_fill_width_dummy_widget (){

   $col=1;
   if(get_storefy_option('dt-footer-widget-column')) {
      $col=(int)get_storefy_option('dt-footer-widget-column');
   }


   $sidebar = wp_get_sidebars_widgets();


   $itemCount=(isset($sidebar['sidebar-bottom']))?count($sidebar['sidebar-bottom']):0;

   switch($col){

          case 2:
                $class='col-md-6 col-sm-6 col-xs-6';
            break;
          case 3:
                $class='col-md-4 col-sm-6 col-xs-6';
            break;
          case 4:
                $class='col-lg-3 col-md-4 col-sm-6 col-xs-6';
            break;
          case 1:
          default:
                $class='col-sm-12';
            break;
  }


  if($itemCount % $col){
   print str_repeat("<div class=\"border-left dummy ".$class."\"></div>",$col - ($itemCount % $col));
 }
}

add_action('dynamic_sidebar_sidebar-bottom','storefy_fill_width_dummy_widget');

function storefy_remove_shortcode_from_content($content) {
  // remove shortcodes
  $content = strip_shortcodes( $content );

  // remove images
  $content = preg_replace('/<img[^>]+./','', $content);
  
  return $content;
}

function storefy_get_first_image_url_from_content() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  if (isset($post->post_content)) {
    $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
    if (isset($matches[1][0])) {
      $first_img = $matches[1][0];
    }
  }

  return $first_img;
}

/* vc_set_as_theme */

if(function_exists('vc_set_as_theme'))
{

    function storefy_vc_add_element_param( $name, $form_field_callback, $script_url = null ) {
      return WpbakeryShortcodeParams::addField( $name, $form_field_callback, $script_url );
    }

    function storefy_add_element_param( $name, $form_field_callback, $script_url = null ) {
      return storefy_vc_add_element_param( $name, $form_field_callback, $script_url );
    }


  if(version_compare(WPB_VC_VERSION,'4.9.0','<')):

        function storefy_vc_settings_general_callback(){


        $pt_array = ( $pt_array = get_option( 'wpb_js_content_types' ) ) ? ( $pt_array ) : vc_default_editor_post_types();

        $excludePostype=apply_filters( 'vc_settings_exclude_post_type',array( 'attachment', 'revision', 'nav_menu_item', 'mediapage' ));

        foreach ( get_post_types( array( 'public' => true )) as $pt) {
          if ( ! in_array( $pt, $excludePostype ) ) {
             $post_type_object=get_post_type_object($pt);
             $label = $post_type_object->labels->singular_name;
            ?>
            <label>
              <input type="checkbox"<?php echo ( in_array( $pt, $pt_array ) ) ? ' checked="checked"' : ''; ?> value="<?php echo esc_attr($pt); ?>"
                     id="wpb_js_post_types_<?php echo sanitize_title($pt); ?>"
                     name="wpb_js_content_types[]">
              <?php echo ucfirst(esc_html( $label )); ?>
            </label><br>
          <?php
          }
        }
        ?>
        <p
          class="description indicator-hint"><?php esc_html_e( "Select for which content types Visual Composer should be available during post creation/editing.", "js_composer" ); ?></p>
      <?php
          }

        function storefy_vc_settings_general(){
            add_settings_field('wpb_js_content_types',esc_html__( "Content types", "js_composer" ),'storefy_vc_settings_general_callback','vc_settings_general','wpb_js_composer_settings_general');
        }

        add_action('admin_init','storefy_vc_settings_general',9999);   

  endif;

  add_action('init','storefy_basic_grid_params');   

  function storefy_basic_grid_params(){

      $post_types = get_post_types( array(),'names' );

      $post_types_list = array();
      foreach ( $post_types as $post_type ) {
          if ( $post_type !== 'revision' && $post_type !== 'nav_menu_item' ) {
              
              $post_type_object=get_post_type_object($post_type);

              $label = $post_type_object->labels->singular_name;

              $post_types_list[] = array( $post_type, ucfirst(esc_html( $label )) );
          }
      }

      $post_types_list[] = array( 'custom', esc_html__( 'Custom query', 'js_composer' ) );
      $post_types_list[] = array( 'ids', esc_html__( 'List of IDs', 'js_composer' ) );

      vc_add_param( 'vc_basic_grid', array(
              'type' => 'dropdown',
              'heading' => esc_html__( 'Data source', 'js_composer' ),
              'param_name' => 'post_type',
              'value' => $post_types_list,
              'description' => esc_html__( 'Select content type for your grid.', 'js_composer' )
      ));

  }

  if(storefy_plugin_is_active('storefy-vc-addon/storefy_vc_addon.php')){
  
      function storefy_vc_btn(){

             vc_add_param( 'vc_btn', array( 
                    'heading' => esc_html__( 'Color', 'js_composer' ),
                    'param_name' => 'color',
                    "type" => "dropdown",
                    'description' => esc_html__( 'Select button color.', 'js_composer' ),
                    // compatible with btn2, need to be converted from btn1
                    'param_holder_class' => 'vc_colored-dropdown vc_btn3-colored-dropdown',
                    'value' => array(
                        // Btn1 Colors
                        esc_html__( 'Brand Primary', 'js_composer' ) => 'brand-primary',
                        esc_html__( 'Classic Grey', 'js_composer' ) => 'default',
                        esc_html__( 'Classic Blue', 'js_composer' ) => 'primary',
                        esc_html__( 'Classic Turquoise', 'js_composer' ) => 'info',
                        esc_html__( 'Classic Green', 'js_composer' ) => 'success',
                        esc_html__( 'Classic Orange', 'js_composer' ) => 'warning',
                        esc_html__( 'Classic Red', 'js_composer' ) => 'danger',
                        esc_html__( 'Classic Black', 'js_composer' ) => 'inverse',
                        // + Btn2 Colors (default color set)
                      ) + getVcShared( 'colors-dashed' ),
                    "std" => 'grey',
                    'dependency' => array(
                      'element' => 'style',
                      'value_not_equal_to' => array(
                        'custom',
                        'outline-custom',
                        'gradient',
                        'gradient-custom',
                      ),
                    ),
                    )
            );


      }

      add_action('init','storefy_vc_btn');   

      add_action('init','storefy_vc_cta_2');   

      function storefy_vc_cta_2(){

           vc_remove_param('vc_cta_button2','color');
            vc_add_param( 'vc_cta_button2', array( 
                    "type" => "dropdown",
                    "heading" => esc_html__("Button style", 'storefy'),
                    "param_name" => "btn_style",
                    "value" => array(
                      esc_html__('Primary','storefy')=>'color-primary',
                      esc_html__('Secondary','storefy')=>'color-secondary',
                      esc_html__('Success','storefy')=>'success',
                      esc_html__('Info','storefy')=>'info',
                      esc_html__('Warning','storefy')=>'warning',
                      esc_html__('Danger','storefy')=>'danger',
                      esc_html__('Ghost Button','storefy')=>'ghost',
                      esc_html__('Link','storefy')=>'link',
                      ),
                    "std" => 'default',
                    "description" => esc_html__("Button style", 'storefy')."."
                    )
            );

         vc_add_param( 'vc_cta_button2',
            array(
              "type" => "dropdown",
              "heading" => esc_html__("Size", 'storefy'),
              "param_name" => "size",
                  "value" => array(
                    esc_html__('Large','storefy')=>'btn-lg',
                    esc_html__('Default','storefy')=>'btn-default',
                    esc_html__('Small','storefy')=>'btn-sm',
                    esc_html__('Extra small','storefy')=>'btn-xs'
                    ),
              "std" => 'btn-default',
              "description" => esc_html__("Button size", 'storefy')
            ));
      }

      function storefy_remove_meta_box_vc(){
        remove_meta_box( 'vc_teaser','page','side');
      }

      add_action('admin_init','storefy_remove_meta_box_vc');   

    add_action('init','storefy_custom_vc_row');  

    function storefy_custom_vc_row(){

     vc_add_param( 'vc_row', array( 
          'heading' => esc_html__( 'Expand section width', 'storefy' ),
          'param_name' => 'expanded',
          'class' => '',
          'value' => array(esc_html__('Expand Column','storefy')=>'1',esc_html__('Expand Background','storefy')=>'2'),
          'description' => esc_html__( 'Make section "out of the box".', 'storefy' ),
          'type' => 'checkbox',
          'group'=>esc_html__('Extended options', 'storefy')
      ) );

   
     vc_add_param( 'vc_row',   array( 
            'heading' => esc_html__( 'Background Type', 'storefy' ),
            'param_name' => 'background_type',
            'value' => array('image'=>esc_html__( 'Image', 'storefy' ),'video'=>esc_html__( 'Video', 'storefy' )),
            'type' => 'radio',
            'group'=>esc_html__('Extended options', 'storefy'),
            'std'=>'image'
         ));

     if(version_compare(WPB_VC_VERSION,'4.7.0','>=')){

          vc_remove_param('vc_row','full_width');
          vc_remove_param('vc_row','video_bg');
          vc_remove_param('vc_row','video_bg_url');
          vc_remove_param('vc_row','video_bg_parallax');
          vc_remove_param('vc_row','parallax');
          vc_remove_param('vc_row','parallax_image');

          if(version_compare(WPB_VC_VERSION,'4.11.0','>=') || version_compare(WPB_VC_VERSION,'4.11','>=')){

              vc_remove_param('vc_row','parallax_speed_video');
              vc_remove_param('vc_row','parallax_speed_bg');
          }

          vc_add_param( 'vc_row',   array( 
                  'heading' => esc_html__( 'Video Source', 'storefy' ),
                  'param_name' => 'video_source',
                  'value' => array('local'=>esc_html__( 'Local Server', 'storefy' ),'youtube'=>esc_html__( 'Youtube/Vimeo', 'storefy' )),
                  'type' => 'radio',
                  'group'=>esc_html__('Extended options', 'storefy'),
                  'std'=>'local',
                  'dependency' => array( 'element' => 'background_type', 'value' => array('video') )   
           ));


         vc_add_param( 'vc_row', array( 
              'heading' => esc_html__( 'Background Video (mp4)', 'storefy' ),
              'param_name' => 'background_video',
              'type' => 'attach_video',
              'group'=>esc_html__('Extended options', 'storefy'),
              'dependency' => array( 'element' => 'video_source', 'value' => array('local') )   
          ) );

         vc_add_param( 'vc_row', array( 
              'heading' => esc_html__( 'Background Video (webm)', 'storefy' ),
              'param_name' => 'background_video_webm',
              'type' => 'attach_video',
              'group'=>esc_html__('Extended options', 'storefy'),
              'dependency' => array( 'element' => 'video_source', 'value' => array('local') )   
          ) );

         vc_add_param( 'vc_row', array( 
              'heading' => esc_html__( 'Background Image', 'storefy' ),
              'param_name' => 'background_image',
              'type' => 'attach_image',
              'group'=>esc_html__('Extended options', 'storefy'),
              'dependency' => array( 'element' => 'background_type', 'value' => array('image') )   
          ) );

          vc_add_param( 'vc_row',
              array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Video link', 'storefy' ),
                'param_name' => 'video_bg_url',
                'group'=>esc_html__('Extended options', 'storefy'),
                'description' => esc_html__( 'Add YouTube/Vimeo link', 'storefy' ),
                'dependency' => array(
                  'element' => 'video_source',
                  'value' => array('youtube'),
                ),
           ));
      }
      else{

         vc_add_param( 'vc_row', array( 
              'heading' => esc_html__( 'Background Video (mp4)', 'storefy' ),
              'param_name' => 'background_video',
              'type' => 'attach_video',
              'group'=>esc_html__('Extended options', 'storefy'),
              'dependency' => array( 'element' => 'background_type', 'value' => array('video') )   
          ) );

         vc_add_param( 'vc_row', array( 
              'heading' => esc_html__( 'Background Video (webm)', 'storefy' ),
              'param_name' => 'background_video_webm',
              'type' => 'attach_video',
              'group'=>esc_html__('Extended options', 'storefy'),
              'dependency' => array( 'element' => 'background_type', 'value' => array('video') )   
          ) );

         vc_add_param( 'vc_row', array( 
              'heading' => esc_html__( 'Background Image', 'storefy' ),
              'param_name' => 'background_image',
              'type' => 'attach_image',
              'group'=>esc_html__('Extended options', 'storefy'),
              'dependency' => array( 'element' => 'background_type', 'value' => array('image') )   
          ) );


      }

     vc_add_param( 'vc_row', array( 
          'heading' => esc_html__( 'Extra id', 'storefy' ),
          'param_name' => 'el_id',
          'type' => 'textfield',
          "description" => esc_html__("If you wish to add anchor id to this row. Anchor id may used as link like href=\"#yourid\"", 'storefy'),
      ) );


     vc_add_param( 'vc_row_inner', array( 
          'heading' => esc_html__( 'Extra id', 'storefy' ),
          'param_name' => 'el_id',
          'type' => 'textfield',
          "description" => esc_html__("If you wish to add anchor id to this row. Anchor id may used as link like href=\"#yourid\"", 'storefy'),
      ) );

      vc_add_param( 'vc_row', array( 
          'heading' => esc_html__( 'Background Style', 'storefy' ),
          'param_name' => 'background_style',
          'type' => 'dropdown',
          'value'=>array(
                esc_html__('No Repeat', 'js_composer') => 'no-repeat',
                esc_html__("Cover", 'js_composer') => 'cover',
                esc_html__('Contain', 'js_composer') => 'contain',
                esc_html__('Repeat', 'js_composer') => 'repeat',
                esc_html__("Parallax", 'storefy') => 'parallax',
               esc_html__("Fixed", 'storefy') => 'fixed',
              ),
          'group'=>esc_html__('Extended options', 'storefy'),
          'dependency' => array( 'element' => 'background_type', 'value' => array('image') )       
      ) );
    }


  }

 add_action('init','storefy_vc_single_image');   

  function storefy_vc_single_image(){

      vc_add_param( 'vc_single_image', array( 
          'heading' => esc_html__( 'Image Hover Option', 'storefy' ),
          'param_name' => 'image_hover',
          'type' => 'radio',
          'value'=>array(
                'none'=>esc_html__("None", 'storefy'),
                'image'=>esc_html__("Image", 'storefy'),
                'text'=>esc_html__("Text", 'storefy'),
              ),
          'group'=>esc_html__('Extended options', 'storefy'),
          'std' => 'none',  
          'dependency' => array(
            'element' => 'source',
            'value' => array( 'media_library', 'featured_image' )
          ),
     
      ) );

      vc_add_param( 'vc_single_image', array( 
          'heading' => esc_html__( 'Image', 'storefy' ),
          'param_name' => 'image_hover_src',
          'type' => 'attach_image',
          'value'=>"",
          'holder'=>'div',
          'param_holder_class'=>'image-hover',
          'group'=>esc_html__('Extended options', 'storefy'),
          'dependency' => array( 'element' => 'image_hover','value'=>array('image'))       
      ) );

      vc_add_param( 'vc_single_image', array( 
          'heading' => esc_html__( 'Animation Style', 'storefy' ),
          'param_name' => 'image_hover_type',
          'type' => 'dropdown',
          'value'=>array(
              esc_html__('Default','storefy')=>'default',
              esc_html__('From Left','storefy')=>'fromleft',
              esc_html__('From Right','storefy')=>'fromright',
              esc_html__('From Top','storefy')=>'fromtop',
              esc_html__('From Bottom','storefy')=>'frombottom',
            ),
          'group'=>esc_html__('Extended options', 'storefy'),
          'dependency' => array( 'element' => 'image_hover','value'=>array('image'))       
      ) );

        vc_add_param( 'vc_single_image', array( 
            'heading' => esc_html__("Image style", "js_composer"),
            'param_name' => 'style',
            'type' => 'dropdown',
            'value'=>array(
                        esc_html__("Default",'storefy') => "",
                        esc_html__('Rounded','storefy') => 'vc_box_rounded',
                        esc_html__('Border','storefy') => 'vc_box_border',
                        esc_html__('Outline','storefy') => 'vc_box_outline',
                        esc_html__('Shadow','storefy') => 'vc_box_shadow',
                        esc_html__('Bordered shadow','storefy') => 'vc_box_shadow_border',
                        esc_html__('3D Shadow','storefy') => 'vc_box_shadow_3d',
                        esc_html__('Round','storefy') => 'vc_box_circle', //new
                        esc_html__('Round Border','storefy') => 'vc_box_border_circle', //new
                        esc_html__('Round Outline','storefy') => 'vc_box_outline_circle', //new
                        esc_html__('Round Shadow','storefy') => 'vc_box_shadow_circle', //new
                        esc_html__('Round Border Shadow','storefy') => 'vc_box_shadow_border_circle', //new
                        esc_html__('Circle','storefy') => 'vc_box_circle_2', //new
                        esc_html__('Circle Border','storefy') => 'vc_box_border_circle_2', //new
                        esc_html__('Circle Outline','storefy') => 'vc_box_outline_circle_2', //new
                        esc_html__('Circle Shadow','storefy') => 'vc_box_shadow_circle_2', //new
                        esc_html__('Circle Border Shadow','storefy') => 'vc_box_shadow_border_circle_2', //new
                        esc_html__("Diamond",'storefy') => "dt_vc_box_diamond" //new from detheme
                    ),
          'dependency' => array(
            'element' => 'source',
            'value' => array( 'media_library', 'featured_image' )
          ),

        ) );



      vc_add_param( 'vc_single_image', array( 
          'heading' => esc_html__( 'Pre Title', 'storefy' ),
          'param_name' => 'image_hover_pre_text',
          'type' => 'textfield',
          'value'=>"",
          'group'=>esc_html__('Extended options', 'storefy'),
          'dependency' => array( 'element' => 'image_hover','value'=>array('text'))       
      ) );
      vc_add_param( 'vc_single_image', array( 
          'heading' => esc_html__( 'Title', 'storefy' ),
          'param_name' => 'image_hover_text',
          'type' => 'textfield',
          'value'=>"",
          'group'=>esc_html__('Extended options', 'storefy'),
          'dependency' => array( 'element' => 'image_hover','value'=>array('text'))       
      ) );
  }
}
/* end vc_set_as_theme */


function storefy_strip_shortcodes( $content ) {

      global $shortcode_tags;

      if ( false === strpos( $content, '[' ) ) {
        return $content;
      }

      if (empty($shortcode_tags) || !is_array($shortcode_tags))
        return $content;

      // Find all registered tag names in $content.
      preg_match_all( '@\[([^<>&/\[\]\x00-\x20=]++)@', $content, $matches );
      $tagnames = array_intersect( array_keys( $shortcode_tags ), $matches[1] );

      if ( empty( $tagnames ) ) {
        return $content;
      }


      $content = do_shortcodes_in_html_tags( $content, true, $tagnames );

      $pattern = get_shortcode_regex( $tagnames );

      $content = preg_replace_callback( "/$pattern/", 'storefy_strip_shortcode_tag', $content );

      // Always restore square braces so we don't break things like <!--[if IE ]>
      $content = unescape_invalid_shortcodes( $content );

      return $content;
}

function storefy_strip_shortcode_tag($m){
  global $shortcode_tags;

  preg_match_all( '@\[([^<>&/\[\]\x00-\x20=]++)@', $m[5], $matches );
  $tagnames = array_intersect( array_keys( $shortcode_tags ), $matches[1] );

  if ( empty( $tagnames ) ) {
    return $m[5];
  }


  $pattern = get_shortcode_regex( $tagnames );


  if( false == strpos( $m[5] , '[')) return preg_replace_callback( "/$pattern/", 'storefy_strip_shortcode_tag', $m[5] );

  return $m[5];
}


add_filter( 'get_search_form','storefy_get_search_form', 10, 1 );

function storefy_get_search_form( $form ) {
    $format = current_theme_supports( 'html5', 'search-form' ) ? 'html5' : 'xhtml';
    $format = apply_filters( 'search_form_format', $format );

    if ( 'html5' == $format ) {
      $form = '<form method="get" class="search-form" action="' . esc_url( home_url( '/' ) ) . '">
        <label>
          <span class="screen-reader-text">' . esc_html_x( 'Search for:', 'label','storefy' ) . '</span>
          <input type="search" class="search-field" placeholder="'.esc_attr__('search','storefy').'" value="' . get_search_query() . '" name="s" title="' . esc_attr_x( 'Search for:', 'label','storefy' ) . '" />
          <i class="icon-search-6"></i>
        </label>
        <input type="submit" class="searchsubmit" value="'. esc_attr_x( 'Search', 'submit button', 'storefy' ) .'" />
      </form>';
    } else {
      $form = '<form method="get" class="searchform" action="' . esc_url( home_url( '/' ) ) . '">
        <div>
          <label class="screen-reader-text">' . esc_html_x( 'Search for:', 'label','storefy' ) . '</label>
          <input type="text" value="' . get_search_query() . '" name="s" placeholder="'.esc_attr__('search','storefy').'" />
          <i class="icon-search-6"></i>
          <input type="submit" class="searchsubmit" value="'. esc_attr_x( 'Search', 'submit button', 'storefy' ) .'" />
        </div>
      </form>';
    }

  return $form;
}


add_filter( 'get_product_search_form','storefy_get_product_search_form', 10, 1 );

function storefy_get_product_search_form( $form ) {
  $form = '<form method="get" action="' . esc_url( home_url( '/'  ) ) . '">
      <div>
        <label class="screen-reader-text">' . esc_html__( 'Search for:', 'woocommerce' ) . '</label>
        <i class="icon-search-6"></i>
        <input type="text" value="' . get_search_query() . '" name="s" placeholder="' . esc_attr__( 'Search for products', 'woocommerce' ) . '" />
        <input type="submit" class="searchsubmit" value="'. esc_attr__( 'Search', 'woocommerce' ) .'" />
        <input type="hidden" name="post_type" value="product" />
      </div>
    </form>';

  return $form;
}

function is_storefy_home($post=null){

  if(!isset($post)) $post=get_post();

  return apply_filters('is_detheme_home',false,$post);
}


function storefy_remove_excerpt_more($excerpt_more=""){

  return "&hellip;";
}

add_filter('excerpt_more','storefy_remove_excerpt_more');

function storefy_prepost_vc_basic_grid_settings($content){

        $regexshortcodes=
        '\\['                              // Opening bracket
        . '(\\[?)'                           // 1: Optional second opening bracket for escaping shortcodes: [[tag]]
        . "(vc_basic_grid|vc_masonry_grid)"// 2: Shortcode name
        . '(?![\\w-])'                       // Not followed by word character or hyphen
        . '('                                // 3: Unroll the loop: Inside the opening shortcode tag
        .     '[^\\]\\/]*'                   // Not a closing bracket or forward slash
        .     '(?:'
        .         '\\/(?!\\])'               // A forward slash not followed by a closing bracket
        .         '[^\\]\\/]*'               // Not a closing bracket or forward slash
        .     ')*?'
        . ')'
        . '(?:'
        .     '(\\/)'                        // 4: Self closing tag ...
        .     '\\]'                          // ... and closing bracket
        . '|'
        .     '\\]'                          // Closing bracket
        .     '(?:'
        .         '('                        // 5: Unroll the loop: Optionally, anything between the opening and closing shortcode tags
        .             '[^\\[]*+'             // Not an opening bracket
        .             '(?:'
        .                 '\\[(?!\\/\\2\\])' // An opening bracket not followed by the closing shortcode tag
        .                 '[^\\[]*+'         // Not an opening bracket
        .             ')*+'
        .         ')'
        .         '\\[\\/\\2\\]'             // Closing shortcode tag
        .     ')?'
        . ')'
        . '(\\]?)';                          // 6: Optional second closing brocket for escaping shortcodes: [[tag]]

  $content=preg_replace('/'.$regexshortcodes.'/s', '[$2 $3 post_id="'.get_the_ID().'"]', $content);
  return $content;

}

function storefy_get_post_by_slug($slug){
    $post = get_posts(array(
            'name' => $slug,
            'posts_per_page' => 1,
            'post_type' => 'page',
            'post_status' => 'publish'
    ));
    
    if(! $post ) {
        return;
    }

    return $post[0];
}

function storefy_get_pre_footer_page(){

  $post_ID=get_the_ID();

  $originalpost = $GLOBALS['post'];

  if(!get_storefy_option('showfooterpage',true) || !get_storefy_option('footerpage') || $post_ID==get_storefy_option('footerpage'))
    return;

  $post_ID = get_storefy_option('footerpage');
  $post = storefy_get_wpml_post($post_ID);

  if(!$post && !$post = storefy_get_post_by_slug($post_ID) )  return;

  $old_sidebar=get_query_var('sidebar');

  set_query_var('sidebar','nosidebar');

  $GLOBALS['post']=$post;
  $pre_footer_page=do_shortcode(storefy_prepost_vc_basic_grid_settings($post->post_content));
  $GLOBALS['post']=$originalpost;


  set_query_var('sidebar',$old_sidebar);
  print "<div class=\"pre-footer-section\">".$pre_footer_page."</div>";

}


add_action('storefy_before_footer_section','storefy_get_pre_footer_page'); 

function storefy_get_post_footer_page(){

  $post_ID=get_the_ID();

  $originalpost = $GLOBALS['post'];

  if(!get_storefy_option('showfooterpage',true) || !get_storefy_option('postfooterpage') || $post_ID==get_storefy_option('postfooterpage'))
    return;

  $post_ID = get_storefy_option('postfooterpage');


  $post = storefy_get_wpml_post($post_ID);

  if(!$post && !$post = storefy_get_post_by_slug($post_ID) )  return;

  $old_sidebar=get_query_var('sidebar');
  set_query_var('sidebar','nosidebar');

  $GLOBALS['post']=$post;
  $post_footer_page=do_shortcode(storefy_prepost_vc_basic_grid_settings($post->post_content));
  $GLOBALS['post']=$originalpost;

  set_query_var('sidebar',$old_sidebar);

  print "<div class=\"post-footer-section\">".$post_footer_page."</div>";

}

add_action('storefy_after_footer_section','storefy_get_post_footer_page'); 

/*wpml translation */

function storefy_get_wpml_post($post_id){

  if(!defined('ICL_LANGUAGE_CODE'))
        return get_post($post_id);

    global $wpdb;

   $postid = $wpdb->get_var(
      $wpdb->prepare("SELECT element_id FROM {$wpdb->prefix}icl_translations WHERE trid=(SELECT trid FROM {$wpdb->prefix}icl_translations WHERE element_id='%d' LIMIT 1) AND element_id!='%d' AND language_code='%s'", $post_id,$post_id,ICL_LANGUAGE_CODE)
   );

  if($postid)
      return get_post($postid);
  
  return get_post($post_id);
}


/* detheme-post*/

function storefy_loadDethemePostTemplate(){

    global $post,$wp_query,$GLOBALS;

    if(!isset($post) || isset($_GET['type']))
        return true;

    $standard_type=$post->post_type;

    if(is_archive() && in_array($standard_type,array('essential_grid'))){

        $post_type_data = get_post_type_object( $standard_type);

        $post_type_slug = $post_type_data->rewrite['slug'];

        if(!$page = get_page_by_path($post_type_slug))
        return true;

        $query_vars=array(
        'post_type' => 'page',
        'page_id'=>$page->ID,
        'posts_per_page'=>1
        );

       $original_query_vars=$wp_query->query_vars;

       $wp_query->query($query_vars);
       if(!$wp_query->have_posts()){
           $wp_query->query($original_query_vars);
           return true;
       }

      $GLOBALS['post']=$page;
    }
    else{
      return true;
    }
}

add_action('template_redirect', 'storefy_loadDethemePostTemplate');


/* essential grid post handle */

if (storefy_plugin_is_active('essential-grid/essential-grid.php')) {

  function storefy_essential_grid_labels($labels){

    $dtpost_settings=get_option('essential_grid_settings');

    if(!$dtpost_settings || !is_array($dtpost_settings)){
      return $labels;
    }

    if(isset($dtpost_settings['label']) && ''!=$dtpost_settings['label']){

      $labels->label=$dtpost_settings['label'];
      $labels->all_items=$dtpost_settings['label'];
      $labels->menu_name=$dtpost_settings['label'];
      $labels->name=$dtpost_settings['label'];

    }

    if(isset($dtpost_settings['singular_label']) && ''!=$dtpost_settings['singular_label']){

      $labels->singular_label=$dtpost_settings['singular_label'];
      $labels->singular_name=$dtpost_settings['singular_label'];

    }

    if(isset($dtpost_settings['slug']) && ''!=$dtpost_settings['slug']){

      $labels->rewrite['slug']=$dtpost_settings['slug'];

    }
    return $labels;
  }

  function storefy_essential_grid_setting_page($post){


    $dtpost_settings=get_option('essential_grid_settings',array('label'=>esc_html__("Ess. Grid Posts", 'storefy'),'singular_label'=>esc_html__("Ess. Grid Post", 'storefy'),'slug'=>''));

    if(wp_verify_nonce( isset($_POST['essential_grid-setting'])?$_POST['essential_grid-setting']:"", 'essential_grid-setting')){

         $dtpost_name=(isset($_POST['dtpost_name']))?$_POST['dtpost_name']:'';
         $singular_name=(isset($_POST['singular_name']))?$_POST['singular_name']:'';
         $rewrite_slug=(isset($_POST['dtpost_slug']))?$_POST['dtpost_slug']:'';

         $do_update=false;

         if($dtpost_name!=$dtpost_settings['label'] && ''!=$dtpost_name){
            $dtpost_settings['label']=$dtpost_name;
            $do_update=true;
         }

         if($singular_name!=$dtpost_settings['singular_label'] && ''!=$singular_name){
            $dtpost_settings['singular_label']=$singular_name;
            $do_update=true;
           
         }

         if($rewrite_slug!=$dtpost_settings['slug']){
            $dtpost_settings['slug']=$rewrite_slug;
            $do_update=true;
         
         }

         if($do_update){
             update_option('essential_grid_settings',$dtpost_settings);
         }

    }



    $args = array( 'page' => 'essential_grid_setting');
    $url = esc_url(add_query_arg( $args, admin_url( 'admin.php' )));

    $dtpost_name=$dtpost_settings['label'];
    $singular_name=$dtpost_settings['singular_label'];
    $slug=$dtpost_settings['slug'];
?>
<div class="dtpost-panel">
<h2><?php printf(esc_html__('%s Settings', 'storefy'),ucwords($dtpost_name));?></h2>
<form method="post" action="<?php print esc_url($url);?>">
<?php wp_nonce_field( 'essential_grid-setting','essential_grid-setting');?>
<input name="option_page" value="reading" type="hidden"><input name="action" value="update" type="hidden">
<table class="form-table">
<tbody>
<tr>
<th scope="row"><label for="dtpost_name"><?php esc_html_e('Label Name','storefy');?></label></th>
<td>
<input name="dtpost_name" id="dtpost_name" max-length="50" value="<?php print sanitize_text_field($dtpost_name);?>" class="" type="text"></td>
</tr>
<tr>
<th scope="row"><label for="singular_name"><?php esc_html_e('Singular Name','storefy');?></label></th>
<td>
<input name="singular_name" id="singular_name" max-length="50" value="<?php print sanitize_text_field($singular_name);?>" class="" type="text"></td>
</tr>
<tr>
<th scope="row"><label for="dtpost_slug"><?php esc_html_e('Rewrite Slug','storefy');?></label></th>
<td>
<input name="dtpost_slug" id="dtpost_slug" max-length="50" value="<?php print sanitize_text_field($slug);?>" class="" type="text"></td>
</tr>
</tbody></table>


<p class="submit"><input name="submit" id="submit" class="button button-primary" value="<?php esc_html_e('Save Changes','storefy');?>" type="submit"></p></form>
</div>
<?php
  }

  function storefy_essential_grid_seeting_menu(){
      add_theme_page(esc_html__('Portfolio Settings', 'storefy'), esc_html__('Portfolio Settings', 'storefy'),'manage_options','essential_grid_setting','storefy_essential_grid_setting_page');
  }

  add_action('admin_menu', 'storefy_essential_grid_seeting_menu');

  add_filter( 'post_type_labels_essential_grid', 'storefy_essential_grid_labels');

  function storefy_related_query_post_grid($query){

    if(isset($query['related']) && (bool)$query['related']){

      $query["post_type"]= get_post_type(get_the_id());
      $query['post__not_in']=(isset($query['post__not_in']) && is_array($query['post__not_in']))? array_push(get_the_id(),$query['post__not_in']):array(get_the_id());

      if($query["post_type"] == 'post'){

        $terms = get_the_terms( get_the_id(), 'category' );

        $query['tax_query']=array(
          array(
          'taxonomy'=>'category',
          'field' =>'id',
          'terms'=>$terms
          ),
          'relation'=>'OR');

      }
      elseif($query["post_type"] == 'essential_grid'){

        $terms = get_object_term_cache( get_the_id(), 'essential_grid_category' );

        $terms_ids=array();
        if($terms && count($terms)){
          foreach($terms as $term){
            $terms_ids[]=$term->term_id;
          }

        $query['tax_query']=array(
          array(
          'taxonomy'=>'essential_grid_category',
          'field' =>'id',
          'terms'=>$terms_ids
          ),
          'relation'=>'OR');
        }
        elseif(isset($query['tax_query'])){
          unset($query['tax_query']);
        }
      }
      elseif($query["post_type"] == 'dtpost'){

        $terms = get_object_term_cache( get_the_id(), 'dtpostcat' );

        $terms_ids=array();
        if($terms && count($terms)){
          foreach($terms as $term){
            $terms_ids[]=$term->term_id;
          }

        $query['tax_query']=array(
          array(
          'taxonomy'=>'dtpostcat',
          'field' =>'id',
          'terms'=>$terms_ids
          ),
          'relation'=>'OR');
        }
        elseif(isset($query['tax_query'])){
          unset($query['tax_query']);
        }
      }
      
    }
    return $query;
  }

  add_filter('essgrid_get_posts','storefy_related_query_post_grid');

  add_filter('essgrid_query_caching','__return_false');


  function storefy_ess_grid_post_type($post_type, $args){

    global $wp_post_types;

    if($post_type!='essential_grid') return true;

     $dtpost_settings = get_option('essential_grid_settings');

     if(!$dtpost_settings || !isset($dtpost_settings['slug']) || $dtpost_settings['slug']=='') return true;



     $essential_post=$wp_post_types['essential_grid'];
     $essential_post->has_archive=true;
     $essential_post->rewrite['slug']=$dtpost_settings['slug'];

     $wp_post_types['essential_grid']=$essential_post;

     add_rewrite_tag( "%$post_type%", '(.+?)', $args->query_var ? "{$args->query_var}=" : "post_type=$post_type&pagename=" );

     add_rewrite_rule( "{$dtpost_settings['slug']}/?$", "index.php?post_type=$post_type", 'top' );


     $permastruct_args = $args->rewrite;

     $permastruct_args['feed'] = isset($permastruct_args['feeds'])?$permastruct_args['feeds']:false;
     add_permastruct( $post_type, $dtpost_settings['slug']."/%$post_type%", $permastruct_args );
  }

  add_action( 'registered_post_type', 'storefy_ess_grid_post_type',999,2);
}


/* comment setting */

function storefy_is_comment_open($open, $post_id){

  $post_type = get_post_type($post_id);
  if(!in_array($post_type,storefy_post_use_comment())){
    return ((bool)get_storefy_option('comment-open-'.$post_type)) && $open;
  }

  return $open;
}

add_filter( 'comments_open','storefy_is_comment_open',0,2);

/* dt carousel image size */

function storefy_create_carousel_size($out, $id){

  if(!$id) return $out;

  $img_url = wp_get_attachment_url($id);
  if($newsize=storefy_aq_resize($img_url,350,230,true,false)){
    return $newsize;
  }
  return $out;
}

add_filter('dt_carousel_pagination_image','storefy_create_carousel_size',1,2);

if ( ! function_exists( 'storefy_breadcrumb' ) ) {

  function storefy_breadcrumb(){

    if(function_exists('woocommerce_breadcrumb')){
/*
      $wc_breadcrumb_args = array(
        'delimiter' => "/",
        'wrap_before' => '<section class="section-breadcrumbs"><div class="container"><ul class="breadcrumbs" dir="ltr">',
        'wrap_after' => '</ul></div></section>',
        'before' => '<li><span>',
        'beforecurrent' => '<li><span class="current">',
        'after' => '</span></li>',
        'home' => esc_html__( 'Home', 'woocommerce' ),
      );
*/
      $wc_breadcrumb_args = array(
        'delimiter' => "/",
        'wrap_before' => '<section class="section-breadcrumbs"><div class="container"><div class="breadcrumbs" dir="ltr">',
        'wrap_after' => '</div></div></section>',
        'before' => '<span>',
        'beforecurrent' => '<span class="current">',
        'after' => '</span>',
        'home' => esc_html__( 'Home', 'woocommerce' ),
      );

        woocommerce_breadcrumb($wc_breadcrumb_args);
    }
  }
}



function storefy_remove_blog_slug( $wp_rewrite ) {
  if ( ! is_multisite() )
    return;
  // check multisite and main site
  if ( ! is_main_site() )
    return;

  // set checkup
  $rewrite = FALSE;

  // update_option
  $wp_rewrite->permalink_structure = preg_replace( '!^(/)?blog/!', '$1', $wp_rewrite->permalink_structure );
  update_option( 'permalink_structure', $wp_rewrite->permalink_structure );

  // update the rest of the rewrite setup
  $wp_rewrite->author_structure = preg_replace( '!^(/)?blog/!', '$1', $wp_rewrite->author_structure );
  $wp_rewrite->date_structure = preg_replace( '!^(/)?blog/!', '$1', $wp_rewrite->date_structure );
  $wp_rewrite->front = preg_replace( '!^(/)?blog/!', '$1', $wp_rewrite->front );

  // walk through the rules
  $new_rules = array();
  foreach ( $wp_rewrite->rules as $key => $rule )
    $new_rules[ preg_replace( '!^(/)?blog/!', '$1', $key ) ] = $rule;
  $wp_rewrite->rules = $new_rules;

  // walk through the extra_rules
  $new_rules = array();
  foreach ( $wp_rewrite->extra_rules as $key => $rule )
    $new_rules[ preg_replace( '!^(/)?blog/!', '$1', $key ) ] = $rule;
  $wp_rewrite->extra_rules = $new_rules;

  // walk through the extra_rules_top
  $new_rules = array();
  foreach ( $wp_rewrite->extra_rules_top as $key => $rule )
    $new_rules[ preg_replace( '!^(/)?blog/!', '$1', $key ) ] = $rule;
  $wp_rewrite->extra_rules_top = $new_rules;

  // walk through the extra_permastructs
  $new_structs = array();
  foreach ( $wp_rewrite->extra_permastructs as $extra_permastruct => $struct ) {
    $struct[ 'struct' ] = preg_replace( '!^(/)?blog/!', '$1', $struct[ 'struct' ] );
    $new_structs[ $extra_permastruct ] = $struct;
  }
  $wp_rewrite->extra_permastructs = $new_structs;
} 

add_action( 'generate_rewrite_rules', 'storefy_remove_blog_slug' );

if(storefy_plugin_is_active('woocommerce/woocommerce.php')){
  require_once( get_template_directory().'/lib/woocommerce.php'); 
}

 add_filter("dt_carousel_navigation_btn",'storefy_dt_carousel_pagination');

 function storefy_dt_carousel_pagination($pagination){
  return array('<span class="btn-owl prev page"><i class="storefy-left-arrow"></i></span>','<span class="btn-owl next page"><i class="storefy-right-arrow"></i></span>');
 }

function storefy_style_loader_tag($tag){

  return preg_replace('/\<link/','<link property', $tag);
}
add_filter('style_loader_tag','storefy_style_loader_tag');

if ( ! function_exists( 'storefy_remove_http' ) ) {
  function storefy_remove_http($url) {
    //Remove http: to make URL compatible on SSL / HTTPS site
    $url = str_replace('http:','',$url);
    $url = str_replace('https:','',$url);
    return $url;
  } 
} 

if ( ! function_exists( 'storefy_hex2rgba' ) ) {
  function storefy_hex2rgba( $hex, $alpha = '' ) {
      $hex = str_replace( "#", "", $hex );
      if ( strlen( $hex ) == 3 ) {
          $r = hexdec( substr( $hex, 0, 1 ) . substr( $hex, 0, 1 ) );
          $g = hexdec( substr( $hex, 1, 1 ) . substr( $hex, 1, 1 ) );
          $b = hexdec( substr( $hex, 2, 1 ) . substr( $hex, 2, 1 ) );
      } else {
          $r = hexdec( substr( $hex, 0, 2 ) );
          $g = hexdec( substr( $hex, 2, 2 ) );
          $b = hexdec( substr( $hex, 4, 2 ) );
      }
      $rgb = $r . ',' . $g . ',' . $b;

      if ( '' == $alpha ) {
          return 'rgba(' . $rgb . ',' . 0 . ')';
      } else {
          $alpha = floatval( $alpha );

          return 'rgba(' . $rgb . ',' . $alpha . ')';
      }
  } 
} 

function storefy_set_blog_masonry_posts_per_page($query) {
    if (($query->is_posts_page==1) && (get_storefy_option('blog_type')=='masonry')) {
      $query->set( 'posts_per_page', -1 );
      return;
    }
}

function storefy_get_link_pages_args() {
  $detheme_link_pages_args = array(
    'before'           => '<div class="row"><div class="billio_link_page container">',
    'after'            => '</div></div>',
    'link_before'      => '<span class="page-numbers">',
    'link_after'       => '</span>',
    'next_or_number'   => 'number',
    'separator'        => ' ',
    'nextpagelink'     => esc_html__( 'Next page','storefy' ),
    'previouspagelink' => esc_html__( 'Previous page','storefy' ),
    'pagelink'         => '%',
    'echo'             => 1
  );

  return $detheme_link_pages_args;
}

function storefy_set_global_style($value) {
  global $storefy_Style;

  $storefy_Style[] = $value;     
}

function storefy_get_global_var($varname) {
  if (isset($GLOBALS[$varname])) {
    return $GLOBALS[$varname];  
  }
}

function storefy_set_global_var($varname,$value) {
    $GLOBALS[$varname] = $value;  
}

function storefy_load_vc_nav_buttons(){


  $fields=get_storefy_option('menu_icon_fields');

  if(!$fields || !is_array($fields)) return;

  $i=0;

//JDZ 2/27/2017 BEGIN
print '<div class="navigation_button_item navigation_active"><i class="simple-line-icon-phone"></i><div class="text-box"><div class="navigation-label">(800) 270-8926</div><div class="navigation-text">Mon - Fri | 8 - 5 CST</div></div></div>';

print '<div class="navigation_button_item"><i class="simple-line-icon-tag"></i><div class="text-box"><div class="navigation-label">FREE SHIPPING</div><div class="navigation-text">On Orders Over $100!</div></div></div>';

//foreach($fields as $field){
//
//    print '<div class="navigation_button_item'.($i=='0' ? " navigation_active":"").'">';
//    print (isset($field['icon']) && ($icon=$field['icon'])) ? "<i class=\"simple-line-icon-tag\"></i>" : ""; 
//
//    if((isset($field['label']) && $field['label']!='') || (isset($field['text']) && $field['text']!='')){
//
//      print "<div class=\"text-box\">";
//      print isset($field['label']) && $field['label']!='' ? "<div class=\"navigation-label\">".$field['label']."</div>": "";
//      print isset($field['text']) && $field['text']!='' ? "<div class=\"navigation-text\">".$field['text']."</div>": "";
//      print "</div>";
//
//    }
//    print '</div>';
//
//    $i++;
//
//  }
//JDZ 2/27/2017 END

}
  

if ( ! is_admin() ) {
// ---------------------- FRONTPAGE -------------------
if ( defined('WC_VERSION') ) {
// ---------------------- WooCommerce active -------------------
  
    /**
   * Set Pagination for shortcodes custom loop on single-pages.
     * @uses $woocommerce_loop;
     */
    add_action( 'pre_get_posts', 'dt_wc_pre_get_posts_query' ); 
    function dt_wc_pre_get_posts_query( $query ) {
      global $woocommerce_loop;
    
      if ( $query->is_main_query() ){
    
        if ( isset($query->query['paged']) ){
          $woocommerce_loop['paged'] = $query->query['paged'];
        }
      }

      
      if ( ! $query->is_post_type_archive || empty($query->query['post_type']) || $query->query['post_type'] !== 'product' ){
        return;
      }
      
      $query->is_paged = true;
      $paged = (isset($woocommerce_loop['paged'])) ? $woocommerce_loop['paged'] : 1;
      $query->query['paged'] = $paged;
      $query->query_vars['paged'] = $paged;

    }
  
  /** Prepare Pagination data for shortcodes on pages
     * @uses $woocommerce_loop;
   */
  add_action( 'loop_end', 'dt_query_loop_end' ); 
  function dt_query_loop_end( $query ) {
    
    if ( ! $query->is_post_type_archive || empty($query->query['post_type']) || $query->query['post_type'] !== 'product' ){
      return;
    }
    
    // Cache data for pagination
    global $woocommerce_loop;
    $woocommerce_loop['pagination']['paged'] = 1;

    $paged = (isset($woocommerce_loop['paged'])) ? $woocommerce_loop['paged'] : 1;
    $woocommerce_loop['pagination']['paged'] = $paged;

    $woocommerce_loop['pagination']['found_posts'] = $query->found_posts;
    $woocommerce_loop['pagination']['max_num_pages'] = $query->max_num_pages;
    $woocommerce_loop['pagination']['post_count'] = $query->post_count;
    $woocommerce_loop['pagination']['current_post'] = $query->current_post;
  }
  /**
   * Pagination for shortcodes on single-pages 
   * @uses $woocommerce_loop;
   */
  add_action( 'woocommerce_after_template_part', 'dt_wc_shortcode_pagination' ); 
  function dt_wc_shortcode_pagination( $template_name ) {
    if ( ! ( $template_name === 'loop/loop-end.php' && is_page() ) ){
      return;
    }
    global $wp_query, $woocommerce_loop;
    if ( ! isset( $woocommerce_loop['pagination'] ) ){
      return;
    }
    $wp_query->query_vars['paged'] = $woocommerce_loop['pagination']['paged'];
    $wp_query->query['paged'] = $woocommerce_loop['pagination']['paged'];
    $wp_query->max_num_pages = $woocommerce_loop['pagination']['max_num_pages'];
    $wp_query->found_posts = $woocommerce_loop['pagination']['found_posts'];
    $wp_query->post_count = $woocommerce_loop['pagination']['post_count'];
    $wp_query->current_post = $woocommerce_loop['pagination']['current_post'];
 
    // Custom pagination function or default woocommerce_pagination()
    storefy_woocommerce_pagination();
  } 
  /**
   * Custom pagination for WooCommerce instead the default woocommerce_pagination()
   * @uses plugin Prime Strategy Page Navi, but added is_singular() on #line16
   */
  remove_action('woocommerce_after_shop_loop', 'woocommerce_pagination', 10);
  add_action( 'woocommerce_after_shop_loop', 'storefy_woocommerce_pagination', 10);
  function storefy_woocommerce_pagination() {
    woocommerce_pagination();
  }
}// END WOOCOMMERCE
}// END FRONTPAGE


/* post_title_ filter */

function storefy_fix_post_title($title){
  return strip_tags($title,'<i><span><strong><b>');
}

/* search option */

function storefy_search_options(){


  $post_type_selected=isset($_GET['post_type']) ? sanitize_key($_GET['post_type']) : "";
  $post_types = get_post_types( array());
  $select_class = wp_is_mobile() ? "no-select" : "";
?>
                      <select name="post_type" class="post-type-select <?php echo esc_attr($select_class);?>">
                        <option value=""><?php esc_html_e('Search All','storefy');?></option>
<?php 
foreach ((array)$post_types as $post_type) {
          $post_type_object=get_post_type_object($post_type);

          if($post_type_object->public){
            $label = $post_type_object->labels->name;
            if($post_type_object->name=='product'){ $label= esc_html__('Product','storefy');}
            print "<option value=\"".$post_type."\"".($post_type==$post_type_selected?" selected=\"selected\"":"").">".$label."</option>";
          }
}
?>
                      </select>
<?php
}

add_filter( 'the_title', 'storefy_fix_post_title');


if(get_option( 'db_version' ) >= 34370 ){
  require_once( get_template_directory().'/lib/taxonomy-banner.php'); 
}
?>
<?php

defined('ABSPATH') or die();

/**

 *

 * @package WordPress

 * @subpackage Storefy

 * @since Storefy 1.0

 */



$footertext=function_exists('icl_t') ? icl_t('storefy', 'footer-text', get_storefy_option('footer-text','')):get_storefy_option('footer-text','');





?>

<footer class="" style="padding:0;" vertical_menu_container":"";?>">
	<div style="width: 100%">

<div class="container footer-section">

		<?php if((!empty($footertext) || strlen(strip_tags($footertext)) > 1) && get_storefy_option('showfooterwidget') && is_active_sidebar( 'sidebar-bottom' )){?> 

		<div class="col-md-12<?php print get_storefy_option('dt-footer-position')=='right' ? "":"";?> col-sm-12 col-xs-12 footer-right">

			<div id="footer-right">

				<?php 

				dynamic_sidebar('sidebar-bottom');

				do_action('dynamic_sidebar_sidebar-bottom');

				 ?>

			</div>

		</div>			

		<div class="col-md-12<?php print get_storefy_option('dt-footer-position')=='right' ? "":";?> col-sm-12 col-xs-12 footer-left">

			<div id="footer-left">

				<?php echo do_shortcode($footertext); ?>

			</div>

		</div>

		<?php }

		elseif((!empty($footertext) || strlen(strip_tags($footertext)) > 1) && (!get_storefy_option('showfooterwidget') || !is_active_sidebar( 'sidebar-bottom' )))

		{

		?> 

		<div class="col-md-12 footer-left equal-height">

			<div id="footer-left">

				<?php echo do_shortcode($footertext); ?>

			</div>

		</div>	

		<?php 

		}

		elseif(get_storefy_option('showfooterwidget') && is_active_sidebar( 'sidebar-bottom' )){

			?>

		<div class="col-md-12 footer-right equal-height">

			<div id="footer-right">

				<?php dynamic_sidebar('sidebar-bottom');

				do_action('dynamic_sidebar_sidebar-bottom');

				 ?>

			</div>

		</div>	

		<?php

		 }

		?>

</div>
</div>
</footer>
<?php
defined('ABSPATH') or die();
/**
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */
?>
<div class="main-navigation-container">
<?php

$after_menu=array();

if(storefy_plugin_is_active('woocommerce/woocommerce.php')) {

  if(function_exists('WC') && get_storefy_option( 'show-header-shoppingcart',false)){

    $cart_count= WC()->cart->get_cart_contents_count() ? WC()->cart->get_cart_contents_count() : 0;

    $after_menu[]='<li id="menu-item-cart" class="menu-item cart-menu" style="margin-right:20px; margin-top: 6px;">
                      <a href="/cart" title="Shopping Cart">
<span>
<img src="/wp-content/uploads/2018/12/shop-png-black-and-white-logo-512.png" style="width: 25px;max-width: 25px;"/>
<span class="item-count-container"><span class="item_count">'.$cart_count.'</span></span></span></a>
                      <div class="sub-menu woocommerce">
                        <div class="cart-popup"><div class="widget_shopping_cart_content"></div></div>
                      </div>
                    </li>';
  }

  if(storefy_plugin_is_active('detheme-woocommerce-scarcity/wc-scarcity.php')){

    if(wooscarcity_get_setting('catalog_mode')) $after_menu=array();

    if(wooscarcity_get_setting('enable_product_compare')){

      $compare_link=wooscarcity_get_compare_link_page();
      $compare_count = wooscarcity_get_compare_count();

      $after_menu[]='<li id="menu-item-compare" class="menu-item compare-menu">
                      <a href="'.esc_url($compare_link).'"><span><i class="storefy-shuffle"></i><span class="item-count-container"><span class="item_count">'.$compare_count.'</span></span></span></a>
                    </li>';

    }

    if(wooscarcity_get_setting('enable_wishlist')){

      $wishlist_link=wooscarcity_get_wishlist_link_page();
      $wish_count=wooscarcity_get_wishlist_count();

      $after_menu[]='<li id="menu-item-wishlist" class="menu-item wishlist-menu">
                      <a href="'.esc_url($wishlist_link).'"><span><i class="storefy-product-wishlist"></i><span class="item-count-container"><span class="item_count">'.$wish_count.'</span></span></span></a>
                    </li>';
    }

  }

}

$right_menu=(count($after_menu)) ? "<ul class=\"main-menu-right\">".implode('', $after_menu)."</ul>":"";

  $menuParams = array(
        'theme_location' => 'primary',
        'echo' => false,
        'container_class'=> 'main-menu-container',
        'container_id'=>'main-menu',
        'menu_class'=>'main-menu',
        'container'=>'ul',
        'before' => '',
        'after' => '',
        'fallback_cb'=>false,
        'nav_menu_item_id'=>'main-menu-item-',
        'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
        'walker'  => new storefy_mainmenu_walker()
  );


  if(!$menu = wp_nav_menu($menuParams)){
    $menuParams['fallback_cb']='wp_page_menu';
    $menuParams['walker']= new storefy_page_menu_walker();
    //$menuParams['after']= "</ul>";
    $menu=wp_nav_menu($menuParams);
  }

if($menu && !is_wp_error($menu)){?>
<div class="col">
	<div class="main-menu-container">
    <a class="toggle-main-menu" href="" onclick="javascript:;">
 <div class="menu-btn" id="menu-btn" style="padding-top:20px; padding-left: 20px;">
	<div></div>
	<span></span>
	<span></span>
	<span></span>
     </div>
    </a>
    <div class="main-menu-wrapper">
      <a class="toggle-mobile-menu" href="" onclick="javascript:;">
        <span class="close-bar">
          <span></span>
          <span></span>
        </span>
      </a>
      <?php print $menu;?>
	    </div>
</div>
	</div>
	
	
	
	
<?php
    }
?>
	<div class="col search-form hidden-xs hidden-sm hidden-md">
	            <div class="heading-search" style="width:20em">

            <form method="get" class="heading-search-form" style="margin-left:0px !important; action="<?php print esc_url( home_url( '/' ) );?>">

                    <div class="form-group" style="border-right:none; display: flex; margin-top: 12px; margin-bottom:0px;">

                    <?php

                    if(get_storefy_option('dt-post-type-search')){

                      storefy_search_options();

                    }

                    ?>

                      <input style="background-color:#224875;    border: 1px solid white;
    border-radius: 10px; color:white;" type="search" class="form-control search-field" placeholder="<?php esc_attr_e('Search','storefy');?>" value="<?php print get_search_query();?>" name="s" title="<?php print esc_attr_x( 'Search for:', 'label','storefy' );?>" />

<input type="submit" id="searchsubmit" value="" class="banner-text-btn" style="background:url(wp-content/uploads/2018/12/output-onlinepngtools.png)no-repeat;border:0px;width: 30px;margin-top: 5px;margin-left: -30px;"/>
                    </div>

                    <input type="hidden" class="searchsubmit" value="<?php print esc_attr_x( 'Search', 'submit button', 'storefy' );?>" />

             </form>

            </div>
	</div>
	<div class="col" style="position: relative; margin-right: 10px;">
<?php print $right_menu;?>
	</div>
	
	
</div>
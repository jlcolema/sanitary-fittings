<?php
// remove wp version number from scripts and styles
function remove_css_js_version( $src ) {
    if( strpos( $src, '?ver=' ) )
        $src = remove_query_arg( 'ver', $src );
    return $src;
}
add_filter( 'style_loader_src', 'remove_css_js_version', 9999 );
defined('ABSPATH') or die();
//2021-12-16 JDZ BEGIN
//default checkout state
add_filter( 'default_checkout_billing_state', 'change_default_checkout_state' );
add_filter( 'default_checkout_shipping_state', 'change_default_checkout_state' );
function change_default_checkout_state() {
    return ''; //set state code if you want to set it otherwise leave it blank.
}
//2021-12-16 JDZ END
/**
 * Hide shipping rates when free shipping is available.
 * Updated to support WooCommerce 2.6 Shipping Zones.
 *
 * @param array $rates Array of rates found for the package.
 * @return array
 */
function my_hide_shipping_when_free_is_available( $rates ) {
	$free = array();
	foreach ( $rates as $rate_id => $rate ) {
		if ( 'free_shipping' === $rate->method_id ) {
			$free[ $rate_id ] = $rate;
			break;
		}
	}
	return ! empty( $free ) ? $free : $rates;
}
//jdz 02/02/2021 BEGIN
add_filter('ep_admin_wp_query_integration', 
function( $integrate ) {
 if ( isset( $_GET['post_type'] ) && 'shop_order' === $_GET['post_type'] ) {
 return false;
        }
 return $integrate;
    },
 15
);
//jdz 02/02/2021 END
add_filter( 'woocommerce_package_rates', 'my_hide_shipping_when_free_is_available', 100 );
//JDZ 02/21/2018 BEGIN
add_filter( 'woocommerce_subcategory_count_html', 'jk_hide_category_count' );
function jk_hide_category_count() {
	// No count
}
//JDZ 03/25/2018 BEGIN
// check for empty-cart get param to clear the cart
add_action( 'init', 'woocommerce_clear_cart_url' );
function woocommerce_clear_cart_url() {
	global $woocommerce;
	
	if ( isset( $_GET['empty-cart'] ) ) {
		$woocommerce->cart->empty_cart(); 
	}
}
add_filter( 'woocommerce_product_tabs', 'wcs_woo_remove_reviews_tab', 98 );
function wcs_woo_remove_reviews_tab($tabs) {
    unset( $tabs['additional_information'] );  	// Remove the additional information tab
    return $tabs;
}
// Display 24 products per page. Goes in functions.php
//add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 20;' ), 20 //);
// Change the Number of WooCommerce Products Displayed Per Page
add_filter( 'loop_shop_per_page', 'lw_loop_shop_per_page', 30 );
function lw_loop_shop_per_page( $products ) {
 $products = 16;
 return $products;
}
/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function shapely_widgets_init() {
	
	register_sidebar(array(
		'id'            => 'footer-widget-new',
		'name'          =>  esc_html__( 'Footer Widget', 'storefy' ),
		'description'   =>  esc_html__( 'Used for footer widget area', 'storefy' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s col-lg-3 col-md-3 col-sm-3">',
		'after_widget'  => '</div>',
		'before_title'  => '<h5 class="widget-title h5">',
		'after_title'   => '</h5>',
	));
}
add_action( 'widgets_init', 'shapely_widgets_init' );
/*6/11/2017 code for product gallery*/
add_action( 'after_setup_theme', 'yourtheme_setup' );
function yourtheme_setup() {
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
}
/** Disable Ajax Call from WooCommerce */
add_action( 'wp_enqueue_scripts', 'dequeue_woocommerce_cart_fragments', 11); 
function dequeue_woocommerce_cart_fragments() { if (!is_woocommerce() || is_product_category()) wp_dequeue_script('wc-cart-fragments'); }
//NO EMOJIS
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
/**
 * @snippet       Remove Variable Product Prices Everywhere
 * @how-to        Watch tutorial @ https://businessbloomer.com/?p=19055
 * @sourcecode    https://businessbloomer.com/disable-variable-product-price-range-woocommerce/
 * @author        Rodolfo Melogli
 * @compatible    WooCommerce 2.4.7
 */
add_filter( 'woocommerce_variable_sale_price_html', 'vi_remove_variation_price', 10, 2 );
add_filter( 'woocommerce_variable_price_html', 'vi_remove_variation_price', 10, 2 );
function vi_remove_variation_price( $price ) {
	$price = '';
	return $price;
}
add_action( 'woocommerce_product_after_variable_attributes', 'variation_settings_fields', 10, 3 );
// Save Variation Settings
add_action( 'woocommerce_save_product_variation', 'save_variation_settings_fields', 10, 2 );
/**
 * Create new fields for variations
 *
*/
function variation_settings_fields( $loop, $variation_data, $variation ) {
	// Text Field
	woocommerce_wp_text_input( 
		array( 
			'id'          => '_text_field[' . $loop . ']', 
			'label'       => __( 'Availability', 'woocommerce' ), 
			'placeholder' => 'Usually In Stock',
			'desc_tip'    => 'true',
			'description' => __( 'Enter product availability here.', 'woocommerce' ),
			'value'       => get_post_meta( $variation->ID, '_text_field', true )
		)
	);
	
	woocommerce_wp_text_input( 
			array(
		'id' => 'steel_no[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Item No.', 'woocommerce' ),
		'placeholder' => 'Item No',
		'desc_tip'    => 'true',
		'description' => __( 'Enter ERP Item No for WooCommerce Import here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'steel_no', true )
		)
	);
	woocommerce_wp_text_input( 
		array(
		'id' => 'sanitary_size[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Sanitary Size', 'woocommerce' ),
		'placeholder' => 'Sanitary Size',
		'desc_tip'    => 'true',
		'description' => __( 'Enter product sanitary size here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'sanitary_size', true )
		)
	);
	woocommerce_wp_text_input( 
			array(
		'id' => 'flange_od[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Flange OD', 'woocommerce' ),
		'placeholder' => 'Flange OD',
		'desc_tip'    => 'true',
		'description' => __( 'Enter product flange od here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'flange_od', true )
		)
	);
		woocommerce_wp_text_input( 
			array(
		'id' => 'tube_id[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Tube ID', 'woocommerce' ),
		'placeholder' => 'Tube ID',
		'desc_tip'    => 'true',
		'description' => __( 'Enter product Tube ID here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'tube_id', true )
		)
	);
		woocommerce_wp_text_input( 
			array(
		'id' => 'material[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Material', 'woocommerce' ),
		'placeholder' => 'Material',
		'desc_tip'    => 'true',
		'description' => __( 'Enter product material here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'material', true )
		)
	);
		woocommerce_wp_text_input( 
			array(
		'id' => 'for_hose_id[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'For Hose Id', 'woocommerce' ),
		'placeholder' => 'For Hose Id',
		'desc_tip'    => 'true',
		'description' => __( 'Enter product for hose id here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'for_hose_id', true )
		)
	);
		woocommerce_wp_text_input( 
			array(
		'id' => 'pipe_size_length[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Pipe Size Length', 'woocommerce' ),
		'placeholder' => 'Pipe Size Length',
		'desc_tip'    => 'true',
		'description' => __( 'Enter product for pipe size length here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'pipe_size_length', true )
		)
	);
		woocommerce_wp_text_input( 
			array(
		'id' => 'drawing_url[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Drawing url', 'woocommerce' ),
		'placeholder' => 'Drawing url',
		'desc_tip'    => 'true',
		'description' => __( 'Enter product for drawing url here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'drawing_url', true )
		)
	);
	
	woocommerce_wp_text_input(
        array(
            'id' => 'drawing_sort_order[' . $loop . ']',
            'class' => 'custom_attributes',
            'label' => __( 'Drawing Sort Order', 'woocommerce' ),
            'placeholder' => 'Drawing Sort Order',
            'desc_tip'    => 'true',
            'description' => __( 'Enter sort order for drawing url here.', 'woocommerce' ),
            'value' => get_post_meta( $variation->ID, 'drawing_sort_order', true )
        )
    );
	
	
/**
*JDZ BEGIN
*/
woocommerce_wp_text_input( 
			array(
		'id' => 'specification[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Specifications Met', 'woocommerce' ),
		'placeholder' => 'Specifications Met',
		'desc_tip'    => 'true',
		'description' => __( 'Enter specifications met here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'specification', true )
		)
	);
woocommerce_wp_text_input( 
			array(
		'id' => 'certification[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Certification', 'woocommerce' ),
		'placeholder' => 'Certification',
		'desc_tip'    => 'true',
		'description' => __( 'Enter certification here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'certification', true )
		)
	);
woocommerce_wp_text_input( 
			array(
		'id' => 'wall_thickness[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Wall Thickness', 'woocommerce' ),
		'placeholder' => 'Wall Thickness',
		'desc_tip'    => 'true',
		'description' => __( 'Enter wall thickness here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'wall_thickness', true )
		)
	);
woocommerce_wp_text_input( 
			array(
		'id' => 'surface_finish[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Surface Finish', 'woocommerce' ),
		'placeholder' => 'Surface Finish',
		'desc_tip'    => 'true',
		'description' => __( 'Enter surface finish here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'surface_finish', true )
		)
	);
	
woocommerce_wp_text_input( 
			array(
		'id' => 'pressure_rating[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Pressure Rating', 'woocommerce' ),
		'placeholder' => 'Pressure Rating',
		'desc_tip'    => 'true',
		'description' => __( 'Enter pressure rating here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'pressure_rating', true )
		)
	);
woocommerce_wp_text_input( 
			array(
		'id' => 'temperature_rating[' . $loop . ']',
		'class' => 'custom_attributes',
		'label' => __( 'Temperature Rating', 'woocommerce' ),
		'placeholder' => 'Temperature Rating',
		'desc_tip'    => 'true',
		'description' => __( 'Enter temperature rating here.', 'woocommerce' ),
		'value' => get_post_meta( $variation->ID, 'temperature_rating', true )
		)
	);
/**
*JDZ END
*/
}
/**
 * Save new fields for variations
 *
*/
function save_variation_settings_fields( $variation_id, $i) {
	//Availability field
	$text_field = $_POST['_text_field'][$i];
	if( isset( $text_field ) ) {
		update_post_meta( $variation_id, '_text_field', sanitize_text_field( $text_field ) );
	}
	$sanitary_size = $_POST['sanitary_size'][$i];
	if( isset( $sanitary_size ) ) {
		update_post_meta( $variation_id, 'sanitary_size', sanitize_text_field( $sanitary_size ) );
	}
	$flange_od = $_POST['flange_od'][$i];
	if( isset( $flange_od ) ) {
		update_post_meta( $variation_id, 'flange_od', sanitize_text_field( $flange_od ) );
	}
	
	$tube_id = $_POST['tube_id'][$i];
	if( isset( $tube_id ) ) {
		update_post_meta( $variation_id, 'tube_id', sanitize_text_field( $tube_id ) );
	}
	
	$material = $_POST['material'][$i];
	if( isset( $material ) ) {
		update_post_meta( $variation_id, 'material', sanitize_text_field( $material ) );
	}
	$for_hose_id = $_POST['for_hose_id'][$i];
	if( isset( $for_hose_id ) ) {
		update_post_meta( $variation_id, 'for_hose_id', sanitize_text_field( $for_hose_id ) );
	}
	$pipe_size_length = $_POST['pipe_size_length'][$i];
	if( isset( $pipe_size_length ) ) {
		update_post_meta( $variation_id, 'pipe_size_length', sanitize_text_field( $pipe_size_length ) );
	}
	
	$drawing_url = $_POST['drawing_url'][$i];
	if( isset( $drawing_url ) ) {
		update_post_meta( $variation_id, 'drawing_url', sanitize_text_field( $drawing_url ) );
	}
	
	$drawing_sort_order = $_POST['drawing_sort_order'][$i];
    if( isset( $drawing_sort_order ) ) {
        update_post_meta( $variation_id, 'drawing_sort_order', sanitize_text_field( $drawing_sort_order ) );
    }
	
	$steel_no = $_POST['steel_no'][$i];
	if( isset( $steel_no ) ) {
		update_post_meta( $variation_id, 'steel_no', sanitize_text_field( $steel_no ) );
	}
/**
*JDZ BEGIN
*/
$specification = $_POST['specification'][$i];
	if( isset( $specification ) ) {
		update_post_meta( $variation_id, 'specification', sanitize_text_field( $specification ) );
	}
	
$certification = $_POST['certification'][$i];
	if( isset( $certification ) ) {
		update_post_meta( $variation_id, 'certification', sanitize_text_field( $certification ) );
	}
	
$wall_thickness = $_POST['wall_thickness'][$i];
	if( isset( $wall_thickness ) ) {
		update_post_meta( $variation_id, 'wall_thickness', sanitize_text_field( $wall_thickness ) );
	}
$surface_finish = $_POST['surface_finish'][$i];
	if( isset( $surface_finish ) ) {
		update_post_meta( $variation_id, 'surface_finish', sanitize_text_field( $surface_finish ) );
	}
	
$pressure_rating = $_POST['pressure_rating'][$i];
if( isset( $pressure_rating ) ) {
update_post_meta( $variation_id, 'pressure_rating', sanitize_text_field( $pressure_rating ) );
}
$temperature_rating = $_POST['temperature_rating'][$i];
if( isset( $temperature_rating ) ) {
update_post_meta( $variation_id, 'temperature_rating', sanitize_text_field( $temperature_rating ) );
}
/**
*JDZ END
*/
	
}
// Add New Variation Settings
add_filter( 'woocommerce_available_variation', 'load_variation_settings_fields' );
/**
 * Add custom fields for variations
 *
*/
function load_variation_settings_fields( $variations ) {
	// duplicate the line for each field
	$variations['text_field'] = get_post_meta( $variations['variation_id'], '_text_field', true );
	$variations['sanitary_size'] = get_post_meta( $variations['variation_id'], 'sanitary_size', true );
	$variations['flange_od'] = get_post_meta( $variations['variation_id'], 'flange_od', true );
	$variations['tube_id'] = get_post_meta( $variations['variation_id'], 'tube_id', true );
	$variations['material'] = get_post_meta( $variations['variation_id'], 'material', true );
	$variations['for_hose_id'] = get_post_meta( $variations['variation_id'], 'for_hose_id', true );
	$variations['pipe_size_length'] = get_post_meta( $variations['variation_id'], 'pipe_size_length', true );
	$variations['drawing_url'] = get_post_meta( $variations['variation_id'], 'drawing_url', true );
	
	$variations['drawing_sort_order'] = get_post_meta( $variations['variation_id'], 'drawing_sort_order', true );
	
		$variations['steel_no'] = get_post_meta( $variations['variation_id'], 'steel_no', true );
/**
*JDZ BEGIN
*/
	$variations['specification'] = get_post_meta( $variations['variation_id'], 'specification', true );
	$variations['certification'] = get_post_meta( $variations['variation_id'], 'certification', true );
	$variations['wall_thickness'] = get_post_meta( $variations['variation_id'], 'wall_thickness', true );
	$variations['surface_finish'] = get_post_meta( $variations['variation_id'], 'surface_finish', true );
	
	$variations['pressure_rating'] = get_post_meta( $variations['variation_id'], 'pressure_rating', true );
	
	$variations['temperature_rating'] = get_post_meta( $variations['variation_id'], 'temperature_rating', true );
/**
*JDZ END
*/
	
	return $variations;
}
/* Add Show All Products to Woocommerce Shortcode */
function woocommerce_shortcode_display_all_products($args)
{
	if(strtolower(@$args['post__in'][0])=='all')
	{
		global $wpdb;
		$args['post__in'] = array();
		$products = $wpdb->get_results("SELECT ID FROM ".$wpdb->posts." WHERE `post_type`='product'",ARRAY_A);
		foreach($products as $k => $v) { $args['post__in'][] = $products[$k]['ID']; }
	}
	return $args;
}
add_filter('woocommerce_shortcode_products_query', 'woocommerce_shortcode_display_all_products');
//Require Company Name
function sv_require_wc_company_field( $fields ) {
	$fields['company']['required'] = true;
	return $fields;
}
add_filter( 'woocommerce_default_address_fields', 'sv_require_wc_company_field' );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
//JDZ 20180419 END
/* Virtina - 11/02/2020 */
/* Start */
function vi_load_vc_nav_buttons() {
	print '<div class="navigation_button_item navigation_active"><i class="icon-phone"></i><div class="text-box"><div class="navigation-label">(800) 270-8926</div><div class="navigation-text">Mon-Fri 8-5 CST</div></div></div>';
}
add_shortcode('vi-products', 'viProducts');
function viProducts(){
	ob_start();
	$products = array(
		'post_type' => 'product',
		'showposts' => 4
	);
	$fQuery = new WP_Query( $products );
	if($fQuery->have_posts()){
		echo '<div class="products row banner-products">';
		while($fQuery->have_posts()){
			$fQuery->the_post();?>
			<div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
				<div class="item-product">
					<a href="<?php echo get_permalink()?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
						<h2 class="woocommerce-loop-product__title"><?php the_title(); ?></h2>
						<div class="featured-image"><?php the_post_thumbnail('woocommerce_thumbnail'); ?></div>
					</a>
					<p><?php echo get_post_meta(get_the_ID(), 'vi_blurb', true); ?></p>
					<a href="<?php echo get_permalink()?>" class="btn btn-primary" data-product_id="17002" data-product_sku="" rel="nofollow">View Details</a>
				</div>
			</div>
			<?php
		}
		echo '</div>';
	}
	return ob_get_clean();
}
function vi_register_meta_boxes() {
	add_meta_box( 'vi-1', __( 'Blurb', 'vi' ), 'vi_display_callback', 'product' );
}
add_action( 'add_meta_boxes', 'vi_register_meta_boxes' );
function vi_display_callback( $post ) {
	echo '<p class="meta-options vi_field">
	<textarea id="vi_blurb" type="text" name="vi_blurb" rows="20" autocomplete="off" cols="40">'.get_post_meta(get_the_ID(), 'vi_blurb', true).'</textarea>
	</p>';
}
function vi_save_meta_box( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( $parent_id = wp_is_post_revision( $post_id ) ) {
		$post_id = $parent_id;
	}
	update_post_meta( $post_id, 'vi_blurb', sanitize_text_field( $_POST['vi_blurb'] ) );
}
add_action( 'save_post', 'vi_save_meta_box' );
function vi_enqueue_script() {
	wp_enqueue_script( 'custom-script', get_template_directory_uri() . '_child/assets/scripts.js', array(), '1.0.2', true );
	wp_enqueue_script( 'cart-qty', get_template_directory_uri() . '_child/assets/cart-qty-lk_.js', array(), '1.0.1', true );
	wp_enqueue_style( 'child-style', get_template_directory_uri() . '_child/style.css', array(), '1.4', 'all');
	wp_enqueue_style( 'icons-style', get_template_directory_uri() . '_child/assets/style.css');
	wp_enqueue_style( 'icons-style', get_template_directory_uri()  . '/style.css', array(), '6.0', 'all');
	wp_enqueue_style( 'icons-style', get_stylesheet_uri() , array(), filemtime(get_stylesheet_uri() ), 'all');
	wp_enqueue_style( 'lightbox-style', get_template_directory_uri()  . '_child/assets/lightbox.min.css', array(), '1.0', 'all');
	wp_enqueue_script( 'lightbox-script', get_template_directory_uri() . '_child/assets/lightbox.min.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'vi_enqueue_script' );
add_filter('loop_shop_columns', 'loop_columns', 999);
if (!function_exists('loop_columns')) {
	function loop_columns() {
		return 4; // 4 products per row
	}
}
if ( ! function_exists( 'storefy_breadcrumb' ) ) {
    function storefy_breadcrumb(){
        if(function_exists('woocommerce_breadcrumb') && !is_cart() && !is_checkout()){
          $wc_breadcrumb_args = array(
            'delimiter' => '<span class="icon-arrow-right"></span>',
            'wrap_before' => '<section class="section-breadcrumbs"><div class="container"><div class="breadcrumbs" dir="ltr">',
            'wrap_after' => '</div></div></section>',
            'before' => '<span>',
            'beforecurrent' => '<span class="current">',
            'after' => '</span>',
            'home' => esc_html__( 'Home', 'woocommerce' ),
          );
          woocommerce_breadcrumb($wc_breadcrumb_args);
        }
    }
}
add_filter( 'woocommerce_product_tabs', 'woo_remove_product_tabs', 98 );
function woo_remove_product_tabs( $tabs ) {
    unset( $tabs['description'] );      	// Remove the description tab
    return $tabs;
}
add_filter( 'woocommerce_reviews_title', 'lk_reviews_heading', 10, 3 );
function lk_reviews_heading( $heading, $count, $product ){
 
	return $heading.'<span>'.$count.'</span>';
 
}
add_action('woocommerce_before_single_product', 'show_title_mob');
function show_title_mob(){
	echo '<div class="container"><h2 class="hidden-lg hidden-md hidden-sm product-mob-title">'.get_the_title().'</h2></div>';
}
add_action('woocommerce_proceed_to_checkout', 'custom_proceed_copy');
function custom_proceed_copy(){
	echo '<p class="text-left">' . __('Enter your address in the next step to view shipping options.') . '</p>';
}
function filter_woocommerce_checkout_fields( $fields, $int='' ) {
	//print_r($fields['shipping']) ;
    // make filter magic happen here... 
    $fields['billing']['billing_company']['class'] = array( 'form-row-first' );
    $fields['billing']['billing_country']['class'] = array( 'form-row-last' );
    $fields['billing']['billing_address_1']['class'] = array( 'form-row-first', 'address-field', 'clear' );
    $fields['billing']['billing_address_2']['class'] = array( 'form-row-last', 'address-field' );
    $fields['billing']['billing_phone']['class'] = array( 'form-row-first', 'clear' );
    $fields['billing']['billing_email']['class'] = array( 'form-row-last' );
    $fields['billing']['billing_state']['class'] = array( 'form-row-first' );
    $fields['billing']['billing_postcode']['class'] = array( 'form-row-last' );
    $fields['shipping']['shipping_company']['class'] = array( 'form-row-first' );
    $fields['shipping']['shipping_country']['class'] = array( 'form-row-last' );
    $fields['shipping']['shipping_address_1']['class'] = array( 'form-row-first', 'address-field', 'clear' );
    $fields['shipping']['shipping_address_2']['class'] = array( 'form-row-last', 'address-field' );
    $fields['shipping']['shipping_phone']['class'] = array( 'form-row-first', 'clear' );
    $fields['shipping']['shipping_email']['class'] = array( 'form-row-last' );
    $fields['shipping']['shipping_state']['class'] = array( 'form-row-first' );
    $fields['shipping']['shipping_postcode']['class'] = array( 'form-row-last' );
    $fields['billing']['billing_address_2']['placeholder'] = 'Apartment, suite, unit, etc. (opt.)';
    $fields['shipping']['shipping_address_2']['placeholder'] = 'Apartment, suite, unit, etc. (opt.)';
    return $fields;
}
         
// add the filter 
add_filter( 'woocommerce_checkout_fields', 'filter_woocommerce_checkout_fields', 10, 2 ); 
add_filter( 'the_title', 'woo_title_order_received', 10, 2 );
function woo_title_order_received( $title, $id ) {
	if ( function_exists( 'is_order_received_page' ) && is_order_received_page() && get_the_ID() === $id ) {
		$title = "Thank you for your order";
	}
	return $title;
}
add_shortcode('hoseconnections', 'hoseconnections');
function hoseconnections(){
	ob_start();
	echo '<h3>Available Hose Connections Styles</h3>
<ul>
<li>90-Degree Tri-Clamp Elbow</li>
<li>Bevel Seat - Plain w/ Nut</li>
<li>Bevel Seat Nut</li>
<li>Camlock Female</li>
<li>Compression Tube</li>
<li>Electropolished Tri-Clamp</li>
<li>Flange End</li>
<li>I-Line Male</li>
<li>I-Line Female</li>
<li>Male NPT Thread</li>
<li>Tri-Clamp</li>
</ul>';
	return ob_get_clean();
}
add_shortcode('sizing', 'sizing');
function sizing(){
	ob_start();
	
	echo '<br/><h3 id="SizeDim" class="h3desc" style="margin-top:30px;">Watch How to Measure Tri-Clamp Fittings</h3>
<a href="https://youtu.be/qOOeZhMKZiQ" target="_blank" title="How To Measure Sanitary Fittings"><img src="https://sanitaryfittings.us/wp-content/uploads/2020/06/you-tube-thumb-min.png" width="540" /></a>
<h3 class="h3desc" id="sizingGuide" style="margin-top:30px;">Tri-Clamp Fittings and Gasket Sizing Guide</h3><img width="400" src="https://sanitaryfittings.us/wp-content/uploads/2018/01/SanitaryFittings_Dimensions-Image.png" class="image wp-image-8077  attachment-full size-full size_flange" alt="Sanitary Fitting Dimensions" style="height: auto; margin-top:20px;" srcset="https://sanitaryfittings.us/wp-content/uploads/2018/01/SanitaryFittings_Dimensions-Image.png 1079w, https://sanitaryfittings.us/wp-content/uploads/2018/01/SanitaryFittings_Dimensions-Image-300x111.png 300w, https://sanitaryfittings.us/wp-content/uploads/2018/01/SanitaryFittings_Dimensions-Image-768x285.png 768w, https://sanitaryfittings.us/wp-content/uploads/2018/01/SanitaryFittings_Dimensions-Image-1024x380.png 1024w" sizes="(max-width: 1079px) 100vw, 1079px">
	<style>
		th.size_th{background:#fff !important; color: #444444 !important; border-left: 0 !important; border-top: 0 !important; border-right: 0 !important; border-bottom: 2px solid #2574bc !important;}
		th.size_th_first{background:#f5f5f5 !important; color: #444444 !important; border-left: 0 !important; border-top: 0 !important; border-right: 0 !important; border-bottom: 2px solid #2574bc !important;}
		td.size_td {text-align: center; border-left: 0 !important; border-top: 0 !important; border-right: 0 !important; border-bottom: 1px solid #e8e8e8 !important; color: #444444;}
		td.size_td_first {text-align: center; font-weight: bold; background:#f5f5f5; color: #444444; border-left: 0 !important; border-top: 0 !important; border-right: 0 !important; border-bottom: 1px solid #e8e8e8 !important; color: #444444;}
		.size_table{margin-top:20px;}
		.size_flange{max-width:480px !important;}
		@media only screen and (max-width:450px){.size_table{margin-top:20px;width:80%;}
		th.size_th{padding:10px 20px !important;}
		th.size_th_first{padding:10px 20px !important;}
		.size_flange{max-width:325px !important;}
		}
	</style>
	<table class="size_table">
		<tbody>
			<tr>
				<th class="size_th_first"><strong>Sanitary Size</strong></th>
				<th class="size_th">Flange OD (<a href="https://sanitaryfittings.us/wp-content/uploads/2022/02/tri-clamp-flange-OD-1.png" target="_blank" title="Tri-Clamp Flange Outside Diameter Example"> ? </a>)</th>
				<th class="size_th">ID of Tube (<a href="https://sanitaryfittings.us/wp-content/uploads/2022/02/tube-inside-diameter.png" target="_blank" title="Tubing Inside Diameter Example"> ? </a>)</th>
				<th class="size_th">OD of Tube  (<a href="https://sanitaryfittings.us/wp-content/uploads/2022/02/tube-outside-diameter.png" target="_blank" title="Tubing Outside Diameter Example"> ? </a>)</th>
			</tr>
			<tr>
				<td class="size_td_first">1/2″</td>
				<td class="size_td">0.984</td>
				<td class="size_td">0.370</td>
				<td class="size_td">0.500</td>
			</tr>
			<tr>
				<td class="size_td_first">3/4″</td>
				<td class="size_td">0.984</td>
				<td class="size_td">0.620</td>
				<td class="size_td">0.750</td>
			</tr>
			<tr>
				<td class="size_td_first">1″</td>
				<td class="size_td">1.984</td>
				<td class="size_td">0.870</td>
				<td class="size_td">1.000</td>
			</tr>
			<tr>
				<td class="size_td_first">1 1/2″</td>
				<td class="size_td">1.984</td>
				<td class="size_td">1.370</td>
				<td class="size_td">1.500</td>
			</tr>
			<tr>
				<td class="size_td_first">2″</td>
				<td class="size_td">2.516</td>
				<td class="size_td">1.870</td>
				<td class="size_td">2.000</td>
			</tr>
			<tr>
				<td class="size_td_first">2 1/2″</td>
				<td class="size_td">3.047</td>
				<td class="size_td">2.370</td>
				<td class="size_td">2.500</td>
			</tr>
			<tr>
				<td class="size_td_first">3″</td>
				<td class="size_td">3.579</td>
				<td class="size_td">2.870</td>
				<td class="size_td">3.000</td>
			</tr>
			<tr>
				<td class="size_td_first">4″</td>
				<td class="size_td">4.682</td>
				<td class="size_td">3.834</td>
				<td class="size_td">4.000</td>
			</tr>
			<tr>
				<td class="size_td_first">6″</td>
				<td class="size_td">6.570</td>
				<td class="size_td">5.782</td>
				<td class="size_td">6.000</td>
			</tr>
			<tr>
				<td class="size_td_first">8″</td>
				<td class="size_td">8.570</td>
				<td class="size_td">7.782</td>
				<td class="size_td">8.000</td>
			</tr>
			<tr>
				<td class="size_td_first">10″</td>
				<td class="size_td">10.570</td>
				<td class="size_td">9.782</td>
				<td class="size_td">10.000</td>
			</tr>
			<tr>
				<td class="size_td_first">12″</td>
				<td class="size_td">12.570</td>
				<td class="size_td">11.760</td>
				<td class="size_td">12.000</td>
			</tr>
		</tbody>
	</table>
	<h3 style="margin-top:30px;">Frequently Asked Questions</h3>
	Read our guide to <a href="/tri-clamp-fittings-faq" title="Tri-Clamp Fittings FAQ">Frequently Asked Questions about Tri-Clamp Fittings</a>';
	return ob_get_clean();
}
function refresh_checkout_on_payment_methods_change(){
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function(){
            jQuery( 'form.checkout' ).on( 'change', '#billing_state, #billing_postcode, #shipping_state, #shipping_postcode, #billing_country', function() { 
                jQuery('body').trigger('update_checkout');
            });
        });
    </script>
    <?php
}
add_action( 'woocommerce_review_order_before_payment', 'refresh_checkout_on_payment_methods_change' );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
/**
 * Disable WooCommerce block styles (front-end).
 */
function smartwp_remove_wp_block_library_css(){
 wp_dequeue_style( 'wp-block-library' );
 wp_dequeue_style( 'wp-block-library-theme' );
 wp_dequeue_style( 'wc-block-style' ); // Remove WooCommerce block CSS
 wp_dequeue_style( 'photoswipe' );
 wp_dequeue_style( 'photoswipe-default-skin' );
wp_dequeue_script('photoswipe');
wp_dequeue_script('photoswipe-ui-default');
}
add_action( 'wp_enqueue_scripts', 'smartwp_remove_wp_block_library_css', 100 );
function defer_parsing_of_js( $url ) {
    if ( is_user_logged_in() ) return $url; //don't break WP Admin
    if ( FALSE === strpos( $url, '.js' ) ) return $url;
    if ( strpos( $url, 'jquery.js' ) ) return $url;
    return str_replace( ' src', ' defer src', $url );
}
add_filter( 'script_loader_tag', 'defer_parsing_of_js', 10 );
function add_rel_preload($html, $handle, $href, $media) {
    
    if (is_admin()) return $html;
    if ( strpos( $html, 'plugins/woocommerce' ) ) return $html;
     $html = <<<EOT
<link rel='preload' as='style' onload="this.onload=null;this.rel='stylesheet'" id='$handle' href='$href' type='text/css' media='all' />
EOT;
    return $html;
}
add_filter( 'style_loader_tag', 'add_rel_preload', 10, 4 );
add_filter( 'wc_add_to_cart_message', 'virtina_wc_add_to_cart_message', 10, 2 );
/**
 * Add custom HTML to Add to Cart message.
 *
 * @param  string $message    The current message.
 * @param  int    $product_id Single product id.
 * @return string             The modified message.
 */
function virtina_wc_add_to_cart_message( $message, $product_id ) {
	
	$variation_id = $_POST['variation_id'];
	$crosssell_variant_ids = get_post_meta($variation_id,'_crosssell_variant_ids',true);
	$message = '<i class="icon-info"></i>'.$message;
	if(!empty($crosssell_variant_ids)){
	$message .='<div class="flex-container">';
	$message .='<div class="message_title">'.esc_html__( 'Customers Also Bought', 'woocommerce' ).'</div><div class="clear"></div>';	
	foreach ($crosssell_variant_ids as $crosssell_variant_id) {
		
		$product = wc_get_product( $crosssell_variant_id );
		
		$variation_link = get_permalink($crosssell_variant_id);	
		if(!empty($product)){
			$message .= '<div class="product_block"><a href="'.$variation_link.'" class="var_link"><div class="image_box">'.$product->get_image( array( 80, 80 ) ).'</div><div class="title_box">'.$product->get_description().'</div></a></div>';
		}
	}
	$message .='</div>';
	}
	return $message;
}
//Product total 100 label and cost change Free Ground Shipping
function sanitaryfittings_shipping_label_change( $label, $method ) {
	$product_total = WC()->cart->get_subtotal();
	
	if($product_total >= 100){
		if($label === 'Ground (UPS)'){
			return 'Free Ground Shipping';
		}
	}
	return $label;
}
add_filter( 'woocommerce_shipping_rate_label', 'sanitaryfittings_shipping_label_change', 10, 2 );
function sanitaryfittings_shipping_cost_change($cost, $method) {
	$product_total = WC()->cart->get_subtotal();
	
	if($product_total >= 100){
		if($method->get_label() === 'Free Ground Shipping'){
			return '0';
		}
	}
	return $cost;
}
add_filter( 'woocommerce_shipping_rate_cost', 'sanitaryfittings_shipping_cost_change', 10, 2 );
function sanitaryfittings_shipping_packages ($rates, $package){
	$product_total = WC()->cart->get_subtotal();
	if($product_total >= 100){
		if ( isset( $rates['ups:13:03'] ) ) {
			$ground_ups = $rates['ups:13:03'];
			unset($rates['ups:13:03']);
			$rates = array_merge(array('ups:13:03' => $ground_ups), $rates);
			$taxes = array();
            foreach( $rates['ups:13:03']->taxes as $key => $tax_cost ) { 
                $taxes[$key] = 0; // Set each tax to Zero
            }
            if ( ! empty($taxes) ) {
                $rates['ups:13:03']->taxes = $taxes;
            }
	 	}
	}
	return $rates;
}
add_filter( 'woocommerce_package_rates', 'sanitaryfittings_shipping_packages', 99, 2 );
function Add_free_to_shipping_label_for_zero_cost( $label, $method ) {
    $product_total = WC()->cart->get_subtotal();
	
	if($product_total >= 100){
		if ( ! ( $method->cost > 0 ) && $method->method_id !== 'free_shipping' ) {
        	$label .= ': ' . __('$0.00');
    	}
	}
    return $label;
}
add_filter( 'woocommerce_cart_shipping_method_full_label', 'Add_free_to_shipping_label_for_zero_cost', 10, 2 );
function add_custom_ups_button_my_orders( $actions, $order ) {
		//$tracking_items = get_post_meta( 22746, '_wc_shipment_tracking_items', true );
		$tracking_items = get_post_meta( $order->id, '_wc_shipment_tracking_items', true );
		$action_slug = 'ups_tracking_button';
		if ( $tracking_items !== '' ) {
			foreach ( $tracking_items as $tracking_item ) {
				$tracker = esc_html( $tracking_item['tracking_number'] );
			}
			$actions[$action_slug] = array(
				'url'  => "https://wwwapps.ups.com/tracking/tracking.cgi?tracknum=$tracker",
				'name' => "UPS Tracking"
			);
		}
	return $actions;
}
add_filter( 'woocommerce_my_account_my_orders_actions', 'add_custom_ups_button_my_orders', 50, 2 );
add_filter( 'wpo_wcpdf_myaccount_button_text', 'change_my_account_orders_invoice_text', 10, 2 );
function change_my_account_orders_invoice_text( $actions, $order ) {
	return __( 'Invoice', 'woocommerce' ); 
}
add_action( 'woocommerce_after_account_orders', 'custom_ups_action_after_account_orders_js');
function custom_ups_action_after_account_orders_js() {
    $action_slug = 'ups_tracking_button'; ?>
    <script>
		jQuery(function($){
			$('a.<?php echo $action_slug; ?>').each( function(){
				$(this).attr('target','_blank');
			})
		});
    </script> <?php
}
/*Variation table code*/
add_filter( 'woocommerce_product_tabs', 'custom_tabs', 10 );
function custom_tabs( $tabs ) {
    $tabs['line_drawing'] = array(
        'title'     => __( 'Line Drawings', 'woocommerce' ),
        'priority'  => 50,
        'callback'  => 'woo_custom_description_tab_content'
    );
    return $tabs;
}
//add_action( 'woocommerce_after_single_product_summary', 'variation_deb', 10);
function woo_custom_description_tab_content() {
    global $product;
    $id_product = $product->get_id();
    $product = wc_get_product( $id_product );
    if($product->is_type( 'variable' )) {
        $variations = $product->get_available_variations();
        $sanitary_size = array_column($variations, 'sanitary_size');
        $sort_variations = [];
        foreach($variations as $k => $v) {
			$sort_variations[$k]['drawing_sort_order'] = $v['drawing_sort_order'];
            $sort_variations[$k]['sku'] = $v['sku'];
            $sort_variations[$k]['variation_description'] = $v['variation_description'];
            $sort_variations[$k]['drawing_url'] = $v['drawing_url'];
        };
        sort($sort_variations);
    }
    if(!empty($variations)) {
        $html =
            '<div id="product_description" class="et_pb_row row products margin-0 justify-content-between">
                    
                <table class="part-table" style="width:100%">
                    <tr>
                        <th>SKU</th><th>Description</th><th>Line Drawing</th>
                    </tr>';
        foreach ( $sort_variations as $variation ) {
            $URL = $variation['drawing_url'];
            if (str_contains($URL, 'request-line-drawing')) {
                $urlText = 'Request Line Drawing';
            } else{
            	$urlText = 'PDF';
            }
            $html .=
                '<tr>
                    <td style="font-weight:200;">'.$variation['sku'].'</td>
                    <td>'.$variation['variation_description'].'</td>
                    <td><a href="'.$variation['drawing_url'].'" target="_blank">'.$urlText.'</a></td>
                </tr>';
        }
        $html .=
        		'</table>
            </div>';
        echo $html;
    }
}
/* Add Puerto Rico as a State */
add_filter( 'woocommerce_countries', 'wc_remove_pr_country', 10, 1 );
function wc_remove_pr_country ( $country ) {
    unset($country["PR"]);
    return $country;
}
add_filter( 'woocommerce_states', 'wc_us_states_mods' );
function wc_us_states_mods ( $states ) {
    $states['US'] = array(
        'AL' => __( 'Alabama', 'woocommerce' ),
        'AK' => __( 'Alaska', 'woocommerce' ),
        'AZ' => __( 'Arizona', 'woocommerce' ),
        'AR' => __( 'Arkansas', 'woocommerce' ),
        'CA' => __( 'California', 'woocommerce' ),
        'CO' => __( 'Colorado', 'woocommerce' ),
        'CT' => __( 'Connecticut', 'woocommerce' ),
        'DE' => __( 'Delaware', 'woocommerce' ),
        'DC' => __( 'District Of Columbia', 'woocommerce' ),
        'FL' => __( 'Florida', 'woocommerce' ),
        'GA' => _x( 'Georgia', 'US state of Georgia', 'woocommerce' ),
        'HI' => __( 'Hawaii', 'woocommerce' ),
        'ID' => __( 'Idaho', 'woocommerce' ),
        'IL' => __( 'Illinois', 'woocommerce' ),
        'IN' => __( 'Indiana', 'woocommerce' ),
        'IA' => __( 'Iowa', 'woocommerce' ),
        'KS' => __( 'Kansas', 'woocommerce' ),
        'KY' => __( 'Kentucky', 'woocommerce' ),
        'LA' => __( 'Louisiana', 'woocommerce' ),
        'ME' => __( 'Maine', 'woocommerce' ),
        'MD' => __( 'Maryland', 'woocommerce' ),
        'MA' => __( 'Massachusetts', 'woocommerce' ),
        'MI' => __( 'Michigan', 'woocommerce' ),
        'MN' => __( 'Minnesota', 'woocommerce' ),
        'MS' => __( 'Mississippi', 'woocommerce' ),
        'MO' => __( 'Missouri', 'woocommerce' ),
        'MT' => __( 'Montana', 'woocommerce' ),
        'NE' => __( 'Nebraska', 'woocommerce' ),
        'NV' => __( 'Nevada', 'woocommerce' ),
        'NH' => __( 'New Hampshire', 'woocommerce' ),
        'NJ' => __( 'New Jersey', 'woocommerce' ),
        'NM' => __( 'New Mexico', 'woocommerce' ),
        'NY' => __( 'New York', 'woocommerce' ),
        'NC' => __( 'North Carolina', 'woocommerce' ),
        'ND' => __( 'North Dakota', 'woocommerce' ),
        'OH' => __( 'Ohio', 'woocommerce' ),
        'OK' => __( 'Oklahoma', 'woocommerce' ),
        'OR' => __( 'Oregon', 'woocommerce' ),
        'PA' => __( 'Pennsylvania', 'woocommerce' ),
        'PR' => __( 'Puerto Rico', 'woocommerce' ),
        'RI' => __( 'Rhode Island', 'woocommerce' ),
        'SC' => __( 'South Carolina', 'woocommerce' ),
        'SD' => __( 'South Dakota', 'woocommerce' ),
        'TN' => __( 'Tennessee', 'woocommerce' ),
        'TX' => __( 'Texas', 'woocommerce' ),
        'UT' => __( 'Utah', 'woocommerce' ),
        'VT' => __( 'Vermont', 'woocommerce' ),
        'VA' => __( 'Virginia', 'woocommerce' ),
        'WA' => __( 'Washington', 'woocommerce' ),
        'WV' => __( 'West Virginia', 'woocommerce' ),
        'WI' => __( 'Wisconsin', 'woocommerce' ),
        'WY' => __( 'Wyoming', 'woocommerce' ),
        'AA' => __( 'Armed Forces (AA)', 'woocommerce' ),
        'AE' => __( 'Armed Forces (AE)', 'woocommerce' ),
        'AP' => __( 'Armed Forces (AP)', 'woocommerce' ),
    );
    return $states;
}
/* Add Puerto Rico as a State */

/**
 * Custom User meta Fields form on backend
*/
add_action('show_user_profile', 'virtina_user_profile_field_callback');
add_action('edit_user_profile', 'virtina_user_profile_field_callback');
function virtina_user_profile_field_callback($user) { 
    $checked = (isset($user->invoice_payment) && $user->invoice_payment) ? ' checked="checked"' : '';  ?>
    <h3>Invoice Settings</h3>
    <label for="vir_invoice_payment">
        <input name="vir_invoice_payment" type="checkbox" id="vir_invoice_payment" value="1" <?php echo $checked; ?>>
        Invoice Payment
    </label>
<?php }

/**
 * Custom User meta Field value update
*/
add_action('personal_options_update', 'virtina_user_profile_field_update');
add_action('edit_user_profile_update', 'virtina_user_profile_field_update');
function virtina_user_profile_field_update($user_id) {
    $cf_val = isset( $_POST['vir_invoice_payment'] ) ? 1 : 0;
    update_user_meta($user_id, 'invoice_payment', $cf_val);
}

/**
 *  WooCommerce Disable Invoice Payment Gateway 
*/
add_filter( 'woocommerce_available_payment_gateways', 'vi_invoice_payment_gateway_disable' );
function vi_invoice_payment_gateway_disable( $available_gateways ) {
    if ( is_user_logged_in() ) {
        $user_id = get_current_user_id();
        $invoice_payment_flag = get_user_meta( $user_id, 'invoice_payment', true );
        if( $invoice_payment_flag != 1 ){
            unset( $available_gateways['invoice'] );
        }
    }
    return $available_gateways;
}
<?php

defined('ABSPATH') or die();

/**

 *

 * @package WordPress

 * @subpackage Storefy

 * @since Storefy 1.0

 */



$footertext=function_exists('icl_t') ? icl_t('storefy', 'footer-text', get_storefy_option('footer-text','')):get_storefy_option('footer-text','');





?>

<footer style="background-color:#252525; padding-top:2em; padding-left:2em; padding-right:2em;" class="<?php print get_storefy_option('dt-header-type')=='leftbar' ? " vertical_menu_container":"";?>">

<?php if ( is_active_sidebar( 'footer-widget' ) ) : ?>

		<div class="col-md-12 col-sm-12 footer-widget" role="complementary">

			<?php dynamic_sidebar( 'footer-widget' ); ?>

		</div><!-- .widget-area .first -->

<?php endif; ?>

<div class="container footer-section">

		<?php if((!empty($footertext) || strlen(strip_tags($footertext)) > 1) && get_storefy_option('showfooterwidget') && is_active_sidebar( 'sidebar-bottom' )){?> 

		<div class="col-md-12<?php print get_storefy_option('dt-footer-position')=='right' ? "":"";?> col-sm-12 col-xs-12 footer-right">

			<div id="footer-right">

				<?php 

				dynamic_sidebar('sidebar-bottom');

				do_action('dynamic_sidebar_sidebar-bottom');

				 ?>

			</div>

		</div>			

		<div class="col-md-12<?php print get_storefy_option('dt-footer-position')=='right' ? "":"";?> col-sm-12 col-xs-12 footer-left">

			<div id="footer-left">

				<?php echo do_shortcode($footertext); ?>

			</div>

		</div>

		<?php }

		elseif((!empty($footertext) || strlen(strip_tags($footertext)) > 1) && (!get_storefy_option('showfooterwidget') || !is_active_sidebar( 'sidebar-bottom' )))

		{

		?> 

		<div class="col-md-12 footer-left equal-height">

			<div id="footer-left">

				<?php echo do_shortcode($footertext); ?>

			</div>

		</div>	

		<?php 

		}

		elseif(get_storefy_option('showfooterwidget') && is_active_sidebar( 'sidebar-bottom' )){

			?>

		<div class="col-md-12 footer-right equal-height">

			<div id="footer-right">

				<?php dynamic_sidebar('sidebar-bottom');

				do_action('dynamic_sidebar_sidebar-bottom');

				 ?>

			</div>

		</div>	

		<?php

		 }

		?>

</div>

</footer>
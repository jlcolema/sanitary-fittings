<?php
defined('ABSPATH') or die();
/**
 * top bar
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */

$text=function_exists('icl_t') ? icl_t('hnd', 'right-top-bar-text', get_storefy_option('dt-right-top-bar-text','')):get_storefy_option('dt-right-top-bar-text','');
?>
<div class="right-menu"><div class="topbar-text"><?php print (!empty($text))? do_shortcode($text):"";?></div></div>
<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.6.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}

$equal_height_type= isset($product->equal_height_type) ? $product->equal_height_type : 0; 
$equal_height_selector= isset($product->equal_height_id) ? $product->equal_height_id : ""; 

$equal_height_tag="";
if(!empty($equal_height_selector)){

	if($equal_height_type=='skip-grouped'){
		$equal_height_tag=' data-mh="'.esc_attr($equal_height_selector).'"';
	}
	elseif($equal_height_type=='skip-target'){
		$equal_height_tag=' data-equal-with="'.esc_attr($equal_height_selector).'"';
	}
}

?>
<li <?php post_class(); echo $equal_height_tag; ?> itemscope itemtype="http://schema.org/Product">
	<?php do_action( 'storefy_woocommerce_before_shop_loop_item' );?>
	<div class="product-loop-container">
		<?php 
		if(storefy_loop_product_show_thumbnail()):?>
		<div class="col-lg-6 col-xs-12">
			<?php
			storefy_woocommerce_template_loop_product_thumbnail();
			?>
		</div>
		<div class="col-lg-6 col-xs-12">
		<?php else:?>
		<div class="col-xs-12">
		<?php endif;?>
			<div class="product-loop-item-container">
				<div class="before-product-loop-item">	
		<?php

					woocommerce_template_loop_product_link_open();
					woocommerce_template_loop_product_title();
					woocommerce_template_loop_product_link_close();
					woocommerce_template_loop_rating();
					storefy_wooscarcity_load_loop_sale_countdown();
					woocommerce_template_loop_price();
					storefy_woocommerce_loop_stock_get_availability();

		?>
				</div>
				<div class="after-product-loop-item">
				<?php 
					$show_add_to_cart_btn= apply_filters('storefy_woocommerce_template_loop_add_to_cart_show',false);
					$is_single_loop= apply_filters( 'storefy_woocommerce_template_single',false);

					if($show_add_to_cart_btn && $is_single_loop):
						woocommerce_template_loop_add_to_cart(array('layout'=>'','btn_label'=>esc_html__('Shop Now!','storefy')));
					endif;

				?>
				</div>
			</div>
		</div>
		<?php 
		$action_lists=apply_filters('storefy_woocommerce_loop_action_list',array());

		if(!$is_single_loop){
			$action_lists['add-to-cart']='<a class="add-to-cart" href=""><i class="storefy-product-cart"></i><span>'.esc_html('add to cart','storefy').'</span></a>';
		}
		?>
	</div>
	<?php
		if(count($action_lists)):
	?>
		<ul class="product-loop-action">
		<?php foreach ($action_lists as $action_name => $action) {?>
		<li class="<?php print sanitize_html_class($action_name);?>"><?php print $action;?></li>
		<?php }?>
		</ul>
	<?php endif;?>
	<?php do_action( 'storefy_woocommerce_after_shop_loop_item' );?>
</li>

<?php
defined('ABSPATH') or die();

//if(!$post_format=get_post_format()) return;

$categories = get_the_category_list(', ');
if (empty($categories)) return;
?>
<div class="postinfo">
	<div class="blog_info_categories"><?php echo $categories; ?></div>
</div>
<?php
/**
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
*/
defined('ABSPATH') or die();
?>
<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8) ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<?php 
require_once( get_template_directory().'/lib/page-options.php'); ?>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php echo esc_url(bloginfo( 'pingback_url' )); ?>">
<?php wp_head(); ?>
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5TD8XHR');</script>
<!-- End Google Tag Manager -->
</head>
<body <?php body_class(); print esc_attr(get_storefy_option('body_tag',''));?> data-speed="5" data-type="background">
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5TD8XHR"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div class="paspartu_top"></div>
<div class="paspartu_left"></div>
<div class="paspartu_right"></div>
<div class="paspartu_bottom"></div>	
<div class="paspartu_inner">
<div id="top-bar">
	<div class="container">
		<div class="top-bar-container">
			<div class="left-menu"><div class="topbar-text" style="margin-top:0px">
				<a class="hidden-lg hidden-md" href="https://sanitaryfittings.us"><img src="https://dusouecxfowwg.cloudfront.net/wp-content/uploads/2020/01/sanitary-fittings-logo.png" /></a>
				<a class="mobile-home" href="https://sanitaryfittings.us"><ul id="menu-right-menu" class="topbar-menu">
<li id="menu-item-341" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-341 hidden-xs hidden-sm"><a href="/my-account/" style="padding-left:0; padding-top:0; padding-bottom:0; padding-right:1.42em;"><i class="simple-line-icon-user"></i><span>My Account</span></a></li>
<li id="menu-item-342" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-342 hidden-xs hidden-sm"><a href="/contact-us"><i class="simple-line-icon-earphones-alt"></i><span>Customer Care</span></a></li>
</ul></div></div>
			      <div class="right-menu">
      <div id="dt-topbar-menu-right" class="menu-right-menu-container"><ul id="menu-right-menu" class="topbar-menu"><li id="menu-item-340" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-340"><a href="/request-a-quote?source=top" style="color:#f78e1e;"><i class="simple-line-icon-basket"></i><span>Request Quote</span></a></li> 
</ul></div>      </div>
		</div>
	</div>
</div>
<?php get_template_part('pagetemplates/preloader'); ?>
<?php if(get_storefy_option('showtopbar',true)): 
	get_template_part('pagetemplates/top-bar');?>
<?php endif;?>

<?php get_template_part('pagetemplates/heading-new');?>

<section class="top-head" style="background-color:#224875 !important">
<?php 
get_template_part('pagetemplates/main_navigation-new');
?>
</section>
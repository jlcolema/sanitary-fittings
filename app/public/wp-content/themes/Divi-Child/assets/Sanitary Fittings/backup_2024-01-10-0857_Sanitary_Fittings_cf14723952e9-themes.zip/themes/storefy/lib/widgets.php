<?php
defined('ABSPATH') or die();
/** DT_Tabs **/
class DT_Tabs extends WP_Widget {
	function __construct() {
		$widget_ops = array('classname' => 'dt_widget_tabs', 'description' => esc_html__( "Display popular posts, recent posts, and recent comments in Tabulation.",'storefy') );
		parent::__construct('dt-tabs', esc_html__('DT Tabs','storefy'), $widget_ops);
		$this->alt_option_name = 'dt_widget_tabs';
	}
	function widget($args, $instance) {
		global $storefy_Scripts;
		$cache = wp_cache_get('dt_widget_tabs', 'widget');
		if ( !is_array($cache) )
			$cache = array();
		if ( ! isset( $args['widget_id'] ) )
			$args['widget_id'] = $this->id;
		if ( isset( $cache[ $args['widget_id'] ] ) ) {
			echo $cache[ $args['widget_id'] ];
			return;
		}
		extract($args);
		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : esc_html__( 'Recent Posts','storefy');
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
		$number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 3;
		if ( ! $number ) $number = 3;
?>
		<?php echo $before_widget; ?>
		<?php if ( $title ) echo $before_title . $title . $after_title; ?>
		<!-- Nav tabs -->
		<ul class="nav nav-tabs nav-justified">
		  <li class="active"><a href="#home_<?php echo sanitize_key($this->get_field_id('dt')); ?>" data-toggle="tab"><?php esc_html_e('Popular','storefy');?></a></li>
		  <li><a href="#recent_<?php echo sanitize_key($this->get_field_id('dt')); ?>" data-toggle="tab"><?php esc_html_e('Recent','storefy');?></a></li>
		</ul>
		<!-- Tab panes -->
		<div class="tab-content">
		  	<div class="tab-pane fade in active" id="home_<?php echo sanitize_key($this->get_field_id('dt')); ?>">
<?php
				$r = new WP_Query(array( 'posts_per_page' => $number, 'no_found_rows' => true, 'post_status' => 'publish', 'ignore_sticky_posts' => true, 'meta_key' => 'post_views_count', 'orderby' => 'meta_value', 'order' => 'DESC' ) );
				if ($r->have_posts()) :
					$i = 0;
					while ( $r->have_posts() ) : $r->the_post();
?>
				<div class="row">
					<div class="rowlist">
					<?php
						$imgurl = "";
						$col_post_info = '';
						$col_image_info = ''; 
						$attachment_id=get_post_thumbnail_id(get_the_ID());
						$featured_image = wp_get_attachment_image_src($attachment_id,'thumbnail',false); 
						$author_name=get_the_author();
						if (isset($featured_image[0])) {
							$imgurl = $featured_image[0];
							$col_image_info = is_rtl()?'col-xs-5 col-xs-push-7':'col-xs-5';
							$col_post_info = is_rtl()?'col-xs-7 col-xs-pull-5':'col-xs-7'; 
						} else {

							$defaultImage=get_storefy_option('dt-default-single-post-image');

							if (!empty($defaultImage['url'])) : 
								$imgurl = $defaultImage['thumbnail'];
								$col_image_info = is_rtl()?'col-xs-5 col-xs-push-7':'col-xs-5';
								$col_post_info = is_rtl()?'col-xs-7 col-xs-pull-5':'col-xs-7'; 
							endif; 
						} 
					?>											

					<?php 
						if (!empty($imgurl)) :

							$alt_image = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
					?>
					<div class="<?php echo storefy_sanitize_html_class($col_image_info); ?> image-info">
						<a href="<?php echo esc_url(get_permalink()); ?>"><img src="<?php echo esc_url($imgurl); ?>" class="widget-post-thumb img-responsive" alt="<?php print esc_attr($alt_image);?>" /></a>
					</div>
					<?php
						endif;
					?>

						<div class="<?php echo storefy_sanitize_html_class($col_post_info); ?> post-info">
							<a href="<?php echo esc_url(get_permalink()); ?>" class="widget-post-title"><?php get_the_title() ? the_title() : the_ID(); ?></a>
							<div class="meta-info">
									<?php print ucwords($author_name)." . ".get_the_date(); ?>
							</div>
						</div>

					</div>
				</div>
<?php
						$i++;
					endwhile; 
				wp_reset_postdata();
				endif; 
?>
		  	</div>
		  	<div class="tab-pane fade" id="recent_<?php echo sanitize_key($this->get_field_id('dt')); ?>">
<?php
				$r = new WP_Query(array( 'posts_per_page' => $number, 'no_found_rows' => true, 'post_status' => 'publish', 'ignore_sticky_posts' => true, 'orderby' => 'date', 'order' => 'DESC' ) );
				if ($r->have_posts()) :
					$i = 0;
					while ( $r->have_posts() ) : $r->the_post();
?>
				<div class="row">
				<div class="rowlist gray_border_bottom">
					<?php
						$imgurl = "";
						$col_post_info = ''; 
						$attachment_id=get_post_thumbnail_id(get_the_ID());
						$featured_image = wp_get_attachment_image_src($attachment_id,'thumbnail',false); 
						$author_name=get_the_author();

						if (isset($featured_image[0])) {
							$imgurl = $featured_image[0];
							$col_image_info = is_rtl()?'col-xs-5 col-xs-push-7':'col-xs-5';
							$col_post_info = is_rtl()?'col-xs-7 col-xs-pull-5':'col-xs-7'; 
						} else {

							$defaultImage=get_storefy_option('dt-default-single-post-image');

							if (!empty($defaultImage['url'])) : 
								$imgurl = $defaultImage['thumbnail'];
								$col_image_info = is_rtl()?'col-xs-5 col-xs-push-7':'col-xs-5';
								$col_post_info = is_rtl()?'col-xs-7 col-xs-pull-5':'col-xs-7'; 
							endif;
						}
					?>											

					<?php 
						if (!empty($imgurl)) :

							$alt_image = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
					?>
					<div class="<?php echo storefy_sanitize_html_class($col_image_info); ?> image-info">
						<a href="<?php echo esc_url(get_permalink()); ?>"><img src="<?php echo esc_url($imgurl); ?>" class="widget-post-thumb img-responsive" alt="<?php print esc_attr($alt_image);?>" /></a>
					</div>
					<?php
						endif;
					?>
					<div class="<?php echo storefy_sanitize_html_class($col_post_info); ?> post-info">
						<a href="<?php echo esc_url(get_permalink()); ?>" class="widget-post-title"><?php get_the_title() ? the_title() : the_ID(); ?></a>
						<div class="meta-info">
								<?php print ucwords($author_name)." . ".get_the_date(); ?>
						</div>
					</div>
				</div>
				</div>
<?php
						$i++;
					endwhile; 
				wp_reset_postdata();
				endif;
?>
		  	</div>
		</div>					
		
		<?php echo $after_widget; ?>
<?php
	}
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = (int) $new_instance['number'];
				
		$alloptions = wp_cache_get( 'alloptions', 'options' );
		if ( isset($alloptions['dt_widget_tabs']) )
			delete_option('dt_widget_tabs');
		return $instance;
	}

	function form( $instance ) {
		$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 3;
?>
		<p><label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e( 'Title:','storefy'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo wp_strip_all_tags($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo sanitize_text_field($title); ?>" /></p>
		<p><label for="<?php echo esc_attr($this->get_field_id( 'number' )); ?>"><?php esc_html_e( 'Number of posts/comments to show:','storefy'); ?></label>
		<input id="<?php echo esc_attr($this->get_field_id( 'number' )); ?>" name="<?php echo wp_strip_all_tags($this->get_field_name( 'number' )); ?>" type="text" value="<?php echo sanitize_text_field($number); ?>" size="3" /></p>
<?php
	}
}
/** /DT_Tabs **/

class Walker_DT_Category extends Walker_Category {
	function start_el( &$output, $category, $depth = 0, $args = array(), $id = 0 ) {
		extract($args);
		$cat_name = esc_attr( $category->name );
		$cat_name = apply_filters( 'list_cats', $cat_name, $category );
		$link = '<a href="' . esc_url( get_term_link($category) ) . '" ';
		if ( $use_desc_for_title == 0 || empty($category->description) )
			$link .= 'title="' . esc_attr( sprintf(esc_html__( 'View all posts filed under %s','storefy' ), $cat_name) ) . '"';
		else
			$link .= 'title="' . esc_attr( strip_tags( apply_filters( 'category_description', $category->description, $category ) ) ) . '"';
		$link .= '>';
		$link .= $cat_name . '</a>';
		if ( !empty($feed_image) || !empty($feed) ) {
			$link .= ' ';
			if ( empty($feed_image) )
				$link .= '(';
			$link .= '<a href="' . esc_url( get_term_feed_link( $category->term_id, $category->taxonomy, $feed_type ) ) . '"';
			if ( empty($feed) ) {
				$alt = ' alt="' . sprintf(esc_html__( 'Feed for all posts filed under %s','storefy' ), $cat_name ) . '"';
			} else {
				$title = ' title="' . $feed . '"';
				$alt = ' alt="' . $feed . '"';
				$name = $feed;
				$link .= $title;
			}
			$link .= '>';
			if ( empty($feed_image) )
				$link .= $name;
			else
				$link .= "<img src='$feed_image'$alt$title" . ' />';
			$link .= '</a>';
			if ( empty($feed_image) )
				$link .= ')';
		}
		if ( !empty($show_count) )
			$link .= ' (' . intval($category->count) . ')';
		if ( 'list' == $args['style'] ) {
			$output .= "\t<li";
			$class = 'cat-item cat-item-' . $category->term_id;
			if ( !empty($current_category) ) {
				$_current_category = get_term( $current_category, $category->taxonomy );
				if ( $category->term_id == $current_category )
					$class .=  ' current-cat';
				elseif ( $category->term_id == $_current_category->parent )
					$class .=  ' current-cat-parent';
			}
			$output .=  ' class="' . $class . '"';
			$output .= ">$link\n";
		} else {
			$output .= "\t$link<br />\n";
		}
	}
}

function storefy_create_category_walker($args){
	$args['walker']=new Walker_DT_Category();
	return $args;
}

add_filter('widget_categories_args', 'storefy_create_category_walker');

function storefy_format_widget_archive($args){
	return $args;
}

add_filter('widget_archives_args','storefy_format_widget_archive');

/** DT_Accordion **/
class DT_Accordion extends WP_Widget {
	function __construct() {
		$widget_ops = array('classname' => 'dt_widget_accordion', 'description' => esc_html__( "Display information in accordion style.",'storefy') );
		parent::__construct('dt_accordion', esc_html__('DT Accordion','storefy'), $widget_ops);
		$this->alt_option_name = 'dt_widget_accordion';
	}

	function form( $instance ) {
		$title  = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$acctitle1  = isset( $instance['acctitle1'] ) ? esc_attr( $instance['acctitle1'] ) : '';
		$acctitle2  = isset( $instance['acctitle2'] ) ? esc_attr( $instance['acctitle2'] ) : '';
		$acctitle3  = isset( $instance['acctitle3'] ) ? esc_attr( $instance['acctitle3'] ) : '';
		$acctitle4  = isset( $instance['acctitle4'] ) ? esc_attr( $instance['acctitle4'] ) : '';
		$accdesc1  = isset( $instance['accdesc1'] ) ? esc_textarea( $instance['accdesc1'] ) : '';
		$accdesc2  = isset( $instance['accdesc2'] ) ? esc_textarea( $instance['accdesc2'] ) : '';
		$accdesc3  = isset( $instance['accdesc3'] ) ? esc_textarea( $instance['accdesc3'] ) : '';
		$accdesc4  = isset( $instance['accdesc4'] ) ? esc_textarea( $instance['accdesc4'] ) : '';
?>
		<p><label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e( 'Title:','storefy' ); ?></label>
		<input class="widefat" id="<?php echo sanitize_title($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo sanitize_text_field($title); ?>" /></p>
		<p><label for="<?php echo esc_attr($this->get_field_id( 'acctitle1' )); ?>"><?php esc_html_e( 'Accordion Title 1:','storefy' ); ?></label>
		<input class="widefat" id="<?php echo sanitize_title($this->get_field_id( 'acctitle1' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'acctitle1' )); ?>" type="text" value="<?php echo sanitize_text_field($acctitle1); ?>" /></p>
		<label for="<?php echo esc_attr($this->get_field_id( 'accdesc1' )); ?>"><?php esc_html_e( 'Accordion Description 1:','storefy' ); ?></label>
		<textarea class="widefat" rows="16" cols="20" id="<?php echo sanitize_title($this->get_field_id('accdesc1')); ?>" name="<?php echo esc_attr($this->get_field_name('accdesc1')); ?>"><?php echo sanitize_text_field($accdesc1); ?></textarea>
		<p><label for="<?php echo esc_attr($this->get_field_id( 'acctitle2' )); ?>"><?php esc_html_e( 'Accordion Title 2:','storefy' ); ?></label>
		<input class="widefat" id="<?php echo sanitize_title($this->get_field_id( 'acctitle2' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'acctitle2' )); ?>" type="text" value="<?php echo sanitize_text_field($acctitle2); ?>" /></p>
		<label for="<?php echo esc_attr($this->get_field_id( 'accdesc2' )); ?>"><?php esc_html_e( 'Accordion Description 2:','storefy' ); ?></label>
		<textarea class="widefat" rows="16" cols="20" id="<?php echo sanitize_title($this->get_field_id('accdesc2')); ?>" name="<?php echo esc_attr($this->get_field_name('accdesc2')); ?>"><?php echo sanitize_text_field($accdesc2); ?></textarea>
		<p><label for="<?php echo esc_attr($this->get_field_id( 'acctitle3' )); ?>"><?php esc_html_e( 'Accordion Title 3:','storefy' ); ?></label>
		<input class="widefat" id="<?php echo sanitize_title($this->get_field_id( 'acctitle3' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'acctitle3' )); ?>" type="text" value="<?php echo sanitize_text_field($acctitle3); ?>" /></p>
		<label for="<?php echo esc_attr($this->get_field_id( 'accdesc3' )); ?>"><?php esc_html_e( 'Accordion Description 3:','storefy' ); ?></label>
		<textarea class="widefat" rows="16" cols="20" id="<?php echo sanitize_title($this->get_field_id('accdesc3')); ?>" name="<?php echo esc_attr($this->get_field_name('accdesc3')); ?>"><?php echo sanitize_text_field($accdesc3); ?></textarea>
		<p><label for="<?php echo esc_attr($this->get_field_id( 'acctitle4' )); ?>"><?php esc_html_e( 'Accordion Title 4:','storefy' ); ?></label>
		<input class="widefat" id="<?php echo sanitize_title($this->get_field_id( 'acctitle4' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'acctitle4' )); ?>" type="text" value="<?php echo sanitize_text_field($acctitle4); ?>" /></p>
		<label for="<?php echo esc_attr($this->get_field_id( 'accdesc4' )); ?>"><?php esc_html_e( 'Accordion Description 4:','storefy' ); ?></label>
		<textarea class="widefat" rows="16" cols="20" id="<?php echo sanitize_title($this->get_field_id('accdesc4')); ?>" name="<?php echo esc_attr($this->get_field_name('accdesc4')); ?>"><?php echo sanitize_text_field($accdesc4); ?></textarea>
<?php
	}
	
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['acctitle1'] = strip_tags($new_instance['acctitle1']);
		$instance['acctitle2'] = strip_tags($new_instance['acctitle2']);
		$instance['acctitle3'] = strip_tags($new_instance['acctitle3']);
		$instance['acctitle4'] = strip_tags($new_instance['acctitle4']);
		if ( current_user_can('unfiltered_html') ) {
			$instance['accdesc1'] =  $new_instance['accdesc1'];
			$instance['accdesc2'] =  $new_instance['accdesc2'];
			$instance['accdesc3'] =  $new_instance['accdesc3'];
			$instance['accdesc4'] =  $new_instance['accdesc4'];
		} else {
			$instance['accdesc1'] = stripslashes( wp_filter_post_kses( addslashes($new_instance['accdesc1']) ) ); 
			$instance['accdesc2'] = stripslashes( wp_filter_post_kses( addslashes($new_instance['accdesc2']) ) ); 
			$instance['accdesc3'] = stripslashes( wp_filter_post_kses( addslashes($new_instance['accdesc3']) ) ); 
			$instance['accdesc4'] = stripslashes( wp_filter_post_kses( addslashes($new_instance['accdesc4']) ) ); 
		}

		return $instance;
	}

	function widget( $args, $instance ) {
		global $storefy_Scripts;
		extract($args);
		if ( ! isset( $args['widget_id'] ) ) $args['widget_id'] = $this->id;
		
		$widget_id = $args['widget_id'];
		$acctitle1  = isset( $instance['acctitle1'] ) ? esc_attr( $instance['acctitle1'] ) : '';
		$acctitle2  = isset( $instance['acctitle2'] ) ? esc_attr( $instance['acctitle2'] ) : '';
		$acctitle3  = isset( $instance['acctitle3'] ) ? esc_attr( $instance['acctitle3'] ) : '';
		$acctitle4  = isset( $instance['acctitle4'] ) ? esc_attr( $instance['acctitle4'] ) : '';
		$accdesc1 = apply_filters( 'widget_text', empty( $instance['accdesc1'] ) ? '' : $instance['accdesc1'], $instance );
		$accdesc2 = apply_filters( 'widget_text', empty( $instance['accdesc2'] ) ? '' : $instance['accdesc2'], $instance );
		$accdesc3 = apply_filters( 'widget_text', empty( $instance['accdesc3'] ) ? '' : $instance['accdesc3'], $instance );
		$accdesc4 = apply_filters( 'widget_text', empty( $instance['accdesc4'] ) ? '' : $instance['accdesc4'], $instance );

		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] :"";
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
		echo $before_widget;
		if ( $title ) echo $before_title . $title . $after_title;
		
		echo '<div class="panel-group custom-accordion" id="'.$widget_id.'">';
		if (!empty($acctitle1)) :		  
		echo '<div class="panel panel-default">
			    <div class="panel-heading openedup" data-toggle="collapse" data-parent="#'.$widget_id.'">
			      <h4 class="panel-title">'.$acctitle1.'</h4>
			      <a class="btn-accordion opened" data-toggle="collapse" data-parent="#'.$widget_id.'" href="#collapseOne'.$widget_id.'"><i class="icon-minus-1"></i></a>
			    </div>
			    <div id="collapseOne'.$widget_id.'" class="panel-collapse collapse in">
			      <div class="panel-body">'. wpautop( $accdesc1 ) . '</div>
			    </div>
			  </div>';
		endif;
		
		if (!empty($acctitle2)) :	  
		echo '<div class="panel panel-default">
			    <div class="panel-heading" data-toggle="collapse" data-parent="#'.$widget_id.'">
			      <h4 class="panel-title">'.$acctitle2.'</h4>
			      <a class="btn-accordion" data-toggle="collapse" data-parent="#'.$widget_id.'" href="#collapseTwo'.$widget_id.'"><i class="icon-plus-1"></i></a>
			    </div>
			    <div id="collapseTwo'.$widget_id.'" class="panel-collapse collapse">
			      <div class="panel-body">'. wpautop( $accdesc2 ) . '</div>
			    </div>
			  </div>';
		endif;
		if (!empty($acctitle3)) :
		echo '<div class="panel panel-default">
			    <div class="panel-heading" data-toggle="collapse" data-parent="#'.$widget_id.'">
			      <h4 class="panel-title">'.$acctitle3.'</h4>
			      <a class="btn-accordion" data-toggle="collapse" data-parent="#'.$widget_id.'" href="#collapseThree'.$widget_id.'"><i class="icon-plus-1"></i></a>
			    </div>
			    <div id="collapseThree'.$widget_id.'" class="panel-collapse collapse">
			      <div class="panel-body">'. wpautop( $accdesc3 ) . '</div>
			    </div>
			  </div>';
		endif;
		if (!empty($acctitle4)) :
		echo '<div class="panel panel-default">
			    <div class="panel-heading" data-toggle="collapse" data-parent="#'.$widget_id.'">
			      <h4 class="panel-title">'.$acctitle4.'</h4>
			      <a class="btn-accordion" data-toggle="collapse" data-parent="#'.$widget_id.'" href="#collapseFour'.$widget_id.'"><i class="icon-plus-1"></i></a>
			    </div>
			    <div id="collapseFour'.$widget_id.'" class="panel-collapse collapse">
			      <div class="panel-body">'. wpautop( $accdesc4 ) . '</div>
			    </div>
			  </div>';
		endif;
		echo '</div>';
        echo $after_widget;
	}
}

if(storefy_plugin_is_active('woocommerce/woocommerce.php')){
	class Storefy_Widget_Products extends WC_Widget{

	  public function __construct() {

	    $this->widget_cssclass    = 'woocommerce storefy_widget_products';
	    $this->widget_description = esc_html__( 'Display a list of your products on your site.', 'storefy' );
	    $this->widget_id          = 'storefy_woocommerce_products';
	    $this->widget_name        = esc_html__( 'Storefy WC Products', 'storefy' );
	    $this->settings           = array(
	      'title'  => array(
	        'type'  => 'text',
	        'std'   => esc_html__( 'Products', 'woocommerce' ),
	        'label' => esc_html__( 'Title', 'woocommerce' )
	      ),
	      'number' => array(
	        'type'  => 'number',
	        'step'  => 1,
	        'min'   => 1,
	        'max'   => '',
	        'std'   => 5,
	        'label' => esc_html__( 'Number of products to show', 'woocommerce' )
	      ),
	      'rows'=>
	        array(
	          'type' => 'number',
	          'label' => esc_html__( 'Rows', 'storefy' ),
	          'step'  => 1,
	          'min'   => 1,
	          'std'   => 5,
	          'max'   => 10,
	        ),
	      'show' => array(
	        'type'  => 'select',
	        'std'   => '',
	        'label' => esc_html__( 'Show', 'woocommerce' ),
	        'options' => array(
	          ''         => esc_html__( 'All Products', 'woocommerce' ),
	          'featured' => esc_html__( 'Featured Products', 'woocommerce' ),
	          'onsale'   => esc_html__( 'On-sale Products', 'woocommerce' ),
	        )
	      ),
	      'orderby' => array(
	        'type'  => 'select',
	        'std'   => 'date',
	        'label' => esc_html__( 'Order by', 'woocommerce' ),
	        'options' => array(
	          'date'   => esc_html__( 'Date', 'woocommerce' ),
	          'price'  => esc_html__( 'Price', 'woocommerce' ),
	          'rand'   => esc_html__( 'Random', 'woocommerce' ),
	          'sales'  => esc_html__( 'Sales', 'woocommerce' ),
	        )
	      ),
	      'order' => array(
	        'type'  => 'select',
	        'std'   => 'desc',
	        'label' => _x( 'Order', 'Sorting order', 'woocommerce' ),
	        'options' => array(
	          'asc'  => esc_html__( 'ASC', 'woocommerce' ),
	          'desc' => esc_html__( 'DESC', 'woocommerce' ),
	        )
	      ),
	      'hide_free' => array(
	        'type'  => 'checkbox',
	        'std'   => 0,
	        'label' => esc_html__( 'Hide free products', 'woocommerce' )
	      ),
	      'show_hidden' => array(
	        'type'  => 'checkbox',
	        'std'   => 0,
	        'label' => esc_html__( 'Show hidden products', 'woocommerce' )
	      )
	    );

	    parent::__construct();
	  }

	  /**
	   * Query the products and return them.
	   * @param  array $args
	   * @param  array $instance
	   * @return WP_Query
	   */
	  public function get_products( $args, $instance ) {
	    $number  = ! empty( $instance['number'] ) ? absint( $instance['number'] ) : $this->settings['number']['std'];
	    $show    = ! empty( $instance['show'] ) ? sanitize_title( $instance['show'] ) : $this->settings['show']['std'];
	    $orderby = ! empty( $instance['orderby'] ) ? sanitize_title( $instance['orderby'] ) : $this->settings['orderby']['std'];
	    $order   = ! empty( $instance['order'] ) ? sanitize_title( $instance['order'] ) : $this->settings['order']['std'];

	    $query_args = array(
	      'posts_per_page' => $number,
	      'post_status'    => 'publish',
	      'post_type'      => 'product',
	      'no_found_rows'  => 1,
	      'order'          => $order,
	      'meta_query'     => array()
	    );

	    if ( empty( $instance['show_hidden'] ) ) {
	      $query_args['meta_query'][] = WC()->query->visibility_meta_query();
	      $query_args['post_parent']  = 0;
	    }

	    if ( ! empty( $instance['hide_free'] ) ) {
	      $query_args['meta_query'][] = array(
	        'key'     => '_price',
	        'value'   => 0,
	        'compare' => '>',
	        'type'    => 'DECIMAL',
	      );
	    }

	    $query_args['meta_query'][] = WC()->query->stock_status_meta_query();
	    $query_args['meta_query']   = array_filter( $query_args['meta_query'] );

	    switch ( $show ) {
	      case 'featured' :
	        $query_args['meta_query'][] = array(
	          'key'   => '_featured',
	          'value' => 'yes'
	        );
	        break;
	      case 'onsale' :
	        $product_ids_on_sale    = wc_get_product_ids_on_sale();
	        $product_ids_on_sale[]  = 0;
	        $query_args['post__in'] = $product_ids_on_sale;
	        break;
	    }

	    switch ( $orderby ) {
	      case 'price' :
	        $query_args['meta_key'] = '_price';
	        $query_args['orderby']  = 'meta_value_num';
	        break;
	      case 'rand' :
	        $query_args['orderby']  = 'rand';
	        break;
	      case 'sales' :
	        $query_args['meta_key'] = 'total_sales';
	        $query_args['orderby']  = 'meta_value_num';
	        break;
	      default :
	        $query_args['orderby']  = 'date';
	    }

	    return new WP_Query( apply_filters( 'woocommerce_products_widget_query_args', $query_args ) );
	  }

	  /**
	   * Output widget.
	   *
	   * @see WP_Widget
	   *
	   * @param array $args
	   * @param array $instance
	   */
	  public function widget( $args, $instance ) {
	    if ( $this->get_cached_widget( $args ) ) {
	      return;
	    }

	    ob_start();

	    if ( ( $products = $this->get_products( $args, $instance ) ) && $products->have_posts() ) {

	    	$rows= isset($instance['rows']) ? intval($instance['rows']) : $products->post_count;
		    $is_carousel =  $products->post_count > $rows;
		    $current_post=1;

	      $this->widget_start( $args, $instance );

			if($is_carousel){

			    wp_enqueue_style('owl.carousel',DETHEME_VC_DIR_URL."css/owl.carousel.css",array());
			    wp_enqueue_script( 'owl.carousel', DETHEME_VC_DIR_URL . 'js/owl.carousel.js', array('jquery'), '', false );

			    print '<div class="product_carousel">';
			}

	      echo apply_filters( 'woocommerce_before_widget_product_list', '<ul class="product_list_widget">' );

	      while ( $products->have_posts() ) {
	        $products->the_post();
	        wc_get_template( 'content-widget-product.php', array( 'show_rating' => false ) );

			if( $is_carousel && !($current_post %  $rows) && $current_post < $products->post_count ){

			      echo apply_filters( 'woocommerce_after_widget_product_list', '</ul>' );
			      echo apply_filters( 'woocommerce_before_widget_product_list', '<ul class="product_list_widget">' );

			}

	        $current_post++;
	      }

	      echo apply_filters( 'woocommerce_after_widget_product_list', '</ul>' );
	  		if($is_carousel){
	  			print "</div>";
	  		}


	      $this->widget_end( $args );
	    }

	    wp_reset_postdata();

	    echo $this->cache_widget( $args, ob_get_clean() );
	  }

	}

	class Storefy_Widget_Top_Rated_Products extends WC_Widget{

		public function __construct() {
			$this->widget_cssclass    = 'woocommerce storefy_widget_top_rated_products';
			$this->widget_description = esc_html__( 'Display a list of your top rated products on your site.', 'woocommerce' );
			$this->widget_id          = 'storefy_woocommerce_top_rated_products';
			$this->widget_name        = esc_html__( 'Sorefy WC Top Rated Products', 'storefy' );
			$this->settings           = array(
				'title'  => array(
					'type'  => 'text',
					'std'   => esc_html__( 'Top Rated Products', 'woocommerce' ),
					'label' => esc_html__( 'Title', 'woocommerce' )
				),
				'number' => array(
					'type'  => 'number',
					'step'  => 1,
					'min'   => 1,
					'max'   => '',
					'std'   => 5,
					'label' => esc_html__( 'Number of products to show', 'woocommerce' )
				),
		      'rows'=>
		        array(
		          'type' => 'number',
		          'label' => esc_html__( 'Rows', 'storefy' ),
		          'step'  => 1,
		          'min'   => 1,
		          'std'   => 5,
		          'max'   => 10,
		        ),
			);

			parent::__construct();
		}

		/**
		 * Output widget.
		 *
		 * @see WP_Widget
		 *
		 * @param array $args
		 * @param array $instance
		 */
		public function widget( $args, $instance ) {

			if ( $this->get_cached_widget( $args ) ) {
				return;
			}

			ob_start();

			$number = ! empty( $instance['number'] ) ? absint( $instance['number'] ) : $this->settings['number']['std'];


			add_filter( 'posts_clauses',  array( WC()->query, 'order_by_rating_post_clauses' ) );

			$query_args = array( 'posts_per_page' => $number, 'no_found_rows' => 1, 'post_status' => 'publish', 'post_type' => 'product' );

			$query_args['meta_query'] = WC()->query->get_meta_query();

			$r = new WP_Query( $query_args );

	    	$rows= isset($instance['rows']) ? intval($instance['rows']) : $r->post_count;
		    $is_carousel =  $r->post_count > $rows;
		    $current_post=1;

			if ( $r->have_posts() ) {

				$this->widget_start( $args, $instance );

				if($is_carousel){

				    wp_enqueue_style('owl.carousel',DETHEME_VC_DIR_URL."css/owl.carousel.css",array());
				    wp_enqueue_script( 'owl.carousel', DETHEME_VC_DIR_URL . 'js/owl.carousel.js', array('jquery'), '', false );

				    print '<div class="product_carousel">';
				}

				echo '<ul class="product_list_widget">';

				while ( $r->have_posts() ) {
					$r->the_post();
					wc_get_template( 'content-widget-product.php', array( 'show_rating' => true ) );

					if( $is_carousel && !($current_post %  $rows) && $current_post < $r->post_count ){

					      echo '</ul><ul class="product_list_widget">';

					}

			        $current_post++;

				}

				echo '</ul>';
		  		if($is_carousel){
		  			print "</div>";
		  		}

				$this->widget_end( $args );
			}

			remove_filter( 'posts_clauses', array( WC()->query, 'order_by_rating_post_clauses' ) );

			wp_reset_postdata();

			$content = ob_get_clean();

			echo $content;

			$this->cache_widget( $args, $content );
		}

	}

	class Storefy_Widget_Recently_Viewed extends WC_Widget{

		public function __construct() {
			$this->widget_cssclass    = 'woocommerce storefy_widget_recently_viewed_products';
			$this->widget_description = esc_html__( 'Display a list of recently viewed products.', 'woocommerce' );
			$this->widget_id          = 'storefy_woocommerce_recently_viewed_products';
			$this->widget_name        = esc_html__( 'Storefy WC Recently Viewed', 'woocommerce' );
			$this->settings           = array(
				'title'  => array(
					'type'  => 'text',
					'std'   => esc_html__( 'Recently Viewed Products', 'woocommerce' ),
					'label' => esc_html__( 'Title', 'woocommerce' )
				),
				'number' => array(
					'type'  => 'number',
					'step'  => 1,
					'min'   => 1,
					'max'   => '',
					'std'   => 10,
					'label' => esc_html__( 'Number of products to show', 'woocommerce' )
				),
		      'rows'=>
		        array(
		          'type' => 'number',
		          'label' => esc_html__( 'Rows', 'storefy' ),
		          'step'  => 1,
		          'min'   => 1,
		          'std'   => 5,
		          'max'   => 10,
		        ),
			);

			parent::__construct();
		}

		/**
		 * Output widget.
		 *
		 * @see WP_Widget
		 *
		 * @param array $args
		 * @param array $instance
		 */
		public function widget( $args, $instance ) {

			$viewed_products = ! empty( $_COOKIE['woocommerce_recently_viewed'] ) ? (array) explode( '|', $_COOKIE['woocommerce_recently_viewed'] ) : array();
			if(function_exists('wooscarcity_get_viewed_lists') && $wooscarcity_views=wooscarcity_get_viewed_lists()){
				$viewed_products=array_merge($wooscarcity_views, $viewed_products);
			}
			$viewed_products = array_filter( array_map( 'absint', $viewed_products ) );

			if ( empty( $viewed_products ) ) {
				return;
			}

			ob_start();

			$number = ! empty( $instance['number'] ) ? absint( $instance['number'] ) : $this->settings['number']['std'];

			$query_args = array( 'posts_per_page' => $number, 'no_found_rows' => 1, 'post_status' => 'publish', 'post_type' => 'product', 'post__in' => $viewed_products, 'orderby' => 'rand' );

			$query_args['meta_query']   = array();
			$query_args['meta_query'][] = WC()->query->stock_status_meta_query();
			$query_args['meta_query']   = array_filter( $query_args['meta_query'] );


			$r = new WP_Query( $query_args );

	    	$rows= isset($instance['rows']) ? intval($instance['rows']) : $r->post_count;
		    $is_carousel =  $r->post_count > $rows;
		    $current_post=1;

			if ( $r->have_posts() ) {

				$this->widget_start( $args, $instance );

				if($is_carousel){

				    wp_enqueue_style('owl.carousel',DETHEME_VC_DIR_URL."css/owl.carousel.css",array());
				    wp_enqueue_script( 'owl.carousel', DETHEME_VC_DIR_URL . 'js/owl.carousel.js', array('jquery'), '', false );

				    print '<div class="product_carousel">';
				}

				echo '<ul class="product_list_widget">';

				while ( $r->have_posts() ) {
					$r->the_post();
					wc_get_template( 'content-widget-product.php' );

					if( $is_carousel && !($current_post %  $rows) && $current_post < $r->post_count ){
					      echo '</ul><ul class="product_list_widget">';
					}
			        $current_post++;
				}

				echo '</ul>';

		  		if($is_carousel){
		  			print "</div>";
		  		}

				$this->widget_end( $args );
			}

			wp_reset_postdata();

			$content = ob_get_clean();

			echo $content;
		}
	}
}

function storefy_widgets_init(){

	// sidebar widget
	register_sidebar(
		array('name'=> esc_html__('Sidebar Widget Area', 'storefy'),
			'id'=>'sidebar',
			'description'=> esc_html__('Sidebar Widget Area', 'storefy'),
			'before_widget' => '<div class="widget %s %s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="widget_title"><span>',
			'after_title' => '</span></h3>'
		));

	register_sidebar(
		array('name'=> esc_html__('Bottom Widget Area', 'storefy'),
			'id'=>'sidebar-bottom',
			'description'=> esc_html__('Bottom Widget Area', 'storefy'),
			'before_widget' => '<div class="widget %s %s">',
			'after_widget' => '</div>',
			'before_title' => '<div class="row"><div class="col col-sm-12 centered"><h3 class="widget-title">',
			'after_title' => '</h3></div></div>'

		));

	register_sidebar(
		array('name'=> esc_html__('Sticky Widget Area', 'storefy'),
			'id'=>'storefy-scrolling-sidebar',
			'description'=> esc_html__('Sticky Widget Area', 'storefy'),
			'before_widget' => '<div class="widget %s %s">',
			'after_widget' => '</div>',
			'before_title' => '<div class="row"><div class="col col-sm-12 centered"><h3>',
			'after_title' => '</h3></div></div>'

		));

	if (storefy_plugin_is_active('woocommerce/woocommerce.php')) {

		register_sidebar(
			array('name'=> esc_html__('Shop Sidebar Widget Area', 'storefy'),
				'id'=>'shop-sidebar',
				'description'=> esc_html__('Sidebar will display on woocommerce page only', 'storefy'),
				'before_widget' => '<div class="widget %s %s">',
				'after_widget' => '</div>',
				'before_title' => '<h3 class="widget_title"><span>',
				'after_title' => '</span></h3>'
			));

	}

	register_widget('DT_Tabs');
	register_widget('DT_Accordion');

	if (storefy_plugin_is_active('woocommerce/woocommerce.php') && class_exists('WC_Widget') && storefy_plugin_is_active('storefy-vc-addon/storefy_vc_addon.php')) {
		register_widget( 'Storefy_Widget_Products' );
		register_widget( 'Storefy_Widget_Top_Rated_Products' );
		register_widget( 'Storefy_Widget_Recently_Viewed' );
	}
}

add_action('widgets_init', 'storefy_widgets_init',1);
?>

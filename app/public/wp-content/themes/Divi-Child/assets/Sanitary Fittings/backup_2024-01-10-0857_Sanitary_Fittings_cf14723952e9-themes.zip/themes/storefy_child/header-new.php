<?php
/**
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
*/
defined('ABSPATH') or die();
?>
<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8) ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<?php 
require_once( get_template_directory().'/lib/page-options.php'); ?>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php echo esc_url(bloginfo( 'pingback_url' )); ?>">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); print esc_attr(get_storefy_option('body_tag',''));?> data-speed="5" data-type="background">
    <script>
    function js_Load()
    {
        
        document.body.style.visibility='visible';
        
    }
    </script>
    
	<?php
	$logo_img = get_storefy_option('dt-logo-image');
	$logo = isset($logo_img['url']) ? $logo_img['url'] : "";
	$logoContent="";
	if(!empty($logo)){
		$alt_image = isset($logo_img['id']) ? get_post_meta($logo_img['id'], '_wp_attachment_image_alt', true) : "";
		$logoContent='<a class="hidden-lg hidden-md hidden-sm mob-logo" href="'.esc_url(home_url('/')).'"><img src="'.esc_url(storefy_maybe_ssl_url($logo)).'" alt="'.esc_attr($alt_image).'" /></a>';
	}
	else{
		$logo_text=get_storefy_option('dt-logo-text');
		if(empty($logo_text)) $logo_text=get_bloginfo('name','raw');
		$blogdescription=get_bloginfo('description','raw');
		$logoContent='<a class="hidden-lg hidden-md hidden-sm mob-logo" href="'.esc_url(home_url('/')).'">'.esc_html($logo_text).(!empty($blogdescription)? "<span>".esc_html($blogdescription)."</span>":"" ).'</a>';
	}
    ?>
	<div class="paspartu_top"></div>
	<div class="paspartu_left"></div>
	<div class="paspartu_right"></div>
	<div class="paspartu_bottom"></div>	
	<div class="paspartu_inner">
		<div id="top-bar">
			<div class="container">
				<div class="top-bar-container">
					<div class="left-menu">
						<div class="topbar-text" style="margin-top:0px">
							<?php echo $logoContent; ?>
							<ul id="menu-right-menu" class="topbar-menu">
								<li id="menu-item-341" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-341 hidden-xs">
									<a href="/my-account/" style="padding-left:0; padding-top:0; padding-bottom:0; padding-right:1.42em;"><b>My Account</b></a>
								</li>
								<li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-342 hidden-xs"><a href="/contact-us"><b>Customer Care</b></a></li>
								<li class=" menu-item menu-item-type-custom hidden-xs">
									<?php global $woocommerce;
			                        $cart_url = $woocommerce->cart->get_cart_url();?>
			                        <a href="<?php echo $cart_url; ?>" title="Shopping Cart">
										<?php $cart_count= WC()->cart->get_cart_contents_count() ? WC()->cart->get_cart_contents_count() : 0;?>
										<span class="icon-cart"></span>
					                    <span class="item-count-container"><span class="item_count"><?php echo $cart_count ?></span></span>
					                    </span>
					                </a>
					            </li>
							</ul>
							<a class="toggle-mob-menu" href="">
					            <div class="menu-btn" id="menu-btn">
					               <span></span>
					               <span></span>
					               <span></span>
					            </div>
					       	</a>
						</div>
					</div>
					<div class="right-menu">
							<div id="dt-topbar-menu-right" class="menu-right-menu-container"><ul id="menu-right-menu" class="topbar-menu"><li id="menu-item-340" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-340"><a href="/request--a-quote?source=top"><span class="icon-quote"></span><b>Request Free Quote</b></a></li> 
							</ul>
						</div>      
					</div>
				</div>
			</div>
			<?php  get_template_part('pagetemplates/main_navigation-mainmenu-mob'); ?>
		</div>
		<?php get_template_part('pagetemplates/preloader'); ?>
		<?php if(get_storefy_option('showtopbar',true)): 
			get_template_part('pagetemplates/top-bar');?>
		<?php endif;?>

		<?php get_template_part('pagetemplates/heading-new');?>

		<section class="top-head">
			<?php 
			get_template_part('pagetemplates/main_navigation-new');
			?>
		</section>
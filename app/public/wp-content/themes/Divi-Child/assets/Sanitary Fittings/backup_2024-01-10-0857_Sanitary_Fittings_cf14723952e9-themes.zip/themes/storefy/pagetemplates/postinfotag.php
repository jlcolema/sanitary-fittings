<?php
defined('ABSPATH') or die();
?>
<ul class="author_date_tags">
	<li class="blog_info_author"><?php the_author_link(); ?></li>
<?php 
	$date = get_the_date();
	if (!empty($date)) :
		$title=get_the_title();
		$date = (!empty($title)) ? $date : '<a href="'.esc_url(get_permalink()).'">'.$date.'</a>';
?>
	<li class="blog_info_date"><?php print $date;?></li>
<?php
	endif;
?>

<?php 
	$tags=get_the_tag_list('',', ');
if (!empty($tags)) : ?>
<li class="blog_info_tags"><?php echo $tags; ?></li>
<?php endif;  ?>
<?php if(comments_open()):?>
<li class="blog_info_comment"><?php comments_number(esc_html__('No Comments','storefy'),esc_html__('1 Comment','storefy'),esc_html__('% Comments','storefy')); ?></li>
<?php endif;?>

</ul>

<?php

defined('ABSPATH') or die();

/**

 * The main navigation file

 *

 * @package WordPress

 * @subpackage Storefy

 * @since Storefy 1.0

 */



$left_content = "";



if( get_storefy_option( 'header-left-menu' )){

  ob_start();

  get_template_part( 'pagetemplates/main_navigation-leftmenu-new');

  $left_content=ob_get_clean();

}



ob_start();

get_template_part( 'pagetemplates/main_navigation-mainmenu-newer');

$right_content=ob_get_clean();

?>

<div class="container">

    <div class="row">

      <?php if(!empty($left_content)):?>

      <div class="col-xs-12 col-lg-3 left-nav-col">

      <?php print $left_content;?>

      </div>

      <div class="col-xs-12 col-lg-9 right-nav-col">

      <?php else:?>

      <div class="row">

      <?php endif;?>

      <?php print $right_content;?>

      </div>

    </div>

</div>
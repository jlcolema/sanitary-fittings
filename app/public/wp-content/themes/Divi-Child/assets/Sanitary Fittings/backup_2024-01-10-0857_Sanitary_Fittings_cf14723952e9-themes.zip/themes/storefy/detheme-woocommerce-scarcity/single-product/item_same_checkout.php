<?php
/**
 *
 * @author  Detheme
 * @package Woscarcity/Templates
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product, $woocommerce_loop, $post;


if ( empty( $product ) || ! $product->exists() ) {
	return;
}


if ( sizeof( $products ) === 0 ) return;
$woocommerce_loop['columns'] = $columns;
$template=isset($template) ? $template : "";
$products_num= count($products);

?>
<div class="wooscarcity-same-checkout products">
	<h2><?php esc_html_e( 'Customers who bought this product also purchased', 'wooscarcity' ); ?></h2>
<?php 
if(storefy_plugin_is_active('storefy-vc-addon/storefy_vc_addon.php')):

$is_carousel = $products_num > $columns;
if($is_carousel){
   wp_enqueue_style('owl.carousel',DETHEME_VC_DIR_URL."css/owl.carousel.css",array());
   wp_enqueue_script( 'owl.carousel', DETHEME_VC_DIR_URL . 'js/owl.carousel.js', array('jquery'), '', false );

	$product_per_slide = $columns;
	$pages = ceil( $products_num / $product_per_slide );
	$current_page=1;
	$current_post=1;
?>
	<div class="product_carousel">
<?php }?>
	<?php woocommerce_product_loop_start(); ?>
		<?php foreach ( $products  as $post) : ?>
			<?php 

			if($template=='widget'){
				$product = new WC_Product( $post );
				wc_get_template( 'content-widget-product.php',compact('product') );
			}
			else{
				wc_get_template_part( 'content', 'product' );
			} ?>

<?php
			if($is_carousel){ 
				if(!($current_post %  $product_per_slide) && $current_post < $products_num ){
					woocommerce_product_loop_end(); 
					woocommerce_product_loop_start();
				}
				$current_post++;
			}
?>
		<?php endforeach; // end of the loop. ?>
	<?php woocommerce_product_loop_end(); ?>
<?php if($is_carousel):?>
	</div>
<?php endif;?>
<!-- plugin vc addon -->
<?php else:?>
	<?php woocommerce_product_loop_start(); ?>
		<?php foreach ( $products  as $post) : ?>
			<?php 

			if($template=='widget'){
				$product = new WC_Product( $post );
				wc_get_template( 'content-widget-product.php',compact('product') );
			}
			else{
				wc_get_template_part( 'content', 'product' );
			} ?>

		<?php endforeach; // end of the loop. ?>
	<?php woocommerce_product_loop_end(); ?>

<?php endif;?>
</div>
<?php
woocommerce_reset_loop();
wp_reset_postdata();
?>

<?php
/**
 *
 * @author 		Detheme
 * @package 	WooCommerce/Templates
 * @version     1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if(!count($action_lists)) return;

?>
<ul class="product-loop-action">
<?php foreach ($action_lists as $action_name => $action) {?>
<li class="<?php print sanitize_html_class($action_name);?>"><?php print $action;?></li>
<?php }?>
</ul>

jQuery(document).ready(function($){
	
//alert('loaded');
 

setTimeout(function(){ 

	$('#view_more_section').hide();

	$('#view_less_button').hide();
	$( "#view_more_button" ).show();



	//$('#view_more_button').click(function(){



	$( "#view_more_button" ).on( "click", function () {	



		//console.log('clicked #view_more_button');

		$('#view_more_section').toggle();

		$('#view_more_button').toggle();

		$('#view_less_button').toggle();

	});



	$( "#view_less_button" ).on( "click", function () {	



		//alert('two');

		$('#view_more_section').toggle();

		$('#view_more_button').toggle();

		$('#view_less_button').toggle();

	});



}, 1000);



$( ".variations_form" ).on( "woocommerce_variation_select_change", function () {

	

setTimeout(function(){ 

	$('#view_more_section').hide();

	$('#view_less_button').hide();

	$( "#view_more_button" ).show();

	$( "#view_more_button" ).on( "click", function () {			

		$('#view_more_section').toggle();

		$('#view_more_button').toggle();

		$('#view_less_button').toggle();

	});



	$( "#view_less_button" ).on( "click", function () {	

		$('#view_more_section').toggle();

		$('#view_more_button').toggle();

		$('#view_less_button').toggle();

	});


	var attribute_counter=0;

	$( ".more-values" ).each(function( index ) {

  		//console.log( index + ": " + $( this ).text() );

  			var custom_attribute_value = $(this).text();

  			if(custom_attribute_value==''){  				

  				$(this).closest('.spec-row').hide();

  				//$('#view_more_button').hide();

  			} 

  			else{

  				 attribute_counter=attribute_counter+1; 

  				 console.log(attribute_counter);  				

  			} 

  			if(attribute_counter<=1){ 

  				$('#view_more_button').hide();

  			}else{

  				$('#view_more_button').show();

  			}


		});



	$( ".drawing_url" ).each(function( index ) {


		var custom_attribute_href = $(this).attr("href");

		//console.log(custom_attribute_href);

			if(custom_attribute_href==''){

				$(this).closest('.spec-row').hide();

			}else{

				$('#view_more_button').show();

			}


	});	


	}, 1000);


	} );



setTimeout(function(){ 

		var attribute_count=0;

	$( ".more-values" ).each(function( index ) {

  		console.log( index + ": " + $( this ).text() );	

  				var custom_attribute_value = $(this).text();

  			if(custom_attribute_value==''){
  				

  				$(this).closest('.spec-row').hide();

  				//$('#view_more_button').hide();

  			}else{

  				 attribute_count=attribute_count+1; 

  			} 

  			if(attribute_count<=1){  

  				$('#view_more_button').hide();

  			}else{

  				$('#view_more_button').show();

  			}


		});



	$( ".drawing_url" ).each(function( index ) {


		var custom_attribute_href = $(this).attr("href");

		//console.log(custom_attribute_href);

			if(custom_attribute_href==''){

				$(this).closest('.spec-row').hide();

			}else{

				$('#view_more_button').show();

			}

	});	

	}, 2000);


	});
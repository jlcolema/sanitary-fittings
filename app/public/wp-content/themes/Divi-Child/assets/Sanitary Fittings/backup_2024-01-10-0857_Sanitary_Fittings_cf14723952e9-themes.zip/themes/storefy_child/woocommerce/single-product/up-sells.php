<?php
 
/* crossells */
 
$crosssell_ids = get_post_meta( get_the_ID(), '_crosssell_ids' ); 
$crosssell_ids=$crosssell_ids[0];
 
?>
	<div class="up-sells upsells products">
<h3><?php esc_html_e( 'You May Need', 'storefy' ) ?></h3>


<ul class="products upsell-products">

<?php
if(count($crosssell_ids)>0){
$args = array( 'post_type' => 'product', 'posts_per_page' => 10, 'post__in' => $crosssell_ids );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post();
?>
<li style="">
	<div class="row">
		<div class="col-sm-12 col-lg-3 col-xs-4">
			<div class="widget-product-image upsell-image">
				<a href='<?php the_permalink(); ?>'>
					<?php the_post_thumbnail( 'thumbnail' ); ?>
				</a>
			</div>
		</div>
		<div class="col-sm-12 col-lg-9 col-xs-8">
			<div class="widget-product-summary upsell-text">
				<a href='<?php the_permalink(); ?>'>
					<?php the_title(); ?>
				</a>
			</div>
		</div>
	</div>
</li>
<?php endwhile; }?>
</ul>
</div>

<?php wp_reset_postdata(); ?>
<?php defined('ABSPATH') or die();?>
<?php if(is_rtl()):?>
	<ul class="social-share-button-group">
		<li><a href="<?php print esc_url( 'https://plus.google.com/share');?>" data-url="<?php echo esc_url(get_permalink()); ?>"><span class="post-share icon-social-google109"></span></a></li>
		<li><a href="<?php print esc_url( 'https://twitter.com/intent/tweet');?>" data-url="<?php echo esc_url(get_permalink()); ?>"><span class="post-share icon-social-twitter35"></span></a></li>
		<li><a href="<?php print esc_url( 'https://www.facebook.com/sharer/sharer.php');?>" data-url="<?php echo esc_url(get_permalink()); ?>"><span  class="post-share icon-social-facebook43"></span></a></li>
	</ul>
	<span class="share-label"><i class="storefy-plus"></i></span>
<?php else:?>
	<span class="share-label"><i class="storefy-plus"></i></span>
	<ul class="social-share-button-group">
		<li><a href="<?php print esc_url( 'https://www.facebook.com/sharer/sharer.php');?>" data-url="<?php echo esc_url(get_permalink()); ?>"><span class="post-share storefy-facebook"></span></a></li>
		<li><a href="<?php print esc_url( 'https://twitter.com/intent/tweet');?>" data-url="<?php echo esc_url(get_permalink()); ?>"><span class="post-share storefy-twitter"></span></a></li>
		<li><a href="<?php print esc_url( 'https://plus.google.com/share');?>" data-url="<?php echo esc_url(get_permalink()); ?>"><span class="post-share storefy-google-plus"></span></a></li>
	</ul>
<?php endif;?>
<?php
/**
 * Cart Page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if(function_exists('WC') && get_storefy_option( 'show-header-shoppingcart',false)){
    $cart_count = WC()->cart->get_cart_contents_count() ? WC()->cart->get_cart_contents_count() : 0;
    if($cart_count > 0) {
    	echo '<p class="cart-count">' . $cart_count.__(' items in your cart') . '</p>';
    	
    }
}
?>

<p class="empty-cart">
<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'cart-pdf' => '1' ), wc_get_cart_url() ), 'cart-pdf' ) );?>" style="display: inline-block;text-align: center;width: 100%;" target="_blank" onclick="gtag('event', 'PDF', {'event_category' : 'Download','event_label' : 'Shopping Cart'});">
<?php esc_html_e( get_option( 'wc_cart_pdf_button_label', __( 'Download Cart as PDF', 'wc-cart-pdf' ) ) ); ?>
</a>
</p>    

<div class="row">
	<div class="divider"></div>
</div>







<?php
wc_print_notices();

do_action( 'woocommerce_before_cart' ); ?>
<?php

?>


<form class="woocommerce-cart-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
<?php do_action( 'woocommerce_before_cart_table' ); ?>
<table class="shop_table cart" cellspacing="0">
	<thead>
		<tr>
			<th class="product-image"><?php esc_html_e( 'Product', 'storefy' ); ?></th>
			<th class="product-price"><?php esc_html_e( 'Price', 'woocommerce' ); ?></th>
			<th class="product-quantity"><?php esc_html_e( 'Quantity', 'woocommerce' ); ?></th>
			<th class="product-subtotal"><?php esc_html_e( 'Total', 'woocommerce' ); ?></th>
			<th class="product-remove">&nbsp;</th>
		</tr>
	</thead>
	<tbody>
		<?php do_action( 'woocommerce_before_cart_contents' ); ?>

		<?php
		foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
			$_product     = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
			$product_id   = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

			if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
				?>
				<tr class="<?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">
					<td class="product-name">
						<div class="product-thumbnail">
							<?php
								$thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );

								if ( ! $_product->is_visible() ) {
									echo $thumbnail;
								} else {
									printf( '<a href="%s">%s</a>', esc_url( $_product->get_permalink( $cart_item ) ), $thumbnail );
								}
							?>
						</div>
						<div style="max-width:400px;">
							<?php
								if ( ! $_product->is_visible() ) {
									echo apply_filters( 'woocommerce_cart_item_name', $_product->get_title(), $cart_item, $cart_item_key ) . '&nbsp;';
								} else {
									echo apply_filters( 'woocommerce_cart_item_name', sprintf( '<a href="%s">%s </a>', esc_url( $_product->get_permalink( $cart_item ) ), $_product->get_title() ), $cart_item, $cart_item_key );
								}

								// Meta data
								echo WC()->cart->get_item_data( $cart_item );

								echo '<div class="clear"></div><dl class="variation"><dt>SKU:</dt><dd>' . $_product->get_sku() . '</dd></dl>';
								
								// Stock Begin
								if(get_post_meta( $_product->get_id(), '_text_field', true )){
									$stock = get_post_meta( $_product->get_id(), '_text_field', true );
									$stock_arr = explode(' ', $stock);
									$color = ( $stock_arr[0] <= 0 ) ? 'red' : 'green';
									echo '<div class="clear"></div><dl class="variation"><dt></dt><dd><span style="color:'.$color.';font-weight:bold;">' . $stock;
									
									//if( $stock_arr[0] <= 0 ) echo '<p><small>' //. __('This product is currently out of //stock.  Contact us for lead times.') . //'</small></p>';
									//echo '</span></dd></dl>';
								}
                                // Stock End

								// Backorder notification
								if ( $_product->backorders_require_notification() && $_product->is_on_backorder( $cart_item['quantity'] ) ) {
									echo '<p class="backorder_notification">' . esc_html__( 'Available on backorder', 'woocommerce' ) . '</p>';
								}
							?>
						</div>
					</td>

					<td class="product-price">
						<?php
							echo apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
						?>
					</td>

					<td class="product-quantity">
						<?php
							if ( $_product->is_sold_individually() ) {
								$product_quantity = sprintf( '1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key );
							} else {
								$product_quantity = woocommerce_quantity_input( array(
									'input_name'  => "cart[{$cart_item_key}][qty]",
									'input_value' => $cart_item['quantity'],
									'max_value'   => $_product->backorders_allowed() ? '' : $_product->get_stock_quantity(),
									'min_value'   => '0'
								), $_product, false );
							}

							echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item );
						?>
					</td>

					<td class="product-subtotal">
						<?php
							echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key );
						?>
					</td>

					<td class="product-remove">
						<?php
							echo apply_filters( 'woocommerce_cart_item_remove_link', sprintf(
								'<a href="%s" class="vi-remove" title="%s" data-product_id="%s" data-product_sku="%s"><span class="icon-times"></span> Remove</a>',
								esc_url( WC()->cart->get_remove_url( $cart_item_key ) ),
								esc_html__( 'Remove this item', 'woocommerce' ),
								esc_attr( $product_id ),
								esc_attr( $_product->get_sku() )
							), $cart_item_key );
						?>
					</td>
				</tr>
				<?php
			}
		}

		do_action( 'woocommerce_cart_contents' );
		?>
		<tr>
			<td colspan="6" class="actions">
				<?php /*<input type="submit" class="button update_cart" name="update_cart" value="<?php esc_attr_e( 'Update Shopping Cart', 'storefy' ); ?>" /> */?>
				<?php do_action( 'woocommerce_cart_actions' ); ?>
				<?php wp_nonce_field( 'woocommerce-cart' ); ?>
				<?php /*<a class="button continue-shopping" href="<?php echo esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>">
					<?php esc_html_e( 'Continue Shopping', 'storefy' ) ?>
				</a>*/ ?>


			</td>
		</tr>

		<?php do_action( 'woocommerce_after_cart_contents' ); ?>
	</tbody>
</table>


<?php do_action( 'woocommerce_after_cart_table' ); ?>

</form>

<div class="cart-collaterals">
	<div class="row">
		
		<div class="col-lg-6 col-xs-12 col-md-6" style="float:right;width:100%!important;">
			<div class="row">
				<div class="col-lg-6 col-xs-12">
					<?php if ( wc_coupons_enabled() ) { ?>
					<form class="checkout_coupon coupon-box" method="post">	
						<div class="coupon">
							<input type="text" name="coupon_code" class="input-text" style="" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Coupon code', 'woocommerce' ); ?>" /> 
							<input type="submit" class="button continue-shopping" name="apply_coupon" value="<?php esc_attr_e( 'Apply', 'woocommerce' ); ?>" />
							<?php do_action( 'woocommerce_cart_coupon' ); ?>
						</div>
					</form>
					<?php } ?>
				</div>
				<div class="col-lg-6 col-xs-12">
					<?php woocommerce_cart_totals(); ?>				
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
woocommerce_cross_sell_display();
do_action( 'woocommerce_after_cart' ); 
?>
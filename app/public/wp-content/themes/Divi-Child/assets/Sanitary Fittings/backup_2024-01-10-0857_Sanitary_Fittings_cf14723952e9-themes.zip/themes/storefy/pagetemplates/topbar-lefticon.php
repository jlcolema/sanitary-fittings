<?php
defined('ABSPATH') or die();
/**
 * left top bar
 *
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */

$menu=get_storefy_option('dt-left-top-bar-menu');

if(!empty($menu)):

	$menuParams=array(
            	'menu'=>$menu,
            	'echo' => false,
            	'container_class'=>'left-menu',
            	'menu_class'=>'nav navbar-nav topbar-icon',
            	'container'=>'div',
                  'theme_location'=>'left-menu',
			'before' => '',
            	'after' => '',
            	'fallback_cb'=>false,
                  'walker' => new storefy_iconmenu_walker()
			);

	$menu=wp_nav_menu($menuParams);

	print ($menu)?$menu:"";
?>
<?php endif;?>

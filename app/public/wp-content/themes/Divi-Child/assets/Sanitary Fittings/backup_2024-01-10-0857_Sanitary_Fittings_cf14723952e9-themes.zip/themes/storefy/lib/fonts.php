<?php
defined('ABSPATH') or die();

function storefy_add_font_selector($buttons) {    
    
    $buttons[] = 'fontsizeselect';

    return $buttons;
}

add_filter('mce_buttons_2', 'storefy_add_font_selector');

function storefy_get_font_sizes($in){
    $in['fontsize_formats']=esc_html__("Bigger",'storefy')."=1.2em ".esc_html__('Big','storefy')."=1.1em ".esc_html__("Small",'storefy')."=0.9em ".esc_html__("Smaller",'storefy')."=0.8em";
 return $in;
}

add_filter('tiny_mce_before_init', 'storefy_get_font_sizes');
?>
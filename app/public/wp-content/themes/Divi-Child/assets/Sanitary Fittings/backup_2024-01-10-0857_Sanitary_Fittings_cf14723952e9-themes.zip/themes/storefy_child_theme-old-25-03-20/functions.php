<?php

defined('ABSPATH') or die();



/**

 * Hide shipping rates when free shipping is available.

 * Updated to support WooCommerce 2.6 Shipping Zones.

 *

 * @param array $rates Array of rates found for the package.

 * @return array

 */



function my_hide_shipping_when_free_is_available( $rates ) {

	$free = array();

	foreach ( $rates as $rate_id => $rate ) {

		if ( 'free_shipping' === $rate->method_id ) {

			$free[ $rate_id ] = $rate;

			break;

		}

	}

	return ! empty( $free ) ? $free : $rates;

}

add_filter( 'woocommerce_package_rates', 'my_hide_shipping_when_free_is_available', 100 );



//JDZ 02/21/2018 BEGIN
add_filter( 'woocommerce_subcategory_count_html', 'jk_hide_category_count' );
function jk_hide_category_count() {
	// No count
}

//JDZ 03/25/2018 BEGIN
// check for empty-cart get param to clear the cart
add_action( 'init', 'woocommerce_clear_cart_url' );
function woocommerce_clear_cart_url() {
  global $woocommerce;
	
	if ( isset( $_GET['empty-cart'] ) ) {
		$woocommerce->cart->empty_cart(); 
	}
}

add_filter( 'woocommerce_product_tabs', 'wcs_woo_remove_reviews_tab', 98 );

    function wcs_woo_remove_reviews_tab($tabs) {



    unset( $tabs['additional_information'] );  	// Remove the additional information tab

    return $tabs;

}



// Display 24 products per page. Goes in functions.php

add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 20;' ), 20 );



/**

 * Register widget area.

 *

 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar

 */

function shapely_widgets_init() {


	
	  register_sidebar(array(

        'id'            => 'footer-widget-new',

        'name'          =>  esc_html__( 'Footer Widget', 'storefy' ),

        'description'   =>  esc_html__( 'Used for footer widget area', 'storefy' ),

        'before_widget' => '<div id="%1$s" class="widget %2$s">',

        'after_widget'  => '</div>',

        'before_title'  => '<h2 class="widget-title">',

        'after_title'   => '</h2>',

      ));





    

}

add_action( 'widgets_init', 'shapely_widgets_init' );



function sizing_shortcode() {

return '<br/><h3 id="SizeDim" class="h3desc">Watch How to Measure Tri-Clamp Fittings</h3><iframe width="560" height="315" src="https://www.youtube.com/embed/qOOeZhMKZiQ" frameborder="0" allowfullscreen class="VideoPlayer"></iframe><h3 class="h3desc" id="sizingGuide">Tri-Clamp Fittings and Gasket Sizing Guide</h3><img width="1079" height="400" src="https://sanitaryfittings.us/wp-content/uploads/2018/01/SanitaryFittings_Dimensions-Image.png" class="image wp-image-8077  attachment-full size-full size_flange" alt="Sanitary Fitting Dimensions" style="height: auto; margin-top:20px;" srcset="https://sanitaryfittings.us/wp-content/uploads/2018/01/SanitaryFittings_Dimensions-Image.png 1079w, https://sanitaryfittings.us/wp-content/uploads/2018/01/SanitaryFittings_Dimensions-Image-300x111.png 300w, https://sanitaryfittings.us/wp-content/uploads/2018/01/SanitaryFittings_Dimensions-Image-768x285.png 768w, https://sanitaryfittings.us/wp-content/uploads/2018/01/SanitaryFittings_Dimensions-Image-1024x380.png 1024w" sizes="(max-width: 1079px) 100vw, 1079px">

<style>

th.size_th{background:#fff !important; color: #444444 !important; border-left: 0 !important; border-top: 0 !important; border-right: 0 !important; border-bottom: 2px solid #2574bc !important;}

th.size_th_first{background:#f5f5f5 !important; color: #444444 !important; border-left: 0 !important; border-top: 0 !important; border-right: 0 !important; border-bottom: 2px solid #2574bc !important;}

td.size_td {text-align: center; border-left: 0 !important; border-top: 0 !important; border-right: 0 !important; border-bottom: 1px solid #e8e8e8 !important; color: #444444;}

td.size_td_first {text-align: center; font-weight: bold; background:#f5f5f5; color: #444444; border-left: 0 !important; border-top: 0 !important; border-right: 0 !important; border-bottom: 1px solid #e8e8e8 !important; color: #444444;}

.size_table{margin-top:20px;}

.size_flange{max-width:480px !important;}

@media only screen and (max-width:450px){.size_table{margin-top:20px;width:80%;}

th.size_th{padding:10px 20px !important;}

th.size_th_first{padding:10px 20px !important;}

.size_flange{max-width:325px !important;}

}

</style>

<table class="size_table">

<tbody>

<tr>

<th class="size_th_first"><strong>Sanitary Size</strong></th>

<th class="size_th">OD of Flange End</th>

<th class="size_th">ID of Tube</th>

<th class="size_th">OD of Tube</th>

</tr>

<tr>

<td class="size_td_first">1/2″</td>

<td class="size_td">0.992</td>

<td class="size_td">0.370</td>

<td class="size_td">0.500</td>

</tr>

<tr>

<td class="size_td_first">3/4″</td>

<td class="size_td">0.992</td>

<td class="size_td">0.620</td>

<td class="size_td">0.750</td>

</tr>

<tr>

<td class="size_td_first">1″</td>

<td class="size_td">1.984</td>

<td class="size_td">0.870</td>

<td class="size_td">1.000</td>

</tr>

<tr>

<td class="size_td_first">1 1/2″</td>

<td class="size_td">1.984</td>

<td class="size_td">1.370</td>

<td class="size_td">1.500</td>

</tr>

<tr>

<td class="size_td_first">2″</td>

<td class="size_td">2.516</td>

<td class="size_td">1.870</td>

<td class="size_td">2.000</td>

</tr>

<tr>

<td class="size_td_first">2 1/2″</td>

<td class="size_td">3.047</td>

<td class="size_td">2.370</td>

<td class="size_td">2.500</td>

</tr>

<tr>

<td class="size_td_first">3″</td>

<td class="size_td">3.579</td>

<td class="size_td">2.870</td>

<td class="size_td">3.000</td>

</tr>

<tr>

<td class="size_td_first">4″</td>

<td class="size_td">4.682</td>

<td class="size_td">3.834</td>

<td class="size_td">4.000</td>

</tr>

<tr>

<td class="size_td_first">6″</td>

<td class="size_td">6.562</td>

<td class="size_td">5.782</td>

<td class="size_td">6.000</td>

</tr>

<tr>

<td class="size_td_first">8″</td>

<td class="size_td">8.602</td>

<td class="size_td">7.782</td>

<td class="size_td">8.000</td>

</tr>

<tr>

<td class="size_td_first">10″</td>

<td class="size_td">10.570</td>

<td class="size_td">9.782</td>

<td class="size_td">10.000</td>

</tr>

<tr>

<td class="size_td_first">12″</td>

<td class="size_td">12.570</td>

<td class="size_td">11.760</td>

<td class="size_td">12.000</td>

</tr>

</tbody>

</table>';

}

add_shortcode('sizing', 'sizing_shortcode');



/*6/11/2017 code for product gallery*/



add_action( 'after_setup_theme', 'yourtheme_setup' );

function yourtheme_setup() {

add_theme_support( 'wc-product-gallery-zoom' );

add_theme_support( 'wc-product-gallery-lightbox' );

add_theme_support( 'wc-product-gallery-slider' );

}



/** Disable Ajax Call from WooCommerce */

add_action( 'wp_enqueue_scripts', 'dequeue_woocommerce_cart_fragments', 11); 

function dequeue_woocommerce_cart_fragments() { if (!is_woocommerce() || is_product_category()) wp_dequeue_script('wc-cart-fragments'); }



//NO EMOJIS

remove_action( 'wp_head', 'print_emoji_detection_script', 7 );

remove_action( 'wp_print_styles', 'print_emoji_styles' );



/**

 * @snippet       Remove Variable Product Prices Everywhere

 * @how-to        Watch tutorial @ https://businessbloomer.com/?p=19055

 * @sourcecode    https://businessbloomer.com/disable-variable-product-price-range-woocommerce/

 * @author        Rodolfo Melogli

 * @compatible    WooCommerce 2.4.7

 */

 

add_filter( 'woocommerce_variable_sale_price_html', 'bbloomer_remove_variation_price', 10, 2 );

add_filter( 'woocommerce_variable_price_html', 'bbloomer_remove_variation_price', 10, 2 );

 

function bbloomer_remove_variation_price( $price ) {

$price = '';

return $price;

}



add_action( 'woocommerce_product_after_variable_attributes', 'variation_settings_fields', 10, 3 );

// Save Variation Settings

add_action( 'woocommerce_save_product_variation', 'save_variation_settings_fields', 10, 2 );

/**

 * Create new fields for variations

 *

*/

function variation_settings_fields( $loop, $variation_data, $variation ) {

	// Text Field

	woocommerce_wp_text_input( 

		array( 

			'id'          => '_text_field[' . $variation->ID . ']', 

			'label'       => __( 'My Text Field', 'woocommerce' ), 

			'placeholder' => 'http://',

			'desc_tip'    => 'true',

			'description' => __( 'Enter the custom value here.', 'woocommerce' ),

			'value'       => get_post_meta( $variation->ID, '_text_field', true )

		)

	);

}

/**

 * Save new fields for variations

 *

*/

function save_variation_settings_fields( $post_id ) {

	// Text Field

	$text_field = $_POST['_text_field'][ $post_id ];

	if( ! empty( $text_field ) ) {

		update_post_meta( $post_id, '_text_field', esc_attr( $text_field ) );

	}

}





/* Add Show All Products to Woocommerce Shortcode */

function woocommerce_shortcode_display_all_products($args)

{

 if(strtolower(@$args['post__in'][0])=='all')

 {

  global $wpdb;

  $args['post__in'] = array();

  $products = $wpdb->get_results("SELECT ID FROM ".$wpdb->posts." WHERE `post_type`='product'",ARRAY_A);

  foreach($products as $k => $v) { $args['post__in'][] = $products[$k]['ID']; }

 }

 return $args;

}

add_filter('woocommerce_shortcode_products_query', 'woocommerce_shortcode_display_all_products');



//Require Company Name

function sv_require_wc_company_field( $fields ) {

    $fields['company']['required'] = true;

    return $fields;

}

add_filter( 'woocommerce_default_address_fields', 'sv_require_wc_company_field' );



// Add New Variation Settings

add_filter( 'woocommerce_available_variation', 'load_variation_settings_fields' );

/**

 * Add custom fields for variations

 *

*/

function load_variation_settings_fields( $variations ) {

	

	// duplicate the line for each field

	$variations['text_field'] = get_post_meta( $variations[ 'variation_id' ], '_text_field', true );

	

	return $variations;

}



remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );



//JDZ 20180419 BEGIN
add_filter ( 'wc_add_to_cart_message', 'wc_add_to_cart_message_filter', 10, 2 );
function wc_add_to_cart_message_filter($message, $product_id ) {

//   $titles[] = get_the_title( $product_id );
//   $titles = array_filter( $titles );
//$added_text = sprintf( _n( '%s has been successfully added to your Basket.', '%s have been added to your Basket.', sizeof( $titles ), 'woocommerce' ), wc_format_list_of_items( $titles ) );



$message = sprintf( '%s <a href="/checkout" class="button">%s</a><a href="/cart" class="button" style="background: #fff !important;color: #1e73be !important;font-weight: normal;margin-right:10px;">View Cart</a>',
               '<span style="color:#616876!important;font-size:20px;"><img src="https://sanitaryfittings.us/wp-content/uploads/2020/01/Vector.png"/>  Added to Cart</span>',
               esc_html__( 'Proceed to Checkout', 'woocommerce' ));


return $message;
}
//JDZ 20180419 END





?>
<?php
defined('ABSPATH') or die();
/**
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */
?>
<?php
  $menu=get_storefy_option('header-left-menu-id');

  if(empty($menu)) return;

  $menuParams = array(
        'menu' => $menu,
        'echo' => false,
        'container_class'=> 'main-menu-container',
        'container_id'=>'main-menu',
        'menu_class'=>'main-menu',
        'container'=>'ul',
        'before' => '',
        'after' => '',
        'fallback_cb'=>false,
        'nav_menu_item_id'=>'main-menu-item-',
        'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
        'walker'  => new storefy_mainmenu_walker()
  );

if($left_menu = wp_nav_menu($menuParams)){

$menu_title=get_storefy_option('header-left-menu-title');
$legend_text= !empty($menu_title ) ? (function_exists('icl_t') ? icl_t('storefy', 'header-left-menu-title', $menu_title) : $menu_title ) : esc_html__('shop all categories','storefy');

?>
  <div class="left-navigation-container">
    <ul class="left-navigation-menu">
      <li class="toggle-menu">
     <a href="#"><?php print $legend_text; ?>
        <span class="menu-bar">
          <span></span>
          <span></span>
          <span></span>
      </span>
    </a>
      </li>
      <li class="menu-container">
            <?php print $left_menu;?>
      </li>
  </ul>
  </div>

<?php } ?>



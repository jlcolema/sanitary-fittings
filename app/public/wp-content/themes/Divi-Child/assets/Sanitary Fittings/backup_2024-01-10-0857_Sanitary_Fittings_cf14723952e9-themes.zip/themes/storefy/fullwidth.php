<?php
defined('ABSPATH') or die();
/**
 * Template Name: Fullwidth
 *
 * This is the most generic template file in a WordPress theme and one
 * of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query,
 * e.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */

get_header();
set_query_var('sidebar','nosidebar');
?>
<div class="content no-padding">
<div class="nosidebar">
<?php 
	$i = 0;

	while ( have_posts() ) :
		$i++;
		if ($i==1) :
?>
	<div class="blank-reveal-area"></div>
<?php 	endif; 
	the_post();
?>
<?php if(get_storefy_option('dt-show-title-page')):?>
						<h1 class="page-title"><?php the_title();?></h1>
<?php endif;?>
						<div class="post-article">
<!-- start content -->
<?php the_content(); 
	wp_link_pages( storefy_get_link_pages_args() );
?>
<!-- end content -->
						</div>

<?php
	if(comments_open()):?>
						<div class="container">
							<div class="comment-count">
								<h3><?php comments_number(esc_html__('No Comments','storefy'),esc_html__('1 Comment','storefy'),esc_html__('% Comments','storefy')); ?></h3>
							</div>

							<div class="section-comment">
								<?php comments_template('/comments.php', true); ?>
							</div><!-- Section Comment -->
						</div>
<?php endif;?>

<?php endwhile; ?>
			</div>
	</div>
<?php
get_footer();
?>
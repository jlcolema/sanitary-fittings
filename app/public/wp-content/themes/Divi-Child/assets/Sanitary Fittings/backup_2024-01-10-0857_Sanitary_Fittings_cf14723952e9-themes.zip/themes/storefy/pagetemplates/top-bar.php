<?php
defined('ABSPATH') or die();
/**
 * top bar view
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */

ob_start();
get_template_part( 'pagetemplates/topbar', "left".get_storefy_option('dt-left-top-bar','text'));
$left_topbar=ob_get_clean();

ob_start();
get_template_part( 'pagetemplates/topbar', "right".get_storefy_option('dt-right-top-bar','text'));
$right_topbar=ob_get_clean();

if(!empty($left_topbar) || !empty($right_topbar)) :
?>
<div id="top-bar">
	<div class="container">
		<div class="top-bar-container">
			<?php print $left_topbar;?>
			<?php print $right_topbar;?>
		</div>
	</div>
</div>
<?php endif;?>
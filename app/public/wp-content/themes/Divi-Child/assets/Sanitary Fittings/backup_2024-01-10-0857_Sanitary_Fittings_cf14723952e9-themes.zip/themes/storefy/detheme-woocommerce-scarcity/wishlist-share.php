<?php
/**
 *
 * @author  Detheme
 * @package Woscarcity/Templates
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$wishlist_link=urlencode(add_query_arg(array('wishlist_id'=>wooscarcity_get_wishlist_id()),wooscarcity_get_wishlist_link_page()));

$wishlist_title=urlencode(sprintf(esc_html__("My Wishlist on %s","wooscarcity"),get_bloginfo('name')));
$facebook_share_link= sprintf("https://www.facebook.com/sharer.php?s=100&p[title]=%s&p[url]=%s",$wishlist_title,$wishlist_link);
$twitter_share_link= sprintf("https://twitter.com/share?url=%s&text=%s",$wishlist_link,$wishlist_title);
$pinterest_share_link= sprintf("http://pinterest.com/pin/create/button/?url=%s&description=%s",$wishlist_link,$wishlist_title);
$gplus_share_link= sprintf("https://plus.google.com/share?url=%s&title=%s",$wishlist_link,$wishlist_title);
$mail_link= sprintf("mailto:?subject=%s&body=%s&title=%s",$wishlist_title,$wishlist_link,$wishlist_title);
?>

<div class="wooscarcity-wishlist-share blog_info_share">
	<span class="share-label"><i class="storefy-plus"></i></span>
	<ul class="wishlist-share-list social-share-button-group">
		<li class="facebook"><a href="<?php print esc_url($facebook_share_link);?>"><span class="post-share storefy-facebook"></span></a></li>
		<li class="twitter"><a href="<?php print esc_url($twitter_share_link);?>"><span class="post-share storefy-twitter"></span></a></li>
		<li class="pinterest"><a href="<?php print esc_url($pinterest_share_link);?>"><span class="post-share storefy-pinterest"></span></a></li>
		<li class="gplus"><a href="<?php print esc_url($gplus_share_link);?>"><span class="post-share storefy-google-plus"></span></a></li>
		<li class="email"><a href="<?php print esc_url($mail_link);?>"><span class="post-share storefy-mail"></span></a></li>
	</ul>
</div>
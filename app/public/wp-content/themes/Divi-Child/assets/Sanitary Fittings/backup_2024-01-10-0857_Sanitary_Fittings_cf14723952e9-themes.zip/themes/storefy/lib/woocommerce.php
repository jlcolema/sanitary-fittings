<?php
defined('ABSPATH') or die();

function storefy_wc_shop_class($input="",$echo=false){

  $col="";

  if ( is_shop() || is_product_category() || is_product_tag() || is_product_taxonomy()) {
    $col=get_option('loop_shop_columns',4);
  }

  if($col!=''){
    $input.=" columns-".$col;
  }

  if(!$echo)  return   $input;

  print "class=\"".$input."\"";
}

function storefy_wc_body_class( $classes ) {
  $classes = (array) $classes;

  $col="";

  if (is_product()){
    $col=get_option('loop_related_columns',3);
  }
  elseif(is_cart()){
    $col=get_option('loop_cross_sells_columns',2);
  }

  if($col!='') {
    $classes[] = "columns-".$col;
  }

  return array_unique( $classes );
}

function storefy_related_products_args($args){

  $col=get_option('loop_related_columns',3);

  if($related_per_page=get_option('loop_related_per_page')){
    $args['posts_per_page']=$related_per_page;  
  }

  $args['columns']=$col;
  return $args;

}

function storefy_woocommerce_upsell_display_args($args){

  $args['columns']=1;
  return $args;

}

function storefy_woocommerce_product_settings($settings=array()){

  if(is_array($settings) && count($settings)){

    $newsettings=array();

    foreach ($settings as $key => $setting) {

      array_push($newsettings, $setting);
      if(isset($setting['id']) && 'woocommerce_shop_page_id'==$setting['id']){

                array_push($newsettings,
                        array(
                          'title'    => esc_html__( 'Num Product Show', 'storefy' ),
                          'desc'     => esc_html__( 'This controls num product show', 'storefy' ),
                          'id'       => 'loop_per_page',
                          'default'  => get_option( 'posts_per_page'),
                          'type'     => 'number',
                          'css'      => 'width:50px;',
                          'custom_attributes' => array(
                            'min'  => 1,
                            'step' => 1,
                            'max' =>100
                          ),
                          'desc_tip' =>  true,
                        ),
                        array(
                        'title'    => esc_html__( 'Product Display Columns', 'storefy' ),
                        'desc'     => esc_html__( 'This controls num column product display', 'storefy' ),
                        'id'       => 'loop_shop_columns',
                        'class'    => 'wc-enhanced-select',
                        'css'      => 'min-width:300px;',
                        'default'  => '3',
                        'type'     => 'select',
                        'options'  => array(
                          '2' => esc_html__( 'Two Columns', 'storefy' ),
                          '3' => esc_html__( 'Three Columns', 'storefy' ),
                          '4' => esc_html__( 'Four Columns', 'storefy' ),
                          '5' => esc_html__( 'Five Columns', 'storefy' ),
                          '6' => esc_html__( 'Six Columns', 'storefy' ),
                        ),
                        'desc_tip' =>  true,
                      ),
                        array(
                          'title'    => esc_html__( 'Num Related/Cross-sell Product Show', 'storefy' ),
                          'desc'     => esc_html__( 'This controls num related/Cross-sell product show', 'storefy' ),
                          'id'       => 'loop_related_per_page',
                          'default'  => 4,
                          'type'     => 'number',
                          'css'      => 'width:50px;',
                          'custom_attributes' => array(
                            'min'  => 1,
                            'step' => 1,
                            'max' =>18
                          ),
                          'desc_tip' =>  true,
                        ),
                        array(
                        'title'    => esc_html__( 'Related/Upsell Product Display Columns', 'storefy' ),
                        'desc'     => esc_html__( 'This controls num column related/upsell product display', 'storefy' ),
                        'id'       => 'loop_related_columns',
                        'class'    => 'wc-enhanced-select',
                        'css'      => 'min-width:300px;',
                        'default'  => '3',
                        'type'     => 'select',
                        'options'  => array(
                          '2' => esc_html__( 'Two Columns', 'storefy' ),
                          '3' => esc_html__( 'Three Columns', 'storefy' ),
                          '4' => esc_html__( 'Four Columns', 'storefy' ),
                          '5' => esc_html__( 'Five Columns', 'storefy' ),
                          '6' => esc_html__( 'Six Columns', 'storefy' ),
                        ),
                        'desc_tip' =>  true,
                      )
                );
      }


    }

    return $newsettings;

  }

  return $settings;
}

function storefy_woocommerce_payment_gateways_settings($settings=array()){

  if(is_array($settings) && count($settings)){

    $newsettings=array();

    foreach ($settings as $key => $setting) {

      array_push($newsettings, $setting);

      if( isset($setting['id']) && 'woocommerce_checkout_page_id'== $setting['id'] ){

                array_push($newsettings,
                      
                        array(
                        'title'    => esc_html__( 'Cross Sell Display Columns', 'storefy' ),
                        'desc'     => esc_html__( 'This controls num column cross sell display', 'storefy' ),
                        'id'       => 'loop_cross_sells_columns',
                        'class'    => 'wc-enhanced-select',
                        'css'      => 'min-width:300px;',
                        'default'  => '3',
                        'type'     => 'select',
                        'options'  => array(
                          '2' => esc_html__( 'Two Columns', 'storefy' ),
                          '3' => esc_html__( 'Three Columns', 'storefy' ),
                          '4' => esc_html__( 'Four Columns', 'storefy' ),
                          '5' => esc_html__( 'Five Columns', 'storefy' ),
                          '6' => esc_html__( 'Six Columns', 'storefy' ),
                        ),
                        'desc_tip' =>  true,
                      ),
                        array(
                        'title'    => esc_html__( 'Cross Sell Display Product', 'storefy' ),
                        'desc'     => esc_html__( 'This controls num cross sell product display', 'storefy' ),
                        'id'       => 'loop_cross_sells_total',
                        'default'  => '3',
                        'type'     => 'number',
                        'css'      => 'width:50px;',
                        'custom_attributes' => array(
                          'min'  => 1,
                          'step' => 1,
                          'max' =>12
                        ),
                        'desc_tip' =>  true,
                      )
                );
      
      }


    }

    return $newsettings;

  }

  return $settings;

}

function storefy_woocommerce_order_button_html(){
  $order_button_text  = apply_filters( 'woocommerce_order_button_text', esc_html__( 'Place order', 'woocommerce' ));
  $button_html='<input type="submit" class="button btn" name="woocommerce_checkout_place_order" id="place_order" value="' . esc_attr( $order_button_text ) . '" data-value="' . esc_attr( $order_button_text ) . '" />';
  return $button_html;

}

function storefy_woocommerce_product_review_comment_form_args($comment_form=array()){

  $comment_form['class_submit']='btn btn-primary';
  return $comment_form;
}

function storefy_woocommerce_sale_price_html($price, $product){

  $display_price         = $product->get_display_price();
  $display_regular_price = $product->get_display_price( $product->get_regular_price() );

  $reduction = ( $display_regular_price - $display_price) * 100 / $display_regular_price;
  $reduction = number_format($reduction);

  $price = '<ins>' . ( ( is_numeric( $display_price ) ) ? wc_price( $display_price ) : $display_price ) . '<span class="woocommerce-rabat">-'.$reduction.'%</span></ins><del>' . ( ( is_numeric( $display_regular_price ) ) ? wc_price( $display_regular_price ) : $display_regular_price ) . '</del>';

  $price .= $product->get_price_suffix();


  return $price;

}

function storefy_woocommerce_sale_flash_html($html=""){

  $html='<div class="onsale-container"><span class="onsale">' . esc_html__( 'Sale!', 'woocommerce' ) . '</span></div>';

  return $html;

}

function storefy_woocommerce_template_single_stock_get_availability(){

  global $product;
  wc_get_template( 'single-product/stock.php',compact('product') );
}


function storefy_woocommerce_loop_stock_get_availability(){

  global $product;

  if(apply_filters('loop_product_show_stock',false)){
    wc_get_template( 'single-product/stock.php',compact('product') );
  }

}

function storefy_woocommerce_stock_get_availability(){

  global $product;

  if ( ! $product->is_purchasable() ) {
    return;
  }

    if ( ! $product->is_in_stock() ) {
      $availability = esc_html__( 'Out of stock', 'woocommerce' );
    } elseif ( $product->managing_stock() && $product->is_on_backorder( 1 ) ) {
      $availability = $this->backorders_require_notification() ? esc_html__( 'Available on backorder', 'woocommerce' ) : esc_html__( 'In stock', 'woocommerce' );
    } elseif ( $product->managing_stock() ) {
      switch ( get_option( 'woocommerce_stock_format' ) ) {
        case 'no_amount' :
          $availability = esc_html__( 'In stock', 'woocommerce' );
        break;
        case 'low_amount' :
          if ( $product->get_total_stock() <= get_option( 'woocommerce_notify_low_stock_amount' ) ) {
            $availability = sprintf( esc_html__( 'Only %s left in stock', 'woocommerce' ), $product->get_total_stock() );

            if ( $product->backorders_allowed() && $product->backorders_require_notification() ) {
              $availability .= ' ' . esc_html__( '(also available on backorder)', 'woocommerce' );
            }
          } else {
            $availability = esc_html__( 'In stock', 'woocommerce' );
          }
        break;
        default :
          $availability = sprintf( wp_kses( __( 'stock: <span>%s</span>', 'storefy' ),array('b'=>array(),'strong'=>array(),'span'=>array('class'))), $product->get_total_stock() );

          if ( $product->backorders_allowed() && $product->backorders_require_notification() ) {
            $availability .= ' ' . esc_html__( '(also available on backorder)', 'woocommerce' );
          }
        break;
      }
    } else {
      $availability = '';
    }

  if ( ! $product->is_in_stock() ) {
    $css_class = 'out-of-stock';
  } elseif ( $product->managing_stock() && $product->is_on_backorder( 1 ) && $product->backorders_require_notification() ) {
    $css_class = 'available-on-backorder';
  } else {
    $css_class = 'in-stock';
  }

  echo empty( $availability) ? '' : '<p class="stock ' . esc_attr( $css_class ) . '">' . $availability . '</p>';

}

function storefy_loop_product_show_thumbnail(){
  return apply_filters( 'storefy_woocommerce_template_loop_product_thumbnail', true );
}

function storefy_woocommerce_template_loop_product_thumbnail() {
  wc_get_template( 'loop/thumbnail.php' );
}


function storefy_woocommerce_get_product_thumbnail( $size = 'shop_catalog') {

  global $post;

  $image_size = apply_filters( 'single_product_archive_thumbnail_size', $size );

  if ( has_post_thumbnail() ) {
    $props = wc_get_product_attachment_props( get_post_thumbnail_id(), $post );
    return get_the_post_thumbnail( $post->ID, $image_size, array(
      'title'  => $props['title'],
      'alt'    => $props['alt'],
    ) );
  } elseif ( wc_placeholder_img_src() ) {
    return wc_placeholder_img( $image_size );
  }
}

function storefy_woocommerce_get_product_attributes($attributes){

//JDZ 02/28/2017 BEGIN
//  global $product;
//
//  if ($product && wc_product_sku_enabled() && ( $product->get_sku() || $product->is_type( 'variable' ) ) ){
//
//      $attribute=array(
//        'name'=>'product-sku',
//        'value'=>  ($sku = $product->get_sku() ) ? $sku : esc_html__( 'N/A', 'woocommerce' ),
//        'position' => 0,
//        'is_visible' => 1,
//        'is_variation' => 0,
//        'is_taxonomy' => 0
//      );
//
//      $attributes['product-sku']=$attribute;
//
//  }
//JDZ 02/28/2017 END
  return $attributes;
}

function storefy_widget_recent_viewed_products(){

    $type = 'Storefy_Widget_Recently_Viewed';

    $atts=array('title'=> esc_html__( 'Recently Viewed', 'storefy' ),'rows'=>4,'number'=>8);

    print "<div class=\"storefy-widget\">";
    the_widget( $type, $atts, array('widget_id'=>'storefy_recently_viewed_products') );
    print '</div>';
}

function storefy_woocommerce_product_additional_information_tab_title(){

    $tab_title=esc_html__('Specification','storefy');

    return $tab_title;
}

function storefy_woocommerce_product_additional_information_heading(){

  return esc_html('Detail Specification Item','storefy');
}

function storefy_woocommerce_product_description_heading(){

  return esc_html('Description Item','storefy');
}

function storefy_woocommerce_template_loop_add_to_cart($force=false){

  $show_add_to_cart=apply_filters('storefy_woocommerce_template_loop_add_to_cart_show',$force);

  if(!$show_add_to_cart) return;
  woocommerce_template_loop_add_to_cart();
}

function storefy_wooscarcity_load_loop_sale_countdown($force=false){


  if(function_exists('wooscarcity_load_loop_sale_countdown') && apply_filters('wooscarcity_load_loop_sale_countdown_show',$force)){
    wooscarcity_load_loop_sale_countdown();
  }

}

function storefy_wooscarcity_load_sold_time_message_html($message){

  return "<span class=\"urgency-message sold-time-message\">".$message."</span>";
}

function storefy_wooscarcity_load_sold_amount_message_html($message){

  return "<span class=\"urgency-message sold-amount-message\">".$message."</span>";
}

function storefy_woocommerce_template_loop_action_button(){

  $action_lists=apply_filters('storefy_woocommerce_loop_action_list',array());

  if(!count($action_lists)) return;
  wc_get_template( 'loop/action_list.php',compact('action_lists'));
}

function storefy_woocommerce_template_loop_excerpt(){

  wc_get_template( 'loop/short-description.php' );
}


function storefy_before_shop_loop(){

  print "<div class=\"before-shop-loop-container\">";

}

function storefy_before_shop_loop_close(){
  print "</div>";

  $loop_css=storefy_wc_shop_class("woocommerce");
  print "<div class=\"".esc_attr($loop_css)."\">";

  add_action( 'woocommerce_after_shop_loop', create_function('', 'return "</div>";'));

}


function storefy_woocommerce_catalog_post_perpage($post_per_page) {

  $per_page=isset($_GET['product_per_page']) ? intval($_GET['product_per_page']) : get_option('loop_per_page', $post_per_page); 
  return $per_page;
}


function storefy_woocommerce_taxonomy_archive_description(){

    if(is_single() || get_query_var( 's' ) !='' ) return;


    if ( is_tax( array( 'product_cat', 'product_tag' ) ) && 0 === absint( get_query_var( 'paged' ) ) ) {

      $category_content="";

      if(get_option( 'db_version' ) >= 34370 && $term = get_queried_object()){


        $term = get_queried_object();
        $taxonomy = $term->taxonomy;
        $term_id = $term->term_id;

        $category_description_id=get_term_meta($term_id, '_storefy_product_category_description', true);

        if($category_description_id){

          $post = storefy_get_wpml_post($category_description_id);

          if($post && !empty($post->post_content)){
             $category_content=$post->post_content;
          }

        }
      }

      if(empty($category_content)) $category_content=term_description();

      $description = wc_format_content( $category_content );

      if ( $description ) {
        echo '<div class="category term-description">' . $description . '</div>';
      }
    }

    if(is_shop() && $post_id=get_option( 'woocommerce_shop_page_id')){

      $post = storefy_get_wpml_post($post_id);

      if(!$post || is_wp_error($post) || empty($post->post_content)) return;

      $content=$post->post_content;
      $content = apply_filters( 'the_content', $content );

      echo '<div class="shop term-description">' . $content . '</div>';


    }
}


if(get_option( 'db_version' ) >= 34370 ) {


  function storefy_product_category_form($tag){

     $term_id= is_object($tag) && $tag->term_id ? $tag->term_id : 0;
     $category_description_id=get_term_meta($term_id, '_storefy_product_category_description', true);
?>
<table class="form-table"> 
<tr class="form-field">
    <th scope="row">
        <label for="catgeory-description"><?php esc_html_e('Page Description','storefy') ?></label>
    </th>
    <td>
<?php 
    $excludes=array();
    $dropdown=wp_dropdown_pages(array('name' => 'storefy_product_category_description', 'orderby' => 'name', 'selected' => $category_description_id, 'echo' => false,'exclude'=>$excludes ,'show_option_none'=>esc_html__('Not Select','storefy')));

    if(empty($dropdown)){
      $dropdown="<select name=\"storefy_product_category_description[]\" id=\"storefy_product_category_description\"><option value=\"\">".esc_html__('Not Select','storefy')."</option></select>";
    }

    print $dropdown;

?>
      <p class="description"><?php esc_html_e('If have selected page, category description will replace with page content','storefy');?></p>
    </td>
</tr>
</table>

<?php

  }

  function storefy_product_category_add_form(){?>

<div class="form-field catgeory-description-wrap">
  <label for="catgeory-description"><?php esc_html_e('Page Description','storefy') ?></label>
<?php 
    $excludes=array();
    $dropdown=wp_dropdown_pages(array('name' => 'storefy_product_category_description', 'orderby' => 'name', 'selected' => 0, 'echo' => false,'exclude'=>$excludes ,'show_option_none'=>esc_html__('Not Select','storefy')));

    if(empty($dropdown)){
      $dropdown="<select name=\"storefy_product_category_description[]\" id=\"storefy_product_category_description\"><option value=\"\">".esc_html__('Not Select','storefy')."</option></select>";
    }
    print $dropdown;
?>
  <p class="description"><?php esc_html_e('If have selected page, category description will replace with page content','storefy');?></p>
</div>

<?php 
  }

  function storefy_product_category_save_form($term_id){

    $product_catgory_id = isset($_POST['storefy_product_category_description']) ? intval($_POST['storefy_product_category_description']) : '';

    $old_category_id=get_term_meta($term_id, '_storefy_product_category_description', true);
    update_term_meta($term_id, '_storefy_product_category_description', $product_catgory_id, $old_category_id);

  }


  function storefy_product_category_description(){

        add_action( 'product_cat_edit_form','storefy_product_category_form',10,2);
        add_action( 'product_cat_add_form', 'storefy_product_category_add_form',10,2);
        add_action( 'edit_term', "storefy_product_category_save_form", 10, 3 );
        add_action( 'create_term', "storefy_product_category_save_form", 10, 3 );
  }


  add_action( 'admin_init', 'storefy_product_category_description' );

}

function storefy_woocommerce_cart_nums_add_to_cart_fragment($fragments){

  global $woocommerce; 

  $fragments['cart_total'] = $woocommerce->cart->get_cart_total();
  $fragments['cart_content_count'] = $woocommerce->cart->cart_contents_count;


  return $fragments;

}

if(storefy_plugin_is_active('detheme-woocommerce-scarcity/wc-scarcity.php')){

  function storefy_wooscarcity_add_wishlist_link($action_lists=array()){

    global $product;
    $link=wooscarcity_get_wishlist_link($product->id);
    $wishlist_link=wooscarcity_get_wishlist_link_page();
    $icon_class="storefy-product-wishlist";

    if(wooscarcity_is_in_wishlist($product->id)){
      $link=$wishlist_link;
      $icon_class="storefy-check-rounded";
    }

    //$action_lists['wishlist']='<a class="wooscarcity-add-to-wish" rel="'.esc_url($wishlist_link).'" href="'.esc_url($link).'"><i class="'.sanitize_html_class($icon_class).'"></i><span>'.esc_html('Wishlist','storefy').'</span></a>';
    $action_lists['wishlist']='<a class="wooscarcity-add-to-wish" href="'.esc_url($link).'"><i class="'.sanitize_html_class($icon_class).'"></i><span>'.esc_html('Wishlist','storefy').'</span></a>';

    return $action_lists;
  }

  function storefy_wooscarcity_single_wishlist_button(){

    global $product;

    if ( empty( $product ) || ! $product->exists() || wooscarcity_is_in_wishlist($product->id)) {
        return;
    }

    $link=wooscarcity_get_wishlist_link($product->id);
    
    print '<a class="wooscarcity-add-to-wish" href="'.esc_url($link).'"><i class="storefy-product-wishlist"></i></a>';

  }

  function storefy_wooscarcity_add_compare_link($action_lists=array()){

    global $product;
    $link=wooscarcity_get_compare_link($product->id);
    $compare_link=wooscarcity_get_compare_link_page();
    $icon_class="storefy-shuffle";

    if(wooscarcity_is_product_in_compare($product->id)){
      $link=$compare_link;
      $icon_class="storefy-check-rounded";
    }


    //$action_lists['compare']='<a class="wooscarcity-add-to-compare" rel="'.esc_url($compare_link).'"  href="'.esc_url($link).'"><i class="'.sanitize_html_class($icon_class).'"></i><span>'.esc_html('Compare','storefy').'</span></a>';
    $action_lists['compare']='<a class="wooscarcity-add-to-compare" href="'.esc_url($link).'"><i class="'.sanitize_html_class($icon_class).'"></i><span>'.esc_html('Compare','storefy').'</span></a>';

    return $action_lists;

  }

  function storefy_wooscarcity_single_product_add_compare(){

    global $product;

    if ( empty( $product ) || ! $product->exists() || wooscarcity_is_product_in_compare($product->id)) {
        return;
    }

    $link=wooscarcity_get_compare_link($product->id);
    
    print '<a class="wooscarcity-add-to-compare" href="'.esc_url($link).'"><i class="storefy-shuffle"></i></a>';

  }


  function storefy_wooscarcity_stock_scarcity_availability(){
    global $product;

      if ( $product &&  $product->managing_stock() ) {

              $stock=$product->get_total_stock();
              $availability="";

              if ( $product->is_in_stock() && $stock > get_option( 'woocommerce_notify_no_stock_amount' ) ) {


                  if($stock <= get_option( 'woocommerce_notify_low_stock_amount' )){

                      $minimum_stock_message=wooscarcity_get_setting('minimum_stock_message',esc_html__( 'Only %s left in stock', 'woocommerce' ));
                      $minimum_stock_plural_message=wooscarcity_get_setting('minimum_stock_plural_message',esc_html__( 'Only %s left in stock', 'woocommerce' ));

                      $availability = sprintf( $stock==1 ? $minimum_stock_message: $minimum_stock_plural_message, $stock );
                  }

                  $class        = 'in-stock';

              } elseif ( $product->backorders_allowed() && $product->backorders_require_notification() ) {

                  $availability = esc_html__( 'Available on backorder', 'woocommerce' );
                  $class        = 'available-on-backorder';
              } elseif ( $product->backorders_allowed() ) {

                  $availability = esc_html__( 'In stock', 'woocommerce' );
                  $class        = 'in-stock';

              } else {

                  $availability = esc_html__( 'Out of stock', 'woocommerce' );
                  $class        = 'out-of-stock';
              }


              $availability_html= (!empty($availability)) ? '<p class="stock-scarcity ' . esc_attr( $class ) . '">' . wp_kses($availability,array('b'=>array(),'strong'=>array(),'span'=>array('class'))) . '</p>' : "";
              print $availability_html;
      }

  }

 if(function_exists('wooscarcity_load_sale_countdown') && wooscarcity_get_setting('enable_countdown_timer')){

      $countdown_timer_position=wooscarcity_get_setting('countdown_timer_position','after-price');

      switch ($countdown_timer_position){

          case 'before-price':
               add_action( 'storefy_woocommerce_single_product_summary', 'wooscarcity_load_sale_countdown', 29 );
              break;
          case 'before-image':
              add_action( 'storefy_woocommerce_template_single_product_image', 'wooscarcity_load_sale_countdown', 2 );
              break;
          case 'after-image':
              add_action( 'woocommerce_after_single_product_summary', 'wooscarcity_load_sale_countdown', 9 );
              break;
          case 'after-price':
          default:
               add_action( 'storefy_woocommerce_single_product_summary', 'wooscarcity_load_sale_countdown', 31 );
      }
  
  }


  if(wooscarcity_get_setting('disable_same_checkout','1') !='1'){

    $same_checkout_position=wooscarcity_get_setting('same_checkout_position',18);


    if('11'== $same_checkout_position){
       add_filter('wooscarcity_get_product_same_checkout_args',create_function('$args', '$args[\'template\']=\'widget\';return $args;'));
       add_action('storefy_woocommerce_after_single_product_summary_sidebar','wooscarcity_same_checkout_products',5);
    }
    else{
       add_action('storefy_woocommerce_after_single_product_summary','wooscarcity_same_checkout_products',$same_checkout_position);
    }
  }

  if(wooscarcity_get_setting('disable_recent_viewed','1') !='1'){

    $recent_viewed_position=wooscarcity_get_setting('recent_viewed_position',18);

      switch($recent_viewed_position){

        case '11':
              add_action( 'storefy_woocommerce_after_single_product_summary_sidebar', 'storefy_widget_recent_viewed_products',8);
          break;
        case 'before_same_checkout':
                $same_checkout_position=wooscarcity_get_setting('same_checkout_position',18);

                if('11'== $same_checkout_position){
                  add_action( 'storefy_woocommerce_after_single_product_summary_sidebar', 'storefy_widget_recent_viewed_products',4);
                }
                else{
                  add_action('storefy_woocommerce_after_single_product_summary','wooscarcity_recent_viewed_products',($same_checkout_position - 1));
                }
          break;
        case 'after_same_checkout':
                $same_checkout_position=wooscarcity_get_setting('same_checkout_position',18);

                if('11'== $same_checkout_position){
                  add_action( 'storefy_woocommerce_after_single_product_summary_sidebar', 'storefy_widget_recent_viewed_products',6);
                }
                else{
                  add_action('storefy_woocommerce_after_single_product_summary','wooscarcity_recent_viewed_products',($same_checkout_position + 1));
                }
          break;
        default:
            add_action('storefy_woocommerce_after_single_product_summary','wooscarcity_recent_viewed_products',$recent_viewed_position);
          break;
      }
  }

  if(wooscarcity_get_setting('enable_urgency_amount_message')){
      $urgency_amount_message_position=wooscarcity_get_setting('urgency_amount_message_position','before-title');

      switch ($urgency_amount_message_position){
          case 'before-addtocart-button':
              add_action( 'storefy_woocommerce_single_product_summary', 'wooscarcity_load_sold_amount_message', 33 );
              break;
          case 'after-addtocart-button':
              add_action( 'storefy_woocommerce_single_product_summary', 'wooscarcity_load_sold_amount_message', 36 );
              break;
          case 'after-title':
              add_action( 'storefy_woocommerce_single_product_summary', 'wooscarcity_load_sold_amount_message', 11 );
              break;
          case 'before-image':
              add_action( 'storefy_woocommerce_template_single_product_image', 'wooscarcity_load_sold_amount_message', 2 );
              break;
          case 'after-image':
              add_action( 'storefy_woocommerce_template_single_product_image', 'wooscarcity_load_sold_amount_message', 6 );
              break;
          case 'before-title':
          default;
              add_action( 'storefy_woocommerce_single_product_summary', 'wooscarcity_load_sold_amount_message', 8 );
      }
  }

  if(wooscarcity_get_setting('enable_urgency_sold_time_message')){
      $urgency_sold_time_message_position=wooscarcity_get_setting('urgency_sold_time_message_position','before-title');

      switch ($urgency_sold_time_message_position){
          case 'before-addtocart-button':
              add_action( 'storefy_woocommerce_single_product_summary', 'wooscarcity_load_sold_time_message', 34 );
              break;
          case 'after-addtocart-button':
              add_action( 'storefy_woocommerce_single_product_summary', 'wooscarcity_load_sold_time_message', 37 );
              break;
          case 'after-title':
              add_action( 'storefy_woocommerce_single_product_summary', 'wooscarcity_load_sold_time_message', 12 );
              break;
          case 'before-image':
              add_action( 'storefy_woocommerce_template_single_product_image', 'wooscarcity_load_sold_time_message', 3 );
              break;
          case 'after-image':
              add_action( 'storefy_woocommerce_template_single_product_image', 'wooscarcity_load_sold_time_message', 7 );
              break;
          case 'before-title':
          default;
              add_action( 'storefy_woocommerce_single_product_summary', 'wooscarcity_load_sold_time_message', 9 );
      }
  }

  if(wooscarcity_get_setting('enable_stock_scarcity')){
    add_action( 'storefy_woocommerce_single_product_summary', 'storefy_wooscarcity_stock_scarcity_availability', 34 );
  }

  if(wooscarcity_get_setting('enable_wishlist')){

      add_filter('storefy_woocommerce_loop_action_list','storefy_wooscarcity_add_wishlist_link');
      add_action( 'woocommerce_after_add_to_cart_button', 'storefy_wooscarcity_single_wishlist_button', 1 );
  }

  if(wooscarcity_get_setting('enable_product_compare')){
      add_filter('storefy_woocommerce_loop_action_list','storefy_wooscarcity_add_compare_link');
      add_action( 'woocommerce_after_add_to_cart_button', 'storefy_wooscarcity_single_product_add_compare', 2 );

  }
}

/* modify category description */
remove_action( 'woocommerce_archive_description', 'woocommerce_taxonomy_archive_description');
add_action( 'woocommerce_archive_description', 'storefy_woocommerce_taxonomy_archive_description', 10 );


add_action('storefy_woocommerce_template_single_product_image','woocommerce_show_product_sale_flash',1);
add_action('storefy_woocommerce_template_single_product_image','woocommerce_show_product_images',5);


add_action('storefy_woocommerce_single_product_summary','woocommerce_template_single_meta',5);
add_action('storefy_woocommerce_single_product_summary','woocommerce_template_single_title',10);
add_action('storefy_woocommerce_single_product_summary','woocommerce_template_single_rating',15);
add_action('storefy_woocommerce_single_product_summary','storefy_woocommerce_template_single_stock_get_availability',20);

add_action('storefy_woocommerce_single_product_summary','woocommerce_template_single_excerpt',25);
add_action('storefy_woocommerce_single_product_summary','woocommerce_template_single_price',30);
add_action('storefy_woocommerce_single_product_summary','woocommerce_template_single_add_to_cart',35);
add_action('storefy_woocommerce_single_product_summary','woocommerce_template_single_sharing',40);

/* hide page title */
//02/28/2017 JDZ BEGIN
//add_filter('woocommerce_show_page_title',create_function('','return false;'));
//02/28/2017 JDZ END

add_action('woocommerce_before_shop_loop','storefy_before_shop_loop',1);
add_action('woocommerce_before_shop_loop','storefy_before_shop_loop_close',9999999);

add_action('storefy_woocommerce_after_single_product_summary','woocommerce_output_product_data_tabs',10);
add_action('storefy_woocommerce_after_single_product_summary','woocommerce_output_related_products',20);
add_action('storefy_woocommerce_after_single_product_summary_sidebar','woocommerce_upsell_display',10);

add_filter( 'woocommerce_add_to_cart_fragments', 'storefy_woocommerce_cart_nums_add_to_cart_fragment');
add_filter( 'wooscarcity_load_sold_amount_message_html', 'storefy_wooscarcity_load_sold_amount_message_html' );
add_filter( 'wooscarcity_load_sold_time_message_html','storefy_wooscarcity_load_sold_time_message_html' );
add_filter( 'woocommerce_upsell_display_args', 'storefy_woocommerce_upsell_display_args' );
add_filter( 'woocommerce_product_description_heading', 'storefy_woocommerce_product_description_heading' );
add_filter( 'woocommerce_product_additional_information_heading', 'storefy_woocommerce_product_additional_information_heading' );
add_filter( 'woocommerce_product_additional_information_tab_title', 'storefy_woocommerce_product_additional_information_tab_title' );
add_filter( 'woocommerce_product_get_attributes', 'storefy_woocommerce_get_product_attributes' ,999);
add_filter( 'woocommerce_output_related_products_args', 'storefy_related_products_args' );
add_filter( 'wooscarcity_get_product_same_checkout_args', 'storefy_related_products_args' );
add_filter( 'wooscarcity_get_recent_viewed_products_args', 'storefy_related_products_args' );
add_filter( 'body_class', 'storefy_wc_body_class' );
add_filter( 'loop_shop_columns',create_function('$column','return ($col=get_option(\'loop_shop_columns\'))?$col:$column;'));
add_filter( 'woocommerce_product_settings','storefy_woocommerce_product_settings');
add_filter( 'woocommerce_payment_gateways_settings','storefy_woocommerce_payment_gateways_settings');
add_filter( 'woocommerce_cross_sells_columns', create_function('$column','return get_option(\'loop_cross_sells_columns\',$column);') );
add_filter( 'woocommerce_cross_sells_total', create_function('$post_per_page','return get_option(\'loop_cross_sells_total\', $post_per_page);') );
add_filter( 'loop_shop_per_page', 'storefy_woocommerce_catalog_post_perpage', 20);
add_filter( 'woocommerce_order_button_html', 'storefy_woocommerce_order_button_html');
add_filter( 'woocommerce_product_review_comment_form_args', 'storefy_woocommerce_product_review_comment_form_args' );
add_filter( 'woocommerce_sale_price_html','storefy_woocommerce_sale_price_html',10,2);
add_filter( 'woocommerce_sale_flash', 'storefy_woocommerce_sale_flash_html');

// product detail : thumbnails
add_filter( 'woocommerce_product_thumbnails_columns', create_function('', 'return 4;'));
?>
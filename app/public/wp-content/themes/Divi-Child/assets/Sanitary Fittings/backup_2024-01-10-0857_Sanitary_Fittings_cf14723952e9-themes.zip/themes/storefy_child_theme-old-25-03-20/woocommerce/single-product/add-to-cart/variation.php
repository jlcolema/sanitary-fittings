<?php
/**
 * Single variation display
 *
 * This is a javascript-based template for single variations (see https://codex.wordpress.org/Javascript_Reference/wp.template).
 * The values will be dynamically replaced after selecting attributes.
 *
 * @see 	https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.5.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;
?>

<script type="text/template" id="tmpl-variation-template">

<div class="spec-row"></div>
<div class="spec-row" style="border-bottom:0px;">
<div class="spec-name">Description:</div>
<div class="spec-value">{{{ data.variation.variation_description }}}</div>
</div>
<div class="spec-row" style="border-bottom:0px;">
<div class="spec-name">SKU:</div>
<div class="spec-value"><span itemprop="sku">{{{ data.variation.sku }}}</span></div>
</div>
<div class="spec-row" style="border-bottom:0px;">
<div class="spec-name">Weight:</div>
<div class="spec-value"><span itemprop="weight">{{{ data.variation.weight }}}</span></div>
</div>
<div class="spec-row">
<div class="spec-name">Availability:</div>
<div class="spec-value" style="color:#f78e1e;">{{{ data.variation.text_field }}}</div>
</div>



	<div class="woocommerce-variation-price">
		{{{ data.variation.price_html }}}
	</div>

	<div class="woocommerce-variation-availability">
		{{{ data.variation.availability_html }}}
	</div>

</script>

<script type="text/template" id="tmpl-unavailable-variation-template">
	<p><?php _e( 'Please call for pricing and availability.', 'woocommerce' ); ?></p>
</script>
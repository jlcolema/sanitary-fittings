<?php
defined('ABSPATH') or die();
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */
?>
<?php 
	$imageurl = "";

	/* Get Image from featured image */
	$thumb_id = get_post_thumbnail_id($post->ID);

	$featured_image = wp_get_attachment_image_src($thumb_id,'full',false); 
	if (isset($featured_image[0])) {
		$imageurl = $featured_image[0];
	} else {
		$imageurl = storefy_get_first_image_url_from_content();
	}

	$alt_image = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);
	
	/* Get Image from content image */
	$pattern = get_shortcode_regex();
	preg_match_all( '/'. $pattern .'/s', get_the_content(), $matches );
	/* find first caption shortcode */


	$i = 0;
	$hascaption = false;
	foreach ($matches[2] as $shortcodetype) {
		if ($shortcodetype=='caption') {
			$hascaption = true;
			break;
		}
	    $i++;
	}

	if ($hascaption and empty($imageurl)) {
		preg_match('/^<a.*?href=(["\'])(.*?)\1.*$/', $matches[5][$i], $m);
		$imageurl = $m[2];
	}
?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<?php if (is_single()) : ?>
					<div class="postcontent">

						<?php get_template_part('pagetemplates/postinfo'); ?>

						<h2 class="blog-post-title"><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_title();?></a></h2>

						<?php get_template_part('pagetemplates/postinfotag'); ?>
						
						<?php the_content(); 

					        wp_link_pages( storefy_get_link_pages_args() );
						?>
					</div>

					<?php get_template_part('pagetemplates/postmetabottom_detail'); ?>

					<?php get_template_part('pagetemplates/postaboutcomment'); ?>
<?php else :  ?>
				<div class="row">
					<div class="col-xs-12">
						<?php get_template_part('pagetemplates/postinfo'); ?>

						<h2 class="blog-post-title"><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_title();?></a></h2>

						<?php get_template_part('pagetemplates/postinfotag'); ?>
					</div>
				</div>


<?php	if ($imageurl!="") { ?>
			<div class="row">											
				<div class="col-xs-12">
					<div class="postimagecontent">
						<a href="<?php echo esc_url(get_permalink()); ?>" title="<?php echo esc_attr(get_the_title());?>"><img class="img-responsive blog_image" alt="<?php echo esc_attr($alt_image); ?>" src="<?php echo esc_url($imageurl); ?>"></a>
					</div>
				</div>
			</div>
<?php
		} 
?>
				<div class="row">
					<div class="col-xs-12">
						<div class="postcontent">
							<?php 
							print get_the_excerpt();
							?>
						</div>
						<?php get_template_part('pagetemplates/postmetabottom'); ?>
					</div>
				</div>
<?php endif;  ?>
			</article>

<?php
defined('ABSPATH') or die();

class storefy_mainmenu_walker extends Walker_Nav_Menu {
  private $sub_menu_container_width, $sub_menu_background; 

  public function start_lvl( &$output, $depth = 0, $args = array() ) {
    $indent = str_repeat("\t", $depth);

    $style1 = "";    
    if (isset($this->sub_menu_container_width)&&!empty($this->sub_menu_container_width)) {
      $style1 = ' style="'. $this->sub_menu_container_width .'" ';
      $this->sub_menu_container_width = '';
    }

    $style2 = "";    
    if (isset($this->sub_menu_background)&&!empty($this->sub_menu_background)) {
      $style2 = ' style="'. $this->sub_menu_background .'" ';
      $this->sub_menu_background = '';
    }

    $output .= "\n$indent<div class=\"sub-menu-container".($depth ? " indent-right":"")."\" ".$style1."><ul class=\"sub-menu\" ".$style2.">\n";
  }

  public function end_lvl( &$output, $depth = 0, $args = array() ) {
    $indent = str_repeat("\t", $depth);
    $output .= "$indent</ul></div>\n";
  }

  public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {

    global $storefy_Style;


    if (is_array($item->classes) && in_array('dt-megamenu',$item->classes)) {

      $menu_id=$item->ID;
      if (isset($item->megamenuWidthOptions) && $item->megamenuWidthOptions!='') {

        if ($item->megamenuWidthOptions=='dt-megamenu-width-set sticky-left') {
          $this->sub_menu_container_width = 'width : ' . $item->megamenuWidth;
          
          //$storefy_Style[] = "#menu-item-".$menu_id." > .sub-menu-container,#page-item-".$menu_id." > .sub-menu-container { width:". $item->megamenuWidth . "; }";
        } elseif($item->megamenuWidthOptions == 'full-dt-megamenu'){
          $this->sub_menu_container_width = 'width: 100%; left: 0;';
          
          //$storefy_Style[] = "#menu-item-".$menu_id." > .sub-menu-container,#page-item-".$menu_id." > .sub-menu-container { width: 100%; left: 0; }";
        }
      }

      if (isset($item->megamenuBackgroundURL) && !empty($item->megamenuBackgroundURL)) {
        $this->sub_menu_background = 'background-image: url('.$item->megamenuBackgroundURL.'); background-position:'. $item->megamenuBackgroundHorizontalPosition . ' ' . $item->megamenuBackgroundVerticalPosition . '; background-repeat:' . $item->megamenuBackgroundRepeat . ';';

        //$storefy_Style[] = "#menu-item-".$menu_id." > .sub-menu-container > .sub-menu,#page-item-".$menu_id." > .sub-menu-container > .children {background-image: url(".$item->megamenuBackgroundURL.'); background-position:'. $item->megamenuBackgroundHorizontalPosition . ' ' . $item->megamenuBackgroundVerticalPosition . '; background-repeat:' . $item->megamenuBackgroundRepeat . ';}';
      }
    }

      parent::start_el($output,$item,$depth,$args,$id);

  }

  public function end_el( &$output, $item, $depth = 0, $args = array() ) {
    $this->curItem = $item;

      parent::end_el($output,$item,$depth,$args);

  }
  
}


class storefy_page_menu_walker extends Walker_Page{

  public function start_lvl( &$output, $depth = 0, $args = array() ) {
    $indent = str_repeat("\t", $depth);
    $output .= "\n$indent<div class=\"sub-menu-container".($depth ? " indent-right":"")."\"><ul class='children'>\n";
  }

  public function end_lvl( &$output, $depth = 0, $args = array() ) {
    $indent = str_repeat("\t", $depth);
    $output .= "$indent</ul></div>\n";
  }


}

class storefy_topbarmenu_walker extends Walker_Nav_Menu {
  public function start_lvl( &$output, $depth = 0, $args = array() ) {
    $indent = str_repeat("\t", $depth);
    $output .= "\n$indent<div class=\"sub-menu-container".($depth ? " indent-right":"")."\"><ul class=\"sub-menu\">\n";
  }

  public function end_lvl( &$output, $depth = 0, $args = array() ) {
    $indent = str_repeat("\t", $depth);
    $output .= "$indent</ul></div>\n";
  }
}


?>
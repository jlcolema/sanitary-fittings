<?php
defined('ABSPATH') or die();
/**
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */

$menu=get_storefy_option('dt-right-top-bar-menu');

if(!empty($menu)):

	$menuParams=array(
            	'menu'=>$menu,
            	'echo' => false,
                  'container_id'=>'dt-topbar-menu-right',
            	'menu_class'=>'topbar-menu',
            	'container'=>'div',
			'before' => '',
            	'after' => '',
                  'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
            	'fallback_cb'=>false,
                  'walker'  => new storefy_topbarmenu_walker()
			);

	$menu=wp_nav_menu($menuParams);

      if($menu):
?>
      <div class="right-menu">
      <?php print $menu;?>
      </div>
<?php endif;
endif;?>

<?php
defined('ABSPATH') or die();
/**
 * Displpay serach result
 * Used for search.
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */

$imageurl = "";

/* Get Image from featured image */
if (isset($post->ID)) {
	$thumb_id = get_post_thumbnail_id($post->ID);
	$featured_image = wp_get_attachment_image_src($thumb_id,'full',false); 
	if (isset($featured_image[0])) {
		$imageurl = $featured_image[0];
	}

	$alt_image = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);
}



$post_type_object=get_post_type_object(get_post_type());
$label = $post_type_object->labels->singular_name;

$short_description= get_the_excerpt(get_the_ID());

if ( ''==$short_description ) {
	$short_description = get_the_content();
	$short_description = storefy_strip_shortcodes( $short_description );

	$excerpt_length = apply_filters( 'excerpt_length', 55 );

	$short_description=wp_trim_words($short_description, $excerpt_length,"");
}


?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="row">
<?php
	if ($imageurl!="") {
?>
<div class="col-xs-12 col-md-4">											
						<div class="postimagecontent">
							<a href="<?php echo esc_url(get_permalink()); ?>" title="<?php print esc_attr(get_the_title());?>"><img class="img-responsive blog_image" alt="<?php echo esc_attr($alt_image); ?>" src="<?php echo esc_url($imageurl); ?>"></a>
						</div>
</div>
<div class="col-xs-12 col-md-8">											

<?php
	} 
	else{?>
<div class="col-xs-12">											
<?php
	}
?>											
	<h2 class="blog-post-title"><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_title();?></a></h2>
	<div class="blog-post-type" style="display:none;"><?php print $label;?></div>
	<div class="postcontent">
		<?php 
			print $short_description;
		?>
	</div>
	<div class="text-right blog_info_share">
		<?php get_template_part('pagetemplates/ms_social_share','share'); ?>
	</div>

</div>
</div>
</article>
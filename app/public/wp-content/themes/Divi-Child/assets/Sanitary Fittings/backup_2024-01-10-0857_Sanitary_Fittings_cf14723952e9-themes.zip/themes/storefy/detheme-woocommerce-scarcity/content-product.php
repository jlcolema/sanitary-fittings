<?php
/**
 * @author  Detheme
 * @package Woscarcity/Templates
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
$equal_height_type= isset($product->equal_height_type) ? $product->equal_height_type : 0; 
$equal_height_selector= isset($product->equal_height_id) ? $product->equal_height_id : ""; 

$equal_height_tag="";
if(!empty($equal_height_selector)){

	if($equal_height_type=='skip-grouped'){
		$equal_height_tag=' data-mh="'.esc_attr($equal_height_selector).'"';
	}
	elseif($equal_height_type=='skip-target'){
		$equal_height_tag=' data-equal-with="'.esc_attr($equal_height_selector).'"';
	}
}

?>
<li <?php post_class(); echo $equal_height_tag; ?> itemscope itemtype="http://schema.org/Product">
<?php do_action( 'storefy_woocommerce_before_shop_loop_item' );?>
<div class="product-loop-container">
<div class="before-product-loop-item">	
<?php
	storefy_woocommerce_template_loop_product_thumbnail();
?>
</div>
<div class="after-product-loop-item">
	<div class="after-product-loop-item-left">
<?php 

	woocommerce_template_loop_product_link_open();
	woocommerce_template_loop_product_title();
	woocommerce_template_loop_product_link_close();

	storefy_woocommerce_template_loop_excerpt();
?>
	</div>
	<div class="after-product-loop-item-right">
<?php
	woocommerce_template_loop_rating();
	storefy_wooscarcity_load_loop_sale_countdown();

	woocommerce_template_loop_price();
	storefy_woocommerce_template_loop_add_to_cart(true);

	storefy_woocommerce_loop_stock_get_availability();
	storefy_woocommerce_template_loop_action_button();
	?>
	</div>
</div>
</div>
<?php do_action( 'storefy_woocommerce_after_shop_loop_item' );?>
</li>

<?php
defined('ABSPATH') or die();

function storefy_post_use_sidebar_layout(){

  return apply_filters('post_type_sidebar_layout_filter',array('revision','nav_menu_item','post','page','product_variation','shop_order','shop_webhook','shop_coupon','shop_order_refund','attachment'));
}


function storefy_post_use_comment(){

  return apply_filters('post_type_comment_filter',array('revision','nav_menu_item','product','product_variation','shop_order','shop_webhook','shop_coupon','shop_order_refund','attachment'));
}


if (!function_exists('detheme_redux_init')) :
	function detheme_redux_init() {


	global $wp_filesystem;

	if (empty($wp_filesystem)) {
		require_once(ABSPATH .'/wp-admin/includes/file.php');
		require_once(ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php');
		require_once(ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php');
		WP_Filesystem();
	}  		

	/* internationalise */

    $domain = 'redux-framework';
    $locale = get_locale();
    load_textdomain( $domain, trailingslashit( WP_LANG_DIR ) . $domain . '/' . $domain . '-' . $locale . '.mo' );
    load_textdomain( $domain, get_template_directory() . '/redux-framework/ReduxCore/languages/' . $domain . '-' . $locale . '.mo' );


	/**
		ReduxFramework Sample Config File
		For full documentation, please visit: https://github.com/ReduxFramework/ReduxFramework/wiki
	**/


	/**
	 
		Most of your editing will be done in this section.

		Here you can override default values, uncomment args and change their values.
		No $args are required, but they can be overridden if needed.
		
	**/
	$args = array();


	// For use with a tab example below
	$tabs = array();

	ob_start();

	$ct = wp_get_theme();
	$theme_data = $ct;
	$item_name = $theme_data->get('Name'); 
	$tags = $ct->Tags;
	$screenshot = $ct->get_screenshot();
	$class = $screenshot ? 'has-screenshot' : '';

	$customize_title = sprintf( esc_html__( 'Customize &#8220;%s&#8221;','redux-framework' ), $ct->display('Name') );



	?>
	<div id="current-theme" class="<?php echo esc_attr( $class ); ?>">
		<h4>
			<?php echo $ct->display('Name'); ?>
		</h4>

		<div>
			<ul class="theme-info">
				<li><?php printf( esc_html__('By %s','redux-framework'), $ct->display('Author') ); ?></li>
				<li><?php printf( esc_html__('Version %s','redux-framework'), $ct->display('Version') ); ?></li>
			</ul>
			<p class="theme-description"><?php esc_html($ct->display('Description')); ?></p>
			<?php if ( $ct->parent() ) {
				printf( ' <p class="howto">' . __( 'This <a href="%1$s">child theme</a> requires its parent theme, %2$s.','redux-framework' ) . '</p>',
					esc_html__( 'http://codex.wordpress.org/Child_Themes','redux-framework' ),
					$ct->parent()->display( 'Name' ) );
			} ?>
			
		</div>

	</div>

	<?php
	$item_info = ob_get_contents();
	    
	ob_end_clean();

	$sampleHTML = '';


	$icon_info='';
	$args['dev_mode'] = false;
	$args['opt_name'] = 'storefy_config';
	$theme = wp_get_theme();
	$args['display_name'] = $theme->get('Name');
	$args['display_version'] = $theme->get('Version');
	$args['google_api_key'] = 'AIzaSyAX_2L_UzCDPEnAHTG7zhESRVpMPS4ssII';
	$args['share_icons']['twitter'] = array(
	    'link' => esc_url('http://twitter.com/detheme'),
	    'title' => 'Follow me on Twitter', 
	    'img' => DethemeReduxFramework::$_url . 'assets/img/social/Twitter.png'
	);

	$args['share_icons']['facebook'] = array(
	    'link' => esc_url('https://www.facebook.com/detheme'),
	    'title' => 'Find me on Facebook', 
	    'img' => DethemeReduxFramework::$_url . 'assets/img/social/Facebook.png'
	);
	$args['show_import_export'] = true;
	$args['menu_title'] = esc_html__('Theme Options', 'redux-framework');
	$args['page_title'] = esc_html__('Options', 'redux-framework');

	$args['page_slug'] = 'redux_options';

	$args['default_show'] = false;
	$args['default_mark'] = '';

	$args['intro_text'] = $args['menu_title'];


	$sections = array();              

	$dt_theme_images  = substr_replace(DethemeReduxFramework::$_url,'images',strpos(DethemeReduxFramework::$_url,'redux-framework'));

	$post_types = get_post_types( array());

   
	$sections['general'] = array(
		'icon' => 'el-icon-cogs',
		'title' => esc_html__('General', 'redux-framework'),
		'fields' => array(
			array(
				'id'=>'devider-1',
				'type' => 'divider', 
				'title' => '<h2 class="redux-title">'.esc_html__('General Settings', 'redux-framework')."</h2>",
				),	
			array(
				'id'=>'layout',
				'type' => 'image_select',
				'compiler'=>true,
				'title' => esc_html__('Main Layout', 'redux-framework'), 
				'subtitle' => esc_html__('Select main layout for the site', 'redux-framework'),
				'options' => array(
						'1' => array('alt' => '1 Column', 'img' => DethemeReduxFramework::$_url.'assets/img/boxed.png'),
						'2' => array('alt' => '2 Column Left', 'img' => DethemeReduxFramework::$_url.'assets/img/side-bar-left-boxed.png'),
						'3' => array('alt' => '2 Column Right', 'img' => DethemeReduxFramework::$_url.'assets/img/side-bar-right-boxed.png'),
						'4' => array('alt' => 'Fullwidh', 'img' => DethemeReduxFramework::$_url.'assets/img/full-width.png')
					),
				'default' => '2'
				),
			)
		);

      foreach ( $post_types as $post_type ) {
          if (!in_array($post_type, storefy_post_use_sidebar_layout())) {
              

	        $post_type_object=get_post_type_object($post_type);

	        if($post_type_object->name=='product'){
	        	$post_type_object->labels->name=$post_type_object->labels->singular_name="Woocommerce Product";
	        }

	        $label = $post_type_object->labels->singular_name;

	        if($post_type_object->public){

	          	array_push($sections['general']['fields'],
				array(
					'id'=>'layout_'.$post_type,
					'type' => 'image_select',
					'compiler'=>true,
					'title' => sprintf(esc_html__('%s Layout', 'redux-framework'),ucfirst($post_type_object->labels->name)), 
					'subtitle' => sprintf(esc_html__('Select layout for the %s page', 'redux-framework'),strtolower($label)),
					'options' => array(
							'1' => array('alt' => '1 Column', 'img' => DethemeReduxFramework::$_url.'assets/img/boxed.png'),
							'2' => array('alt' => '2 Column Left', 'img' => DethemeReduxFramework::$_url.'assets/img/side-bar-left-boxed.png'),
							'3' => array('alt' => '2 Column Right', 'img' => DethemeReduxFramework::$_url.'assets/img/side-bar-right-boxed.png'),
							'4' => array('alt' => 'Fullwidh', 'img' => DethemeReduxFramework::$_url.'assets/img/full-width.png')
						),
					'default' => '2'
					));
	         }
          }
      }



	$sections['general']['fields']=array_merge($sections['general']['fields'],array(
			array(
				'id'		=> 'boxed_layout_activate',
				'title' 	=> esc_html__('Layout', 'redux-framework'), 
				'subtitle'		=> esc_html__('Enable or Disable the boxed layout','redux-framework'),
				'type'		=> 'radio',
				'options' 	=> array(
					'0' => esc_html__('Default','redux-framework'),
					'boxed' => esc_html__('Boxed','redux-framework'),
					'wide' => esc_html__('Wide','redux-framework'),
				),
				'default' 	=> 0
			),
			array(
				'id'		=> 'boxed_layout_stretched',
				'title' 	=> esc_html__('Stretched', 'redux-framework'), 
				'subtitle'		=> esc_html__('Enable or Disable the stretched boxed layout','redux-framework'),
				'type'		=> 'switch',
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework'),
				'default' 	=> 0
			),
			array(
				'id'=>'boxed_layout_boxed_background_image',
				'type' => 'media', 
				'title' => esc_html__('Boxed Background Image', 'redux-framework'),
				'subtitle'=>esc_html__('Select image for the boxed background layout','redux-framework'),
				'compiler' => true,
				'default'=>array('url'=>''),
				),
			array(
				'id'=>'boxed_layout_boxed_background_color',
				'type' => 'color_nocheck',
				'output' => '',
				'title' => esc_html__('Boxed Background Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select color for the boxed background layout', 'redux-framework'),
				'default' => '#ffffff',
				'validate' => 'color',
				),	
			array(
				'id'=>'dt-404-page',
				'type' => 'select',
				'title' => esc_html__('404 Page', 'redux-framework'), 
				'subtitle'=>esc_html__('Select the 404 page','redux-framework'),
				'data' => 'pages',
				'description'=>'<a class="btn button" href="'.esc_url(admin_url( 'post-new.php?post_type=page', 'relative' )).'" target="_blank">'.esc_html__('Create New Page','redux-framework').'</a>',
				)
			)
		);
		
	if(!function_exists('wp_site_icon')){
		array_push(
			$sections['general']['fields'],
			array(
				'id'=>'dt-favicon-image',
				'type' => 'media', 
				'title' => esc_html__('Favicon Image', 'redux-framework'),
				'subtitle'=>esc_html__('Select image for the favicon','redux-framework'),
				'compiler' => true,
				'desc'=> esc_html__('Upload your image (.png,.ico, .jpg) with size 16x16 pixel', 'redux-framework'),
				'default'=>'',
				)
			);
	}

    $post_object=get_post_type_object('post');
    $postlabel = $post_object->labels->singular_name;

	$sections['general']['fields']=array_merge($sections['general']['fields'],array(
		array(
			'id'=>'dt-show-title-page',
			'type' => 'switch', 
			'title' => esc_html__('Page Title', 'redux-framework'),
			'subtitle'=>esc_html__('Enable or Disable the page title','redux-framework'),
			"default" => 1,
			'on' => esc_html__('On', 'redux-framework'),
			'off' => esc_html__('Off', 'redux-framework')
			),	
		array(
			'id'=>$post_object->name.'-title',
			'type' => 'switch', 
			'title' => sprintf(esc_html__('%s Title', 'redux-framework'),ucfirst($postlabel)),
			"default" => 1,
			'on' => esc_html__('On', 'redux-framework'),
			'off' => esc_html__('Off', 'redux-framework')
		)
	));


	if (storefy_plugin_is_active('detheme-post/detheme_post.php')) {

			 $dtpost_object=get_post_type_object('dtpost');
		     $dtpostlabel = $dtpost_object->labels->singular_name;

			$sections['general']['fields']=array_merge($sections['general']['fields'],array(
				array(
					'id'=>$dtpost_object->name.'-title',
					'type' => 'switch', 
					'title' => sprintf(esc_html__('%s Title', 'redux-framework'),ucfirst($dtpostlabel)),
					"default" => 1,
					'on' => esc_html__('On', 'redux-framework'),
					'off' => esc_html__('Off', 'redux-framework')
				)
			));

	}

	if (storefy_plugin_is_active('essential-grid/essential-grid.php')) {

		 $dtpost_object=get_post_type_object('essential_grid');
	     $dtpostlabel = $dtpost_object->labels->singular_name;
		$sections['general']['fields']=array_merge($sections['general']['fields'],array(
			array(
				'id'=>$dtpost_object->name.'-title',
				'type' => 'switch', 
				'title' => sprintf(esc_html__('%s Title', 'redux-framework'),ucfirst($dtpostlabel)),
				"default" => 1,
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework')
			)
		));

	}

		$sections['general']['fields']=array_merge($sections['general']['fields'],array(

			array(
				'id'=>'devider-2',
				'type' => 'divider', 
				'title' => '<h2 class="redux-title">'.esc_html__('Page Loader', 'redux-framework').'</h2>',
				),	
			array(
				'id'		=> 'page_loader',
				'title' 	=> esc_html__('Page Loader', 'redux-framework'), 
				'subtitle'	=>esc_html__('Enable or Disable the page loader','redux-framework'),
				'type'		=> 'switch',
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework'),
				'default' 	=> 0
				),
			array(
				'id'=>'page_loader_background',
				'type' => 'color_nocheck',
				'output' => '',
				'title' => esc_html__('Background Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select color for the page loader background', 'redux-framework'),
				'default' => '#000000',
				'validate' => 'color',
				),	
			array(
				'id'=>'page_loader_ball_1',
				'type' => 'color_nocheck',
				'output' => '',
				'title' => esc_html__('Ball 1 Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select color for the first ball on the page loader', 'redux-framework'),
				'default' => '#cb2025',
				'validate' => 'color',
				),	
			array(
				'id'=>'page_loader_ball_2',
				'type' => 'color_nocheck',
				'output' => '',
				'title' => esc_html__('Ball 2 Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select color for the second ball on the page loader', 'redux-framework'),
				'default' => '#f8b334',
				'validate' => 'color',
				),	
			array(
				'id'=>'page_loader_ball_3',
				'type' => 'color_nocheck',
				'output' => '',
				'title' => esc_html__('Ball 3 Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select color for the third ball on the page loader', 'redux-framework'),
				'default' => '#00a096',
				'validate' => 'color',
				),	
			array(
				'id'=>'page_loader_ball_4',
				'type' => 'color_nocheck',
				'output' => '',
				'title' => esc_html__('Ball 4 Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select color for the fourth ball on the page loader', 'redux-framework'),
				'default' => '#97bf0d',
				'validate' => 'color',
				),	
			array(
				'id'=>'devider-3',
				'type' => 'divider', 
				'title' => '<h2 class="redux-title">'.esc_html__('Sticky Sidebar', 'redux-framework').'</h2>',
				),	
			array(
				'id'		=> 'dt_scrollingsidebar_on',
				'title' 	=> esc_html__('Sticky Sidebar', 'redux-framework'), 
				'subtitle'	=>esc_html__('Enable or Disable the sticky sidebar','redux-framework'),
				'type'		=> 'switch',
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework'),
				'default' 	=> 0
				),
			array(
				'id'=>'dt_scrollingsidebar_bg_type',
				'type' => 'switch',
				'title' => esc_html__('Background Color', 'redux-framework'), 
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework'),
				'subtitle' => esc_html__('Enable or Disable the background color as well as select the background color', 'redux-framework'),
				'default'=>1
				),
			array(
				'id'=>'dt_scrollingsidebar_bg_color',
				'type' => 'color_nocheck',
				'output' => '',
				'default' => '#ecf0f1',
				'validate' => 'color',
				),	
			array(
				'id'		=> 'dt_scrollingsidebar_position',
				'type' 		=> 'select', 
				'title' 	=> esc_html__('Position', 'redux-framework'),
				'subtitle' 	=> esc_html__('Select position for the sticky sidebar', 'redux-framework'),
				'default' 	=> 'right',
				'options' 	=> array(
					'right' => esc_html__('Right','redux-framework'),
					'left' => esc_html__('Left','redux-framework'),
					),
				),	
			array(
				'id'		=> 'dt_scrollingsidebar_top_margin',
				'type' 		=> 'text',
				'compiler'	=> true,
				'title' 	=> esc_html__('Top Margin', 'redux-framework'), 
				'subtitle' 	=> esc_html__('Adjust the sticky sidebar position from the top (in pixel)', 'redux-framework'),
				'validate' 	=> 'numeric',
				'msg'		=> esc_html__('Please enter number.','redux-framework'),
				'default' 	=> 200
				),
			array(
				'id'		=> 'dt_scrollingsidebar_margin',
				'type' 		=> 'text',
				'compiler'	=> true,
				'title' 	=> esc_html__('Other Margin', 'redux-framework'), 
				'subtitle' 	=> esc_html__('Adjust the sticky sidebar position from its surrounding (in pixel)', 'redux-framework'),
				'validate' 	=> 'numeric',
				'msg'		=> esc_html__('Please enter number.','redux-framework'),
				'default' 	=> 0
				),
			array(
				'id'=>'devider-5',
				'type' => 'divider', 
				'title' => '<h2 class="redux-title">'.esc_html__('Meta Open Graph', 'redux-framework').'</h2>',
				),
			array(
				'id'=>'meta-og',
				'type' => 'switch', 
				'title' => esc_html__('Meta Open Graph', 'redux-framework'),
				'subtitle'=> esc_html__('Allow show/hide Meta Open Graph', 'redux-framework'),
				'default'=> 1,
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework')
				),	
			array(
				'id'=>'devider-10',
				'type' => 'divider', 
				'title' => '<h2 class="redux-title">'.esc_html__('Blog Type', 'redux-framework').'</h2>',
				),
			array(
				'id'=>'blog_type',
				'type' => 'select',
				'title' => esc_html__('Blog Type','redux-framework'),
				'subtitle'=>esc_html__('Select Blog Type','redux-framework'), 
				'options'=>array(
				      'default'=>esc_html__("Default", 'redux-framework'),
				      'masonry'=> esc_html__("Masonry", 'redux-framework') ,
					),
				'default'=> 'default',
				),
			array(
				'id'=>'masonry_column',
				'type' => 'select',
				'title' => esc_html__('Masonry Column (dekstop)','redux-framework'),
				'subtitle'=>esc_html__('Number of columns on the screen resolution larger than 900px','redux-framework'), 
				'options'=>array(
				      1=>esc_html__("1 Column", 'redux-framework'),
				      2=>esc_html__("2 Columns", 'redux-framework'),
				      3=> esc_html__("3 Columns", 'redux-framework'),
				      4=> esc_html__("4 Columns", 'redux-framework')
					),
				'default'=> 3,
				),
			array(
				'id'=>'masonry_column_tablet',
				'type' => 'select',
				'title' => esc_html__('Masonry Column (tablet)','redux-framework'),
				'subtitle'=>esc_html__('Number of columns on the screen resolution between 601px and 900px','redux-framework'), 
				'options'=>array(
				      1=>esc_html__("1 Column", 'redux-framework'),
				      2=>esc_html__("2 Columns", 'redux-framework'),
				      3=> esc_html__("3 Columns", 'redux-framework')
					),
				'default'=> 2,
				),
			array(
				'id'=>'masonry_column_mobile',
				'type' => 'select',
				'title' => esc_html__('Masonry Column (mobile)','redux-framework'),
				'subtitle'=>esc_html__('Number of columns on the screen resolution below 600px','redux-framework'), 
				'options'=>array(
				      1=>esc_html__("1 Column", 'redux-framework'),
				      2=>esc_html__("2 Columns", 'redux-framework')
					),
				'default'=> 1,
				),
			array(
				'id'=>'devider-11',
				'type' => 'divider', 
				'title' => '<h2 class="redux-title">'.esc_html__('Author', 'redux-framework').'</h2>',
				),
			array(
				'id'=>'show-author',
				'type' => 'switch', 
				'title' => esc_html__('Display About Author Box ?', 'redux-framework'),
				'subtitle'=> esc_html__('Display/Hide About Author Box', 'redux-framework'),
				"default" => 1,
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework')
				),
			array(
				'id'=>'devider-4',
				'type' => 'divider', 
				'title' => '<h2 class="redux-title">'.esc_html__('Comments', 'redux-framework').'</h2>',
				))
			);	

     foreach ( $post_types as $post_type ) {

          if (!in_array($post_type, storefy_post_use_comment())) {

	        $post_type_object=get_post_type_object($post_type);
	        $label = $post_type_object->labels->name;

	        if($post_type_object->public){

	          	array_push($sections['general']['fields'],
				array(
					'id'=>'comment-open-'.$post_type,
					'type' => 'switch', 
					'title' => sprintf(esc_html__('%s Comment', 'redux-framework'),ucfirst($label)),
					'subtitle'=> sprintf(esc_html__('Enable or Disable comment on the %s', 'redux-framework'),$label),
					"default" => 1,
					'on' => esc_html__('On', 'redux-framework'),
					'off' => esc_html__('Off', 'redux-framework')
					));
	        }
          }
      }

	$sections['styling'] = array(
		'icon' => 'el-icon-website',
		'title' => esc_html__('Style', 'redux-framework'),
		'fields' => array(
			array(
				'id'=>'primary-color',
				'type' => 'color_nocheck',
				'output' => array('.site-title'),
				'title' => esc_html__('Primary Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select primary color for the theme', 'redux-framework'),
				'default' => '#fcbd39',
				'validate' => 'color',
				),		
			array(
				'id'=>'secondary-color',
				'type' => 'color_nocheck',
				'output' => array('.site-title'),
				'title' => esc_html__('Secondary Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select secondary color for the theme', 'redux-framework'),
				'default' => '#999999',
				'validate' => 'color',
				),		
			array(
				'id'=>'headings-color',
				'type' => 'color_nocheck',
				'output' => array('h1','h2','h3','h4','h5','h6'),
				'title' => esc_html__('Headings Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select color for heading (h1, h2 , h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6)', 'redux-framework'),
				'default' => '#444444',
				'validate' => 'color',
				),		
			array(
				'id'=>'body_text_color',
				'type' => 'color_nocheck',
				'output' => '',
				'title' => esc_html__('Body Text Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select color for the body text', 'redux-framework'),
				'default' => '#888888',
				'validate' => 'color',
				),	
			array(
				'id'=>'body_background_color',
				'type' => 'color_nocheck',
				'output' => '',
				'title' => esc_html__('Body Background Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select color for the body background', 'redux-framework'),
				'default' => '#ffffff',
				'validate' => 'color',
				),	
			array(
				'id'=>'body_background_image',
				'type' => 'media', 
				'title' => esc_html__('Body Background Image', 'redux-framework'),
				'compiler' => true,
				'subtitle'=> esc_html__('Select image for the body background', 'redux-framework'),
				'default'=>array('url'=>''),
				),
			array(
				'id'=>'body_background_style',
				'type' => 'select',
				'title' => esc_html__('Body Background Image Style','redux-framework'),
				'subtitle'=>esc_html__('Select style for the body background image','redux-framework'), 
				'options'=>array(
				      'cover'=>esc_html__("Cover", 'js_composer'),
				      'cover_all'=> esc_html__("Cover All", 'js_composer') ,
				      'contain'=> esc_html__('Contain', 'js_composer') ,
				      'no-repeat'=> esc_html__('No Repeat', 'js_composer') ,
				      'repeat'=> esc_html__('Repeat', 'js_composer') ,
				      'parallax'=> esc_html__("Parallax", 'storefy') ,
				      'parallax_all'=> esc_html__("Parallax All", 'storefy') ,
				      'fixed'=> esc_html__("Fixed", 'storefy') ,
					)
				),
			array(
				'id'=>'primary-font',
				'type' => 'typography',
				'title' => esc_html__('Body Text Font', 'redux-framework'),
				'subtitle' => esc_html__('Select font properties for the body text', 'redux-framework'),
				'font-style'=>false,
				'font-weight'=>false,
				'font-size'=>false,
				'color'=>false,
				'google'=>true,
				'line-height'=>true,
				'letter-spacing'=>true,
				'class'=>'no-border-bottom',
				'default' => array(
					'font-family'=>'Heboo',
					'google'=>true
					),
				),
			array(
				'id'=>'secondary-font',
				'type' => 'typography',
				'title' => esc_html__('Heading Text Font', 'redux-framework'),
				'subtitle' => esc_html__('Select font properties for the heading text', 'redux-framework'),
				'font-style'=>false,
				'font-weight'=>true,
				'font-size'=>false,
				'color'=>false,
				'google'=>true,
				'line-height'=>true,
				'letter-spacing'=>true,
				'class'=>'no-border-bottom has-border-top',
				'default' => array(
					'font-family'=>'Heboo',
					'google'=>true
					),
				),
			array(
				'id'=>'section-font',
				'type' => 'typography',
				'title' => esc_html__('Section Heading Text Font', 'redux-framework'),
				'subtitle' => esc_html__('Select font properties for the section heading text', 'redux-framework'),
				'font-style'=>false,
				'font-weight'=>true,
				'font-size'=>false,
				'color'=>false,
				'google'=>true,
				'line-height'=>false,
				'class'=>'has-border-top',
				'default' => array(
					'font-family'=>'Heboo',
					'google'=>true
					),
				),
			array(
				'id'=>'tertiary-font',
				'type' => 'typography',
				'title' => esc_html__('Quote Text Font', 'redux-framework'),
				'subtitle' => esc_html__('Select font properties for the quote text', 'redux-framework'),
				'font-style'=>false,
				'font-weight'=>false,
				'font-size'=>false,
				'color'=>false,
				'google'=>true,
				'line-height'=>true,
				'letter-spacing'=>true,
				'class'=>'no-border-bottom',
				'default' => array(
					'font-family'=>'Playfair Display',
					),
				),
			array(
				'id'=>'heading-style',
				'type' => 'select',
				'title' => esc_html__('Heading Text Style', 'redux-framework'),
				'subtitle'=>esc_html__('Select style for the heading text','redux-framework'),
				'class'=>'has-border-top',
				'options'=>array(
					'uppercase'=>esc_html__('Uppercase', 'redux-framework'),
					'capitalize'=>esc_html__('Capitalize', 'redux-framework'),
					'none'=>esc_html__('None', 'redux-framework')
					),
				'default'=>'none'
				)
		)
	);

		$sections['topbar'] = array(
		'title' => esc_html__('Top Bar', 'redux-framework'),
		'icon' => 'el-icon-tasks',
		'fields' => array(	
			array(
				'id'=>'showtopbar',
				'type' => 'switch', 
				'title' => esc_html__('Top Bar', 'redux-framework'),
				'subtitle'=> esc_html__('Enable or Disable the Top Bar', 'redux-framework'),
				"default" 		=> 1,
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework')
				),	
			array(
				'id'=>'topbar-background-color',
				'type' => 'color_rgba',
				'output' => '',
				'title' => esc_html__('Background Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select color for the top bar', 'redux-framework'),
				'default' => '#ffffff',
				'validate' => 'color',
				),	
			array(
				'id'=>'topbar-font-color',
				'type' => 'color_nocheck',
				'output' => '',
				'title' => esc_html__('Font Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select font color for the top bar', 'redux-framework'),
				'default' => '#222222',
				),	
			array(
				'id'=>'topbar-height',
				'type' => 'text', 
				'class'=>'width_100',
				'title' => esc_html__('Top Bar Height', 'redux-framework'),
				'subtitle' => sprintf(esc_html__('is used to adjust Top Bar Height in pixel (Default: %dpx)', 'redux-framework'),0),
				'default'=> 0,
				),
			array(
				'id'=>'devider-6',
				'type' => 'divider', 
				'title' => '<h2 class="redux-title">'.esc_html__('Left Section', 'redux-framework')."</h2>",
				),	
			array(
				'id'=>'dt-left-top-bar',
				'type' => 'select',
				'title' => esc_html__('Type of Element', 'redux-framework'), 
				'subtitle'=>esc_html__('Select element to be displayed on the left section of top bar','redux-framework'),
				'options'=>array(
					'text'=>esc_html__('Custom Text','redux-framework'),
					'menu'=>esc_html__('Menu','redux-framework'),
					'icon'=>esc_html__('Icon from Menu','redux-framework')
					)
				),
			array(
				'id'=>'dt-left-top-bar-menu',
				'type' => 'menu',
				'title' => esc_html__('Select Menu Source', 'redux-framework'), 
				'subtitle'=>esc_html__('Select menu that will be displayed on the left section of top bar','redux-framework'),
				),
			array(
				'id'=>'dt-left-top-bar-text',
				'type' => 'text',
				'title' => esc_html__('Custom Text', 'redux-framework'),
				'subtitle'=>esc_html__('Write any text that will be displayed on the left section of top bar','redux-framework'),
				'default' => esc_html__('Left topbar custom text','redux-framework')
				),				
			array(
				'id'=>'devider-7',
				'type' => 'divider', 
				'title' => '<h2 class="redux-title">'.esc_html__('Right Section', 'redux-framework').'</h2>',
				),	
			array(
				'id'=>'dt-right-top-bar',
				'type' => 'select',
				'title' => esc_html__('Type of Element', 'redux-framework'), 
				'subtitle'=>__('Select element to be displayed on the right section of top bar','redux-framework'),
				'options'=>array(
					'text'=>esc_html__('Custom Text','redux-framework'),
					'menu'=>esc_html__('Menu','redux-framework'),
					'icon'=>esc_html__('Icon from Menu','redux-framework')
					)
				),
			array(
				'id'=>'dt-right-top-bar-menu',
				'type' => 'menu',
				'subtitle'=>esc_html__('Select menu that will be displayed on the right section of top bar','redux-framework'),
				'title' => esc_html__('Select Menu Source', 'redux-framework'), 
				),
			array(
				'id'=>'dt-right-top-bar-text',
				'type' => 'text',
				'title' => esc_html__('Custom Text', 'redux-framework'),
				'subtitle'=>esc_html__('Write any text that will be displayed on the right section of top bar','redux-framework'),
				'default' => esc_html__('Right topbar custom text','redux-framework')
				),					)
	);
	
	$sections['header'] = array(
		'title' => esc_html__('Header Section', 'redux-framework'),
		'icon' => 'el-icon-th-large',
		'fields' => array(
            array(
                'id'=>'header-text-color',
                'type'=>'color_nocheck',
                'title' => esc_html__('Header Text Color', 'redux-framework'),
                'subtitle'=>esc_html__('Select Header Text Color','redux-framework'),
                'default'=>'',
                'validate' => 'color'
                ),
            array(
                'id'=>'header-background-color',
                'type'=>'color_rgba',
                'title' => esc_html__('Header Background Color', 'redux-framework'),
                'subtitle'=>esc_html__('Select Header Background Color','redux-framework'),
                'default'=>array('color'=>'#ffffff','alpha'=>1),
                'mode' => 'background'
                ),
			array(
				'id'=>'menu_icon_fields',
				'type' => 'icon_multi_text',
				'title' => esc_html__('Navigation Icons', 'redux-framework'),
				'subtitle'=>esc_html__('Manage the navigation icon as menu','redux-framework'),
				'sortable' => true,
				'fields'=> array(
					'label' => __('Label', 'redux-framework'),
					'text' => __('Text', 'redux-framework'),
					)
				),
            array(
                'id'=>'header-icons-color',
                'type'=>'color_nocheck',
                'title' => esc_html__('Navigation Icons Color', 'redux-framework'),
                'subtitle'=>esc_html__('Set Navigation Icons Color','redux-framework'),
                'default'=>'#fcbd39',
                'validate' => 'color'
                ),
			array(
				'id'=>'dt-logo-image',
				'type' => 'media', 
				'title' => esc_html__('Logo', 'redux-framework'),
				'compiler' => true,
				'desc'=> esc_html__('Set logo image.', 'redux-framework'),
				'subtitle' => esc_html__('Select the default logo for the site', 'redux-framework'),
				'default'=>array('url'=>''),
			),
			array(
				'id'=>'dt-logo-text',
				'type' => 'text', 
				'title' => esc_html__('Logo Alt Text', 'storefy'),
				'subtitle' => esc_html__('Adjust the logo alt text', 'redux-framework'),
				'default'=>'',
				),
			array(
				'id'=>'dt-logo-width',
				'type' => 'text', 
				'title' => esc_html__('Logo Width', 'redux-framework'),
				'subtitle' => esc_html__('Adjust the logo width (in pixel)', 'redux-framework'),
				'class'=>'width_100',
				'desc'=>esc_html__('leave blank or put "0" if no set', 'redux-framework'),
				'default'=>'240',
				),
			array(
				'id'=>'dt-post-type-search',
				'type' => 'switch', 
				'title' => esc_html__('Post Type Search Option', 'redux-framework'),
				'subtitle'=> esc_html__('Enable or Disable the post type option on seach bar', 'redux-framework'),
				"default" => 0,
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework')
				),	
			)

	);

	$sections['navigation'] = array(
		'title' => esc_html__('Navigation', 'redux-framework'),
		'icon' => 'el-icon-lines',
		'fields' => array(
			array(
				'id'=>'dt-sticky-menu',
				'type' => 'switch', 
				'title' => esc_html__('Sticky Menu', 'redux-framework'),
				'subtitle'=> esc_html__('Enable or Disable the sticky menu', 'redux-framework'),
				"default" => 1,
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework')
				),	
			array(
				'id'=>'show-header-shoppingcart',
				'type' => 'switch', 
				'title' => esc_html__('Shopping Cart ', 'redux-framework'),
				'subtitle' => esc_html__('Enable or Disable Woocommerce shopping cart', 'redux-framework'),
				"default" 		=> 1,
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework')
				),	
			array(
				'id'=>'dt-menu-height',
				'type' => 'text', 
				'class'=>'width_100',
				'title' => esc_html__('Navigation Bar Height', 'redux-framework'),
				'subtitle' => esc_html__('Adjust the navigation bar in px', 'redux-framework'),
				'default'=> '',
				),
            array(
                'id'=>'header-color',
                'type'=>'color_rgba',
                'title' => esc_html__('Navigation Bar Background Color', 'redux-framework'),
                'subtitle'=>esc_html__('Select Navigation Bar Background Color','redux-framework'),
                'default'=>array('color'=>'#1b3f4f','alpha'=>0),
                'mode' => 'background'
                ),
			array(
				'id'=>'header-font-color',
				'type' => 'color_nocheck',
				'output' => '',
				'title' => esc_html__('Navigation Bar Font Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select the font color for the navigation bar', 'redux-framework'),
				'default' => '#444444',
				'validate' => 'color',
				),	
            array(
                'id'=>'header-color-sticky',
                'type'=>'color_rgba',
                'title' => esc_html__('Navigation Bar Background Color (Sticky)', 'redux-framework'),
                'subtitle'=>esc_html__('Select Navigation Bar Background Color (Sticky)','redux-framework'),
                'default'=>array('color'=>'#1b3f4f','alpha'=>1),
                'mode' => 'background'
                ),
			array(
				'id'=>'header-font-color-sticky',
				'type' => 'color_nocheck',
				'output' => '',
				'title' => esc_html__('Navigation Bar Font Color (Sticky)', 'redux-framework'), 
				'subtitle' => esc_html__('Select the font color for the navigation bar when in sticky mode', 'redux-framework'),
				'default' => '#ffffff',
				'validate' => 'color',
				),	
			array(
				'id'=>'header-left-menu',
				'type' => 'switch', 
				'title' => esc_html__('Side Menu', 'redux-framework'),
				'subtitle'=> esc_html__('Enable or Disable side menu', 'redux-framework'),
				"default" => 0,
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework')
				),	
			array(
				'id'=>'header-left-menu-id',
				'type' => 'menu',
				'subtitle'=>__('Select menu that will be displayed on the side section of navigation bar','redux-framework'),
				'title' => __('Select Menu Source', 'redux-framework'), 
				),
			array(
				'id'=>'header-left-menu-title',
				'type' => 'text', 
				'class'=>'width_400',
				'title' => esc_html__('Side Menu Legend', 'redux-framework'),
				'subtitle' => esc_html__('Side Menu Title/Legend', 'redux-framework'),
				'default'=> '',
				),
			)
	);

	$sections['footer'] = array(
		'title' => esc_html__('Footer', 'redux-framework'),
		'icon' => 'el-icon-fork',
		'fields' => array(
			array(
				'id'=>'showfooterarea',
				'type' => 'switch', 
				'title' => esc_html__('Footer', 'redux-framework'),
				'subtitle'=> esc_html__('Enable or Disable footer', 'redux-framework'),
				"default"=> 1,
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework')
				),	
			array(
				'id'=>'footer-text',
				'type' => 'editor',
				'title' => esc_html__('Footer Text', 'redux-framework'), 
				'subtitle' => esc_html__('Type in the text that will be show on footer area <br>','redux-framework'),
				'default' => '&copy; 2016 ' .sprintf(esc_html__('%s, The Awesome Theme. All right reserved.','redux-framework'), get_template()),
				'editor_options'=>array( 'media_buttons' => true, 'tinymce' => true,'wpautop' => false)
				),
			array(
				'id'=>'dt-footer-position',
				'type' => 'radio',
				'title' => esc_html__('Footer Text Position', 'redux-framework'), 
				'subtitle'=>esc_html__('Select position for the footer text','redux-framework'),
				'options'=>array(
					'left'=>esc_html__('Left', 'redux-framework'),
					'right'=>esc_html__('Right', 'redux-framework'),
					),
				'multi_layout'=>'inline',
				'default'=>'left'
				),
			array(
				'id'=>'showfooterwidget',
				'type' => 'switch', 
				'title' => esc_html__('Footer Widget', 'redux-framework'),
				'subtitle'=> esc_html__('Enable or Disable footer widget', 'redux-framework'),
				"default"=> 0,
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework')
				),	
			array(
				'id'=>'dt-footer-widget-column',
				'type' => 'radio',
				'title' => esc_html__('Footer Widget Columns', 'redux-framework'), 
				'subtitle'=>esc_html__('Select number of column for the footer widget <br>You can set the footer widget on Appearance > Widgets > Bottom Widget Area','redux-framework'),
				'options'=>array(1=>esc_html__('One Column', 'redux-framework'),
					2=>esc_html__('Two Columns', 'redux-framework'),
					3=>esc_html__('Three Columns', 'redux-framework'),
					4=>esc_html__('Four Columns', 'redux-framework')
					),
				'multi_layout'=>'inline',
				'default'=>3
				),
			array(
				'id'=>'footer-color',
				'type' => 'color_nocheck',
				'output' => array('.description'),
				'title' => esc_html__('Footer Background Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select color for the footer background', 'redux-framework'),
				'default' => '#222222',
				'validate' => 'color',
				),	
			array(
				'id'=>'footer-font-color',
				'type' => 'color_nocheck',
				'output' => '',
				'title' => esc_html__('Footer Font Color', 'redux-framework'), 
				'subtitle' => esc_html__('Select color for the footer font', 'redux-framework'),
				'default' => '#ffffff',
				'validate' => 'color',
				),	
			array(
				'id'=>'showfooterpage',
				'type' => 'switch', 
				'title' => esc_html__('Pre and Post Footer', 'redux-framework'),
				'subtitle'=> esc_html__('Enable or Disable pre and post footer area', 'redux-framework'),
				"default"=> 1,
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework')
				),	
			array(
				'id'=>'footerpage',
				'type' => 'select',
				'title' => esc_html__('Pre Footer Page', 'redux-framework'), 
				'subtitle'=>esc_html__('Select page for the pre footer','redux-framework'),
				'data' => 'pages',
				'description'=>'<a class="btn button" href="'.esc_url(admin_url( 'post-new.php?post_type=page', 'relative' )).'" target="_blank">'.esc_html__('Create New Page','redux-framework').'</a>',
			),
			array(
				'id'=>'postfooterpage',
				'type' => 'select',
				'title' => esc_html__('Post Footer Page', 'redux-framework'), 
				'subtitle'=>esc_html__('Select page for the post footer','redux-framework'),
				'data' => 'pages',
				'description'=>'<a class="btn button" href="'.esc_url(admin_url( 'post-new.php?post_type=page', 'relative' )).'" target="_blank">'.esc_html__('Create New Page','redux-framework').'</a>',
			),
			)
		);

	$sections['advance'] = array(
		'icon' => 'el-icon-wrench',
		'title' => esc_html__('Advanced Settings', 'redux-framework'),
		'fields' => array(
			array(
				'id'=>'sandbox-mode',
				'type' => 'switch', 
				'title' => esc_html__('Development Mode', 'redux-framework'),
				'subtitle'=> esc_html__('Please activate this option during development stage', 'redux-framework'),
				'description'=>esc_html__('Few webhosts cached CSS file that causes Theme Option unresponsive','redux-framework'),
				"default"=> 0,
				'on' => esc_html__('On', 'redux-framework'),
				'off' => esc_html__('Off', 'redux-framework')
				),	
	        array(
				'id'=>'css-code',
				'type' => 'ace_editor',
				'title' => esc_html__('CSS Code', 'redux-framework'), 
				'subtitle' => sprintf(esc_html__('Put your CSS code in here<br/>Your css code will saving at %s', 'redux-framework'),'/css/customstyle.css'),
				'mode' => 'css',
	            'theme' => 'monokai',
	            'default' => "body{\nheight: 100%;\n}"
				),
	        array(
				'id'=>'js-code',
				'type' => 'ace_editor',
				'title' => esc_html__('Javascript Code', 'redux-framework'), 
				'subtitle' => esc_html__('Put your Javascript code in here. <br> The code will be loaded at the end of every page', 'redux-framework'),
				'mode' => 'javascript',
	            'theme' => 'chrome',
				'desc' => esc_html__('Be careful!','redux-framework'),
	            'default' => "jQuery(document).ready(function(){\n\n});"
				)
	        )
	);


	global $wp_filesystem;

	$sections['info'] = array(
		'icon' => 'el-icon-info-sign',
		'title' => esc_html__('Theme Information & Update', 'redux-framework'),
		'desc' => '<p class="description">'.esc_html__('The Awesome Wordpress Theme by %s', 'redux-framework').'</p>',
		'fields' => array(
			array(
				'title' => esc_html__('Item Purchase Number', 'redux-framework'),
				'id'=>'detheme_license',
				'type' => 'text',
				'validate_callback'=>'storefy_check_for_update',
				'default'=>get_option("detheme_license_".get_template()),
				'desc' => sprintf(esc_html__('purchase number from %s. ex:xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx', 'redux-framework'),"themeforest.net")
				),
			array(
				'id'=>'raw_new_info',
				'type' => 'raw',
				'content' => $item_info,
				)
			),   
		);

	global $DethemeReduxFramework;
	$DethemeReduxFramework = new DethemeReduxFramework();
	$DethemeReduxFramework->__render($sections, $args, $tabs);

	// END Sample Config
	}

	add_filter('theme_option_name','detheme_redux_option_name');
	add_action('init', 'detheme_redux_init');
endif;

function detheme_redux_option_name($option_name){
	return "storefy_config";
}

if(!function_exists('storefy_darken')){
	function storefy_darken($colourstr, $procent=0) {
	  $colourstr = str_replace('#','',$colourstr);
	  $rhex = substr($colourstr,0,2);
	  $ghex = substr($colourstr,2,2);
	  $bhex = substr($colourstr,4,2);

	  $r = hexdec($rhex);
	  $g = hexdec($ghex);
	  $b = hexdec($bhex);

	  $r = max(0,min(255,$r - ($r*$procent/100)));
	  $g = max(0,min(255,$g - ($g*$procent/100)));  
	  $b = max(0,min(255,$b - ($b*$procent/100)));

	  return '#'.str_repeat("0", 2-strlen(dechex($r))).dechex($r).str_repeat("0", 2-strlen(dechex($g))).dechex($g).str_repeat("0", 2-strlen(dechex($b))).dechex($b);
	}
}

if(!function_exists('storefy_lighten')){

    function storefy_lighten($colourstr, $procent=0){

      $colourstr = str_replace('#','',$colourstr);
      $rhex = substr($colourstr,0,2);
      $ghex = substr($colourstr,2,2);
      $bhex = substr($colourstr,4,2);

      $r = hexdec($rhex);
      $g = hexdec($ghex);
      $b = hexdec($bhex);

      $r = max(0,min(255,$r + ($r*$procent/100)));
      $g = max(0,min(255,$g + ($g*$procent/100)));  
      $b = max(0,min(255,$b + ($b*$procent/100)));

      return '#'.str_repeat("0", 2-strlen(dechex($r))).dechex($r).str_repeat("0", 2-strlen(dechex($g))).dechex($g).str_repeat("0", 2-strlen(dechex($b))).dechex($b);
    }

}

if(!function_exists('storefy_lightenrgba')){

    function storefy_lightenrgba($colourstr, $procent=0){

      $colourstr = str_replace('#','',$colourstr);
      $rhex = substr($colourstr,0,2);
      $ghex = substr($colourstr,2,2);
      $bhex = substr($colourstr,4,2);

      $r = hexdec($rhex);
      $g = hexdec($ghex);
      $b = hexdec($bhex);

      $r = max(0,min(255,$r));
      $g = max(0,min(255,$g));  
      $b = max(0,min(255,$b));

      return 'rgba('.$r.','.$g.','.$b.','.($procent/100).');';
    }

}

if(!function_exists('get_redux_boxed_layout')){
	function get_redux_boxed_layout($args){
		$cssline = "";

		$boxed_layout_activate = isset($args['boxed_layout_activate']) ? $args['boxed_layout_activate'] : 0;

		if ($boxed_layout_activate) {
			$cssline.="body.boxed .paspartu_inner,body.wide .paspartu_inner{ background-image: url(".$args['boxed_layout_boxed_background_image']['url']."); }";

			$boxed_layout_stretched = isset($args['boxed_layout_stretched']) ? $args['boxed_layout_stretched'] : 0;

			if ($boxed_layout_stretched) {
				$cssline.="body.stretched .paspartu_left,".
				" body.stretched .paspartu_right, body.stretched .paspartu_top, ".
				"body.stretched .paspartu_bottom{ background-color: ".$args['boxed_layout_boxed_background_color']."; }";
			}
			else{
				$cssline.="body.boxed .paspartu_inner,body.wide .paspartu_inner{ background-color: ".$args['boxed_layout_boxed_background_color']."; }";

			}


		}


		return $cssline;
	}
}


if(!function_exists('get_redux_body_style')){
	function get_redux_body_style($args){
		$cssline = $backgroundattr= "";

		if (isset($args['body_background_image']['url'])&&!empty($args['body_background_image']['url'])) {
			$cssline.="body.dt_custom_body { background-image: url(".$args['body_background_image']['url']."); }";

			switch($args['body_background_style']){
			    case'parallax':
			        $backgroundattr="background-position: 0% 0%; background-repeat: no-repeat; background-size: cover;";
			        break;
			    case'parallax_all':
			        $backgroundattr="background-position: 0% 0%; background-repeat: repeat; background-size: cover;";
			        break;
			    case'cover':
			        $backgroundattr="background-position: center; background-repeat: no-repeat ; background-size: cover;";
			        break;
			    case'cover_all':
			        $backgroundattr="background-position: center; background-repeat: repeat ; background-size: cover;";
			        break;
			    case'no-repeat':
			        $backgroundattr="background-position: center; background-repeat: no-repeat ;background-size:auto;";
			        break;
			    case'repeat':
			        $backgroundattr="background-position: 0 0;background-repeat: repeat ;background-size:auto;";
			        break;
			    case'contain':
			        $backgroundattr="background-position: center; background-repeat: no-repeat ;background-size: contain;";
			        break;
			    case 'fixed':
			        $backgroundattr="background-position: center; background-repeat: no-repeat ; background-size: cover;background-attachment: fixed;";
			        break;
			    default:
			        $backgroundattr="background-position: center; background-repeat: no-repeat ; background-size: cover;";
			        break;
			}


			$cssline.="body.dt_custom_body { ".$backgroundattr." }";
		}

		if (isset($args['body_background_color'])&&!empty($args['body_background_color'])) {
			$cssline.="body.dt_custom_body, .body_background_color { background-color: ".$args['body_background_color']."; }";
		}

		if (isset($args['body_text_color'])&&!empty($args['body_text_color'])) {
			$cssline.="body.dt_custom_body { color: ".$args['body_text_color']."; }";
		}

		return $cssline;
	}
}

if(!function_exists('get_redux_custom_primary_font')){
	function get_redux_custom_primary_font($font) {

		$primary_font_family = isset($font['font-family']) ? $font['font-family'] : "";

		if(empty($primary_font_family)) return "";

		ob_start();

		if(!empty($primary_font_family) && ''!==$primary_font_family) :
?>
			body,
			.btn,
			.paging-nav,
			.postdate .year,
			.footer-right,
			#dt-menu li a,
			#dt-menu,
			.blog_info_author,
			.blog_info_categories,
			.blog_info_categories a,
			.blog_info_share .share-label,
			.blog_info_share a,
			.btn-readmore,
			.btn.btn-readmore, 
			.woocommerce #reviews #comments ol.commentlist li .comment-text p.meta
			{
			  font-family: <?php print $primary_font_family;?>;
			}

			#dt-menu label { font: 3.125em/1.375em <?php print $primary_font_family;?>; }
			#dt-menu .sub-nav label { font: 2em/2em <?php print $primary_font_family;?>; }
			#dt-menu .sub-nav label { font: 2em/2em <?php print $primary_font_family;?>; }
			#dt-menu .sub-nav:not(.megamenu-sub), #dt-menu .sub-nav:not(.megamenu-sub) a { font-family: <?php print $primary_font_family;?>; }
			.eg-service-grid-element-1 { font-family: <?php print $primary_font_family;?>!important; }
<?php
		endif;

		$line_height = isset($font['line-height']) ? $font['line-height'] : false;
		if(!empty($line_height) && ''!==$line_height && $line_height!='undefinedpx' && $line_height!='px') :
?>
			body,
			.postdate .year,
			.footer-right,
			.paging-nav,
			.btn,
			.eg-service-grid-element-1 {
  				line-height: <?php print $line_height;?>;
			}
<?php
		endif;

		$letter_spacing = isset($font['letter-spacing']) ? $font['letter-spacing'] : "";
		if(!empty($letter_spacing) && ''!==$letter_spacing && $letter_spacing!='undefinedpx' && $letter_spacing!='px') :
?>
			body,
			.postdate .year,
			.footer-right,
			.paging-nav,
			.btn,
			.eg-service-grid-element-1 {
				letter-spacing: <?php print $letter_spacing;?>;
			}
<?php
		endif;
		
		$cssline=ob_get_contents();

		ob_end_clean();

		return $cssline;

	}
} 

if(!function_exists('get_redux_custom_section_font')){
	function get_redux_custom_section_font($font_family=array()){

	if(empty($font_family))
		return '';

	$custom_section_font = isset($font_family['font-family'])? $font_family['font-family'] : "";

	if(empty($custom_section_font)) return "";

	ob_start();

	$custom_section_font = isset($font_family['font-family'])? $font_family['font-family'] : "";
?>
.dt-section-head h1,
.dt-section-head h2,
.dt-section-head h3,
.dt-section-head h4,
.dt-section-head h5,
.dt-section-head h6,
.dtcareers .career-item .career-isotope-button,
.dt-career-container .career-item .career-isotope-button,
.dtcareers #career-filter li a { font-family: <?php print $custom_section_font;?>;
<?php 
$font_weight = isset($font_family['font-weight']) ? $font_family['font-weight']: "";
if(''!=$font_weight && $font_weight!='undefinedpx' && $font_weight!='px'):?>
  font-weight: <?php print $font_weight;?>;
<?php endif;?>
<?php 
$font_style = isset($font_family['font-style']) ? $font_family['font-style'] : "";
if(''!=$font_style && $font_style!='undefinedpx' && $font_style!='px' ):?>
  font-style: <?php print $font_style;?>;
<?php endif;?>
}
<?php
	$cssline=ob_get_contents();
	ob_end_clean();

	return $cssline;
	}
}

if(!function_exists('get_redux_custom_secondary_font')){
	function get_redux_custom_secondary_font($font) {

		$secondary_font_family = isset($font['font-family']) ? $font['font-family'] : "";
		if(empty($secondary_font_family)) return "";

		ob_start();

		if(!empty($secondary_font_family) && ''!==$secondary_font_family) :
?>
			h1,h2,h3,h4,h5,h6,h1,.h2,.h3,.h4,.h5,.h6,
			.horizontal-wp-custom-menu .widget_nav_menu ul li,
			.dt-media .select-target,
			input.secondary_color_button,
			.social-share-link,
			.postdate .day,
			.postmetabottom,
			.dt-comment-author,
			#top-bar,
			footer h3.widget-title,
			.share-button.float-right.sharer-0 label span,
			.carousel-content .carousel-inner a.inline-block,
			.box-main-color .iconbox-detail h3,
			.box-secondary-color .iconbox-detail h3, 
			.postmetatop ul li,
			.singlepostmetatop ul li,
			.dt-comment-date,
			.comment-leave-title,
			.comment-reply-title,
			footer .widget_archive,
			footer .dt_widget_recent_post,
			footer .widget_categories, 
			footer .widget_tag_cloud .tagcloud .tag,
			#sequence ul li .slide-title,
			footer .widget-title h3,
			.woocommerce.widget_product_tag_cloud li, 
			.woocommerce.widget_product_tag_cloud .tagcloud .tag,
			footer .woocommerce.widget_product_tag_cloud .tagcloud .tag,
			h3.dt_report_pre_title, h2.dt_report_title,
			.dt_report_button,
			.eg-service-grid-element-2,
			.eg-portfolio-element-0,
			.eg-portfolio-element-5,
			.billio-nav-skin .esg-filterbutton,
			.billio-nav-skin .esg-navigationbutton,
			.billio-nav-skin .esg-sortbutton,
			.billio-nav-skin .esg-cartbutton,
			.woocommerce table.shop_table th, 
			.woocommerce-page table.shop_table th,
			.woocommerce .cart-collaterals .cart_totals h2, 
			.woocommerce .cart-collaterals .cart_totals h2, 
			.woocommerce-page .cart-collaterals .cart_totals h2, 
			.woocommerce-page .cart-collaterals .cart_totals h2,
			.woocommerce ul.products li.product,
			.woocommerce-page ul.products li.product,
			.woocommerce ul.products li.product .price,
			.woocommerce-page ul.products li.product .price,
			.woocommerce ul.products li.product .add_to_cart_button,
			.woocommerce-page ul.products li.product .add_to_cart_button,
			.widget_rss .rsswidget, 
			.widget_rss cite { 
				font-family: <?php print $secondary_font_family;?>; 
			}


			.widget_archive, 
			.widget_categories,
			.dt_widget_recent_post, 
			.widget_tag_cloud .tagcloud .tag {
			  font-family: inherit;
			}



<?php
		endif;

		$line_height = isset($font['line-height'])  ? $font['line-height'] : "";
		if(!empty($line_height) && ''!==$line_height && $line_height!='undefinedpx' && $line_height!='px') :
?>
			#dt-topbar-menu-left label,
			#dt-topbar-menu-left ul li a:after,
			h1,h2,h3,h4,h5,h6,h1,.h2,.h3,.h4,.h5,.h6,
			.horizontal-wp-custom-menu .widget_nav_menu ul li,
			.dt-media .select-target,
			input.secondary_color_button,
			.social-share-link,
			.postdate .day,
			.dt-comment-author,
			#top-bar,
			footer h3.widget-title,
			.share-button.float-right.sharer-0 label span,
			.carousel-content .carousel-inner a.inline-block,
			.box-main-color .iconbox-detail h3,
			.box-secondary-color .iconbox-detail h3, 
			.postmetatop ul li,
			.singlepostmetatop ul li,
			.dt-comment-date,
			.comment-leave-title,
			.comment-reply-title,
			footer .widget_archive,
			footer .dt_widget_recent_post,
			footer .widget_tag_cloud .tagcloud .tag,
			.dt_widget_recent_post, 
			.widget_tag_cloud .tagcloud .tag,
			#sequence ul li .slide-title,
			footer .widget-title h3,
			.woocommerce #content input.button, 
			.woocommerce #respond input#submit, 
			.woocommerce a.button, 
			.woocommerce button.button, 
			.woocommerce input.button, 
			.woocommerce-page #content input.button, 
			.woocommerce-page #respond input#submit, 
			.woocommerce-page a.button, 
			.woocommerce-page button.button, 
			.woocommerce-page input.button,
			.woocommerce.widget_product_tag_cloud li, 
			.woocommerce.widget_product_tag_cloud .tagcloud .tag,
			.shipping-calculator-button,
			footer .woocommerce.widget_product_tag_cloud .tagcloud .tag,
			h3.dt_report_pre_title, 
			h2.dt_report_title, 
			.dt_report_button,
			.eg-service-grid-element-2,
			.eg-portfolio-element-0,
			.eg-portfolio-element-5,
			.billio-nav-skin .esg-filterbutton,
			.billio-nav-skin .esg-navigationbutton,
			.billio-nav-skin .esg-sortbutton,
			.billio-nav-skin .esg-cartbutton,
			.woocommerce div.product .woocommerce-tabs #reviews #comments .comment_container .comment-text .meta .author, 
			.widget_rss .rsswidget, 
			.widget_rss cite {
  				line-height: <?php print $line_height;?>;
			}
<?php
		endif;

		$font_weight = isset($font['font-weight']) ? $font['font-weight'] : "";

		if(!empty($font_weight) && ''!==$font_weight ) :
?>
			h1,h2,h3,h4,h5,h6,h1,.h2,.h3,.h4,.h5,.h6{
			font-weight: <?php print $font_weight;?>

		}
<?php endif;

		$letter_spacing = isset($font['letter-spacing']) ? $font['letter-spacing'] : "";

		if(!empty($letter_spacing) && ''!==$letter_spacing && $letter_spacing!='undefinedpx' && $letter_spacing!='px') :
?>
			h1,h2,h3,h4,h5,h6,h1,.h2,.h3,.h4,.h5,.h6,
			.horizontal-wp-custom-menu .widget_nav_menu ul li,
			.dt-media .select-target,
			input.secondary_color_button,
			.social-share-link,
			.postdate .day,
			.postmetabottom,
			.dt-comment-author,
			#top-bar,
			footer h3.widget-title,
			.share-button.float-right.sharer-0 label span,
			.carousel-content .carousel-inner a.inline-block,
			.box-main-color .iconbox-detail h3,
			.box-secondary-color .iconbox-detail h3, 
			.postmetatop ul li,
			.singlepostmetatop ul li,
			.dt-comment-date,
			.comment-leave-title,
			.comment-reply-title,
			footer .widget_archive,
			footer .dt_widget_recent_post,
			footer .widget_categories, 
			footer .widget_tag_cloud .tagcloud .tag,
			.widget_archive, 
			.widget_categories,
			.dt_widget_recent_post, 
			.widget_tag_cloud .tagcloud .tag,
			#sequence ul li .slide-title,
			footer .widget-title h3,
			.woocommerce #content input.button, 
			.woocommerce #respond input#submit, 
			.woocommerce a.button, 
			.woocommerce button.button, 
			.woocommerce input.button, 
			.woocommerce-page #content input.button, 
			.woocommerce-page #respond input#submit, 
			.woocommerce-page a.button, 
			.woocommerce-page button.button, 
			.woocommerce-page input.button,
			.woocommerce.widget_product_tag_cloud li, 
			.woocommerce.widget_product_tag_cloud .tagcloud .tag,
			.woocommerce ul.products li.product,
			.woocommerce-page ul.products li.product,
			.woocommerce ul.products li.product .price,
			.woocommerce-page ul.products li.product .price,
			.woocommerce ul.products li.product .add_to_cart_button,
			.woocommerce-page ul.products li.product .add_to_cart_button,
			.cart-popup .button, 
			.shipping-calculator-button,
			footer .woocommerce.widget_product_tag_cloud .tagcloud .tag,
			h3.dt_report_pre_title, 
			h2.dt_report_title, 
			.dt_report_button,
			.eg-service-grid-element-2,
			.eg-portfolio-element-0,
			.eg-portfolio-element-5,
			.billio-nav-skin .esg-filterbutton,
			.billio-nav-skin .esg-navigationbutton,
			.billio-nav-skin .esg-sortbutton,
			.billio-nav-skin .esg-cartbutton,
			.woocommerce div.product .woocommerce-tabs #reviews #comments .comment_container .comment-text .meta .author, 
			.widget_rss .rsswidget, 
			.widget_rss cite,
			.blog_info_author {
				letter-spacing: <?php print $letter_spacing;?>;
			}
<?php
		endif;
		
		$cssline=ob_get_contents();

		ob_end_clean();

		return $cssline;

	}
} 

if(!function_exists('get_redux_custom_quote_font')){

function get_redux_custom_quote_font($font) {

	$tertiary_font_family = isset($font['font-family']) ? $font['font-family'] : "";

	if(empty($tertiary_font_family)) return ""; 

	ob_start();

	if(!empty($tertiary_font_family) && ''!==$tertiary_font_family) :
?>
blockquote, article blockquote, .dt_column blockquote, footer blockquote { font-family: <?php print $tertiary_font_family;?>; }
.blog .postcontent.postcontent-quote { font-family: <?php print $tertiary_font_family;?>; }
.postcontent-quote { font-family: <?php print $tertiary_font_family;?>; }
<?php
	endif;

	$line_height = isset($font['line-height']) ? $font['line-height'] : "";
	if(!empty($line_height) && ''!==$line_height && $line_height!='undefinedpx' && $line_height!='px') :
?>
blockquote, article blockquote, .dt_column blockquote, footer blockquote,
.blog .postcontent.postcontent-quote,
.postcontent-quote {
  line-height: <?php print $line_height;?>;
}

<?php
	endif;

	$letter_spacing =isset($font['letter-spacing']) ? $font['letter-spacing'] : "";
	if(!empty($letter_spacing) && ''!==$letter_spacing && $letter_spacing!='undefinedpx' && $letter_spacing!='px') :
?>
blockquote, article blockquote, .dt_column blockquote, footer blockquote,
.blog .postcontent.postcontent-quote,
.postcontent-quote {
  letter-spacing: <?php print $letter_spacing;?>;
}

<?php
	endif;

	$cssline=ob_get_contents();

	ob_end_clean();

	return $cssline;
}

}

if(!function_exists('get_redux_custom_primary_color')){
function get_redux_custom_primary_color($color='') {

	if(empty($color) && ''!==$color)
		return '';

	ob_start();

	$mainColor=$color;

    @list($r, $g, $b) = sscanf($mainColor, "#%02x%02x%02x");
    $rgbcolor=$r.','.$g.','.$b;

    @list($r50d, $g50d, $b50d) = sscanf(storefy_darken($mainColor,50), "#%02x%02x%02x");
    $rgb50dcolor=$r50d.','.$g50d.','.$b50d;
?>
		h1, h2, h3, h4, h5, h6,
		.primary_color_text,
		.woocommerce nav.woocommerce-pagination ul li a,
		.woocommerce-page nav.woocommerce-pagination ul li a,
		.woocommerce #content nav.woocommerce-pagination ul li a,
		.woocommerce-page #content nav.woocommerce-pagination ul li a,
		.woocommerce nav.woocommerce-pagination ul li span,
		.woocommerce-page nav.woocommerce-pagination ul li span,
		.woocommerce #content nav.woocommerce-pagination ul li span,
		.woocommerce-page #content nav.woocommerce-pagination ul li span,
		.woocommerce nav.woocommerce-pagination ul li span.current,
		.woocommerce-page nav.woocommerce-pagination ul li span.current,
		.woocommerce #content nav.woocommerce-pagination ul li span.current,
		.woocommerce-page #content nav.woocommerce-pagination ul li span.current,
		.woocommerce nav.woocommerce-pagination ul li a:hover,
		.woocommerce-page nav.woocommerce-pagination ul li a:hover,
		.woocommerce #content nav.woocommerce-pagination ul li a:hover,
		.woocommerce-page #content nav.woocommerce-pagination ul li a:hover,
		.woocommerce nav.woocommerce-pagination ul li a:focus,
		.woocommerce-page nav.woocommerce-pagination ul li a:focus,
		.woocommerce #content nav.woocommerce-pagination ul li a:focus,
		.woocommerce-page #content nav.woocommerce-pagination ul li a:focus,
		.woocommerce .woocommerce-checkout #payment #place_order:hover,
		.woocommerce .woocommerce-checkout #payment #place_order:focus {
			color: <?php print $mainColor;?>;
		}

		.primary_color_border { border-color: <?php print $mainColor;?>; }
		.primary_color_button,
		.woocommerce.widget_product_tag_cloud li { background-color: <?php print $mainColor;?>; }


		.woocommerce div.product .woocommerce-tabs #reviews #review_form_wrapper input[type="submit"]:hover {
  			background-color: <?php print storefy_darken($mainColor, 10);?>;
		}

		.blog_info_categories, .blog_info_categories a { color: <?php print $mainColor;?>; }
		.blog_info_categories a:hover { color: <?php print storefy_darken($mainColor,10);?>; }

		.btn-color-primary,
		.portfolio-navigation a.more-post,
		.shipping-calculator-button,
		.woocommerce #content input.button,
		.woocommerce #respond input#submit,
		.woocommerce input.button,
		.woocommerce-page #content input.button,
		.woocommerce-page #respond input#submit,
		.woocommerce-page a.button,
		.woocommerce-page button.button,
		.woocommerce-page input.button,
		.woocommerce.widget_product_search .searchsubmit,
		.woocommerce #content input.button.alt,
		.woocommerce #respond input#submit.alt,
		.woocommerce a.button.alt,
		.woocommerce button.button.alt,
		.woocommerce input.button.alt,
		.woocommerce-page #content input.button.alt,
		.woocommerce-page #respond input#submit.alt,
		.woocommerce-page a.button.alt,
		.woocommerce-page button.button.alt,
		.woocommerce-page input.button.alt,
		.cart-popup .button,
		.woocommerce .single_add_to_cart_button,
		.woocommerce.single-product .product .entry-summary button.single_add_to_cart_button,
		.wooscarcity .wishlist-products .add_to_cart_button,
		.wooscarcity .wishlist-products .product_type_grouped
		{
			background: <?php print $mainColor;?>;
		}

		#customer_details label { color: <?php print $mainColor;?>; }
		
		footer .widget_text ul.list-inline-icon li:hover { border: 1px solid <?php print $mainColor;?>; background: <?php print $mainColor;?>; }
		footer .owl-theme .owl-controls .owl-page span,
		footer .owl-theme .owl-custom-pagination .owl-page span { background-color: <?php print $mainColor;?>; border: 2px solid <?php print $mainColor;?>; }
		footer .owl-theme .owl-controls .owl-page.active span,
		footer .owl-theme .owl-custom-pagination .owl-page.active span { border: 2px solid <?php print $mainColor;?>; }

		footer .widget_tag_cloud .tagcloud .tag a:hover,
		.woocommerce .woocommerce-info, .woocommerce .showcoupon-info,.woocommerce .woocommerce-message {
		  background-color: <?php print $mainColor;?>;
		}

		footer .dt_widget_accordion .btn-accordion {
		  background-color: <?php print $mainColor;?>;
		}

		footer .dt_widget_accordion .opened {
		  background: #ffffff; 
		  color: <?php print $mainColor;?>;
		}

		/* storefy */
		.btn.btn-round.skin-light:hover{
			background-color: transparent !important;
		}
		:selection {background:<?php print $mainColor;?>;}
		::selection {background:<?php print $mainColor;?>;}
		::-moz-selection {background:<?php print $mainColor;?>;}
		
		.pre-footer-section .text-follow .dt-icon:hover,
		.round-ghost,
		.dt_team_custom_item i:hover, 
		.owl-theme .owl-custom-pagination .owl-page.active i, 
		.woocommerce .widget_layered_nav ul li:hover:before, .woocommerce-page .widget_layered_nav ul li:hover:before, .woocommerce .widget_layered_nav ul li:focus:before, .woocommerce-page .widget_layered_nav ul li:focus:before, .woocommerce .widget_layered_nav ul li.chosen:before, .woocommerce-page .widget_layered_nav ul li.chosen:before,
		.woocommerce ul.products li.product .product-loop-item-container .add_to_cart_button, .woocommerce-page ul.products li.product .product-loop-item-container .add_to_cart_button, .woocommerce ul.products li.product .product-loop-item-container .button.product_type_grouped, .woocommerce-page ul.products li.product .product-loop-item-container .button.product_type_grouped,
		.widget_calendar #today,
		.woocommerce .widget_price_filter .price_slider_amount button, .woocommerce-page .widget_price_filter .price_slider_amount button, .woocommerce .widget_price_filter .price_slider_amount .button, .woocommerce-page .widget_price_filter .price_slider_amount .button,
		.woocommerce a.button, .woocommerce-page a.button, .woocommerce button.button, .woocommerce-page button.button, .woocommerce input.button, .woocommerce-page input.button, .woocommerce .button, .woocommerce-page .button, .woocommerce .button.checkout-button, .woocommerce-page .button.checkout-button, .woocommerce .button[disabled]:disabled, .woocommerce-page .button[disabled]:disabled, .woocommerce input.button[disabled]:disabled, .woocommerce-page input.button[disabled]:disabled, .woocommerce a.checkout-button, .woocommerce-page a.checkout-button, .woocommerce .button:disabled, .woocommerce-page .button:disabled, .woocommerce input.button:disabled, .woocommerce-page input.button:disabled,
		.woocommerce.single-product .product .woocommerce-tabs ul.wc-tabs li.active a:after, .woocommerce-page.single-product .product .woocommerce-tabs ul.wc-tabs li.active a:after, .woocommerce.single-product .product .woocommerce-tabs .wc-tabs li.active a:after, .woocommerce-page.single-product .product .woocommerce-tabs .wc-tabs li.active a:after,
		.owl-theme .owl-custom-pagination.pagination-type-navigation i:hover,
		.paging-nav .prev:hover, .paging-nav .next:hover,
		.paging-nav a:hover,
		.paging-nav span.current,
		.woocommerce ul.products li.product .product-loop-action, .woocommerce-page ul.products li.product .product-loop-action,
		.woocommerce ul.products li.product:hover .button, .woocommerce-page ul.products li.product:hover .button, .woocommerce ul.products li.product:hover .add_to_cart_button, .woocommerce-page ul.products li.product:hover .add_to_cart_button,
		.wooscarcity-loop-products .loop-view-type li:hover, .wooscarcity-loop-products .loop-view-type li.active,
		.rounded-btn,
		.woocommerce .product-soldbar .barcolor, .woocommerce-page .product-soldbar .barcolor,
		.wooscarcity-loop-products.table ul.products li.product .button,
		.wooscarcity-loop-products.list ul.products li.product .button,
		.wooscarcity-loop-products.table ul.products li.product .add_to_cart_button,
		.wooscarcity-loop-products.list ul.products li.product .add_to_cart_button,
		.wooscarcity .wishlist-products .add_to_cart_button, .wooscarcity .wishlist-products .button.add_to_cart_button,
		.wooscarcity .wishlist-products .product_type_grouped,
		.wooscarcity .wishlist-products .button.product_type_grouped,
		.wooscarcity .compare-products .add_to_cart_button, .wooscarcity .compare-products .button.add_to_cart_button,
		.wooscarcity .compare-products .product_type_grouped,
		.wooscarcity .compare-products .button.product_type_grouped,
		.round-dark,
		.product-result.woocommerce ul.products li.product .button,
		.product-result.woocommerce ul.products li.product .add_to_cart_button,
		.owl-theme .owl-custom-pagination .owl-page.active i{
			background-color: <?php print $mainColor;?>;
		}
		.select.select-theme-default .select-options .select-option:hover, .select.select-theme-default .select-options .select-option.select-option-highlight,
		.dt-social li:hover,
		.blog_info_share .share-label:hover, .blog_info_share .post-share:hover, .blog_info_share .share-label:focus, .blog_info_share .post-share:focus,
		.main-menu-right li.menu-item .item-count-container,
		.form-outdoor input[type="submit"].btn-round-right,
		.btn.btn-round.skin-light{
			background-color: <?php print $mainColor;?> !important;
		}
		.round-ghost, .round-ghost:hover,
		.woocommerce .widget_layered_nav ul li:hover:before, .woocommerce-page .widget_layered_nav ul li:hover:before, .woocommerce .widget_layered_nav ul li:focus:before, .woocommerce-page .widget_layered_nav ul li:focus:before, .woocommerce .widget_layered_nav ul li.chosen:before, .woocommerce-page .widget_layered_nav ul li.chosen:before,
		.woocommerce .widget_price_filter .price_slider_amount button, .woocommerce-page .widget_price_filter .price_slider_amount button, .woocommerce .widget_price_filter .price_slider_amount .button, .woocommerce-page .widget_price_filter .price_slider_amount .button,
		.woocommerce .widget_price_filter .price_slider .ui-slider-handle, .woocommerce-page .widget_price_filter .price_slider .ui-slider-handle, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle, .woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle, .woocommerce .widget_price_filter .ui-slider-horizontal .ui-slider-handle, .woocommerce-page .widget_price_filter .ui-slider-horizontal .ui-slider-handle,
		.woocommerce a.button, .woocommerce-page a.button, .woocommerce button.button, .woocommerce-page button.button, .woocommerce input.button, .woocommerce-page input.button, .woocommerce .button, .woocommerce-page .button, .woocommerce .button.checkout-button, .woocommerce-page .button.checkout-button, .woocommerce .button[disabled]:disabled, .woocommerce-page .button[disabled]:disabled, .woocommerce input.button[disabled]:disabled, .woocommerce-page input.button[disabled]:disabled, .woocommerce a.checkout-button, .woocommerce-page a.checkout-button, .woocommerce .button:disabled, .woocommerce-page .button:disabled, .woocommerce input.button:disabled, .woocommerce-page input.button:disabled,
		.woocommerce ul.products li.product:hover, .woocommerce-page ul.products li.product:hover,
		.wooscarcity-loop-products.table ul.products li.product .button,
		.wooscarcity-loop-products.list ul.products li.product .button,
		.wooscarcity-loop-products.table ul.products li.product .add_to_cart_button,
		.wooscarcity-loop-products.list ul.products li.product .add_to_cart_button,
		.wooscarcity .wishlist-products .add_to_cart_button, .wooscarcity .wishlist-products .button.add_to_cart_button,
		.wooscarcity .wishlist-products .product_type_grouped,
		.wooscarcity .wishlist-products .button.product_type_grouped,
		.wooscarcity .compare-products .add_to_cart_button, .wooscarcity .compare-products .button.add_to_cart_button,
		.wooscarcity .compare-products .product_type_grouped,
		.wooscarcity .compare-products .button.product_type_grouped,
		.woocommerce .woocommerce-checkout #payment #place_order,
		.rounded-btn:hover,
		.product-result.woocommerce ul.products li.product .button,
		.product-result.woocommerce ul.products li.product .add_to_cart_button{
		  border-color: <?php print $mainColor;?>;
		}
		.blog_info_share .share-label:hover, .blog_info_share .post-share:hover, .blog_info_share .share-label:focus, .blog_info_share .post-share:focus,
		.form-outdoor input[type="submit"].btn-round-right,
		section.heading .heading-search,
		.btn.btn-round.skin-light {
		  border-color: <?php print $mainColor;?> !important;
		}
		.woocommerce ul.products li.product .product-loop-item-container .add_to_cart_button:hover, .woocommerce-page ul.products li.product .product-loop-item-container .add_to_cart_button:hover,
		ul.mgm li.nav-title, ul.mgm li a:hover, .bgwasli ul.sub-menu a:hover, .bgwasli ul.sub-menu li.menu-item:hover > a,
		.widget_shopping_cart_content .product_list_widget li a:hover, .woocommerce-page .widget_shopping_cart_content .product_list_widget li a:hover, .woocommerce .widget_shopping_cart_content ul.product_list_widget li a:hover, .woocommerce-page .widget_shopping_cart_content ul.product_list_widget li a:hover,
		.round-ghost:hover,
		.widget_calendar a,
		.dt_widget_tabs .post-info a:hover,
		#top-bar ul.topbar-menu li a:hover, #top-bar ul.topbar-menu li a:focus,
		.widget_calendar #prev, .widget_calendar #prev a, .widget_calendar #next, .widget_calendar #next a,
		.woocommerce .widget_price_filter .price_slider_amount button:hover, .woocommerce-page .widget_price_filter .price_slider_amount button:hover, .woocommerce .widget_price_filter .price_slider_amount .button:hover, .woocommerce-page .widget_price_filter .price_slider_amount .button:hover,
		.woocommerce table.shop_table td.actions .continue-shopping:hover, .woocommerce .shop_table td.actions .continue-shopping:hover, .woocommerce table.shop_table td.actions .continue-shopping:focus, .woocommerce .shop_table td.actions .continue-shopping:focus,
		.woocommerce table.shop_table td.product-name:hover, .woocommerce .shop_table td.product-name:hover, .woocommerce table.shop_table td.product-name a:hover, .woocommerce .shop_table td.product-name a:hover, .woocommerce table.shop_table td.product-name:focus, .woocommerce .shop_table td.product-name:focus, .woocommerce table.shop_table td.product-name a:focus, .woocommerce .shop_table td.product-name a:focus,
		.woocommerce a.button:hover, .woocommerce-page a.button:hover, .woocommerce button.button:hover, .woocommerce-page button.button:hover, .woocommerce input.button:hover, .woocommerce-page input.button:hover, .woocommerce .button:hover, .woocommerce-page .button:hover, .woocommerce .button.checkout-button:hover, .woocommerce-page .button.checkout-button:hover, .woocommerce .button[disabled]:disabled:hover, .woocommerce-page .button[disabled]:disabled:hover, .woocommerce input.button[disabled]:disabled:hover, .woocommerce-page input.button[disabled]:disabled:hover, .woocommerce a.checkout-button:hover, .woocommerce-page a.checkout-button:hover, .woocommerce .button:disabled:hover, .woocommerce-page .button:disabled:hover, .woocommerce input.button:disabled:hover, .woocommerce-page input.button:disabled:hover,
		.rounded-btn:hover,
		.comment-reply-link, .comment-edit-link,
		.sidebar a:hover,
		.widget_tag_cloud .tagcloud .tag a:hover,
		.dt_widget_accordion .btn-accordion.opened .icon-minus-1:before, .dt_widget_accordion .btn-accordion.opened .icon-plus-1:before,
		.dt_widget_accordion .panel-heading.openedup .panel-title,
		.widget_categories > ul > li a:hover, .dt_widget_recent_post > ul > li a:hover, .widget_recent_entries > ul > li a:hover, .widget_recent_comments > ul > li a:hover, .dt_widget_recent_comments > ul > li a:hover, .widget_rss > ul > li a:hover, .widget_meta > ul > li a:hover, .widget_nav_menu > ul > li a:hover, .widget_archive > ul > li a:hover, .widget_pages > ul > li a:hover,
		h2.blog-post-title:hover, h2.blog-post-title a:hover, h2.blog-post-title:focus, h2.blog-post-title a:focus,
		.history_tab .vc_active .vc_tta-title-text,
		.main-menu li.menu-item:hover > a, .main-menu li.page_item:hover > a, .main-menu li.menu-item:focus > a, .main-menu li.page_item:focus > a,
		section.heading .heading-search i.storefy-search,
		.wooscarcity-loop-products.table ul.products li.product .button:hover,
		.wooscarcity-loop-products.list ul.products li.product .button:hover,
		.wooscarcity-loop-products.table ul.products li.product .add_to_cart_button:hover,
		.wooscarcity-loop-products.list ul.products li.product .add_to_cart_button:hover,
		.wooscarcity .wishlist-products .add_to_cart_button:hover, .wooscarcity .wishlist-products .button.add_to_cart_button:hover,
		.wooscarcity .wishlist-products .product_type_grouped:hover,
		.wooscarcity .wishlist-products .button.product_type_grouped:hover,
		.wooscarcity .compare-products .add_to_cart_button:hover, .wooscarcity .compare-products .button.add_to_cart_button:hover,
		.wooscarcity .compare-products .product_type_grouped:hover, .wooscarcity .compare-products .button.product_type_grouped:hover,
		.btn.btn-round.skin-light:hover,
		.product-result.woocommerce ul.products li.product .button:hover,
		.product-result.woocommerce ul.products li.product .add_to_cart_button:hover{
		  color: <?php print $mainColor;?>;
		}
		/* end storefy */

		a:hover, a:focus { color : <?php print $mainColor;?>; }

		.dt-iconboxes.hover-this .dt-section-icon:hover,
		.dt-iconboxes-2.hover-this:hover .dt-section-icon i.hi-icon,
		.dt-iconboxes-2.hover-this:hover i,
		.dt-iconboxes-2:hover .dt-section-icon i.hi-icon,
		.dt-iconboxes-2:hover i,
		.dt-iconboxes.layout-3.hover-this .dt-section-icon:hover,
		.dt-iconboxes-4.hover-this:hover .dt-section-icon,
		.dt-iconboxes.layout-3 .dt-section-icon:hover,
		.dt-iconboxes.layout-3:hover span,
		.dt-iconboxes-4:hover .dt-section-icon,

		.no-touch .dt-iconboxes-5.hover-this:hover .hi-icon-effect-5 .hi-icon,
		.no-touch .dt-iconboxes-5:hover .hi-icon-effect-5 .hi-icon,
		.dt-iconboxes-5:hover .hi-icon-effect-5 .hi-icon,
		.dt-iconboxes.layout-6.hover-this:hover {
		  background-color: <?php print $mainColor;?> !important;
		}

		footer .dt_widget_accordion .openedup,
		.sidebar .owl-theme .owl-controls .owl-page span,
		.sidebar .owl-theme .owl-custom-pagination .owl-page span {
		  background-color: <?php print $mainColor;?>;
		}

		.sidebar .owl-theme .owl-controls .owl-page.active span,
		.sidebar .owl-theme .owl-custom-pagination .owl-page.active span {
		  border: 2px solid <?php print $mainColor;?>;
		}

		.widget_text ul.list-inline-icon li:hover {
		   border: 1px solid <?php print $mainColor;?>; background: <?php print $mainColor;?>; 
		}

		footer h3,
		footer .widget-title,
		#related-port .related-port figure figcaption .related-tag a {
		  color: <?php print $mainColor;?>;
		}

		.dt_team_custom_item hr:after {
		  width: 50px !important;
		}
		.dt-iconboxes.hover-this .dt-section-icon:hover:after,
		.dt-iconboxes.hover-this .dt-section-icon:hover:before,
		.dt-iconboxes.layout-3:hover span::after,
		.dt-iconboxes.layout-3:hover span::before,
		.dt-iconboxes.layout-3:hover .dt-section-icon:after,
		.dt-iconboxes.layout-3:hover .dt-section-icon:before,
		.dt-iconboxes-4.hover-this:hover .dt-section-icon:after,
		.dt-iconboxes-4.hover-this:hover .dt-section-icon:before,
		.dt-iconboxes-4:hover .dt-section-icon:after,
		.dt-iconboxes-4:hover .dt-section-icon:before,
		.dt-iconboxes.layout-1:hover span::after,
		.dt-iconboxes.layout-1:hover span::before {
		  border-top-color: <?php print $mainColor;?>;
		}

		.dt-iconboxes-4.hover-this:hover .dt-section-icon i:hover,
		.dt-iconboxes-4:hover .dt-section-icon i,
		.dt-iconboxes.layout-6 i,
		.no-touch .dt-iconboxes-4.hover-this:hover .hi-icon-effect-5 .hi-icon,
		.no-touch .dt-iconboxes-4:hover .hi-icon-effect-5 .hi-icon {
		  color: <?php print $mainColor;?>;
		}
		.no-touch .dt-iconboxes-5.hover-this:hover .hi-icon-effect-5 .hi-icon,
		.no-touch .dt-iconboxes-5:hover .hi-icon-effect-5 .hi-icon,
		.dt-iconboxes-5:hover .hi-icon-effect-5 .hi-icon,
		.dt-iconboxes.layout-3:hover span{
		  border-color: <?php print $mainColor;?> !important;
		}

		.dt-iconboxes.layout-3.hover-this .dt-section-icon:hover,
		.woocommerce .single_add_to_cart_button,
		.woocommerce.single-product .product .entry-summary button.single_add_to_cart_button,
		.wooscarcity .wishlist-products .add_to_cart_button,
		.wooscarcity .wishlist-products .product_type_grouped,
		.wooscarcity .wishlist-products .button.add_to_cart_button,
		.wooscarcity .wishlist-products .button.product_type_grouped,
		.dt-iconboxes.layout-1:hover span
		 {
			border-color: <?php print $mainColor;?>;
	    }

		.dt_team_custom_item .profile-scocial a:hover,
		.dt_team_custom_item .profile-scocial i:hover,
		.woocommerce .single_add_to_cart_button:hover,
		.woocommerce.single-product .product .entry-summary button.single_add_to_cart_button:hover,
		.wooscarcity .wishlist-products .add_to_cart_button:hover,
		.wooscarcity .wishlist-products .product_type_grouped:hover,
		.wooscarcity .wishlist-products .wishlist-product-name:hover,
		.wooscarcity .wishlist-products .wishlist-product-name:hover a,
		#top-bar a:hover {
			color: <?php print $mainColor;?>;
		}

		.price-4-col.featured ul, .price-3-col.featured ul,
		.dt-iconboxes.layout-1:hover span{
		  background-color: <?php print $mainColor;?>;
		}
		.price-4-col.featured .hover-tip:before, .price-3-col.featured .hover-tip:before,
		.price-4-col.featured .hover-tip:after, .price-3-col.featured .hover-tip:after {
			border-bottom-color: <?php print storefy_darken($mainColor,30);?>;
		}
		.price-4-col.featured .plan-action:before, .price-3-col.featured .plan-action:before,
		.price-4-col.featured .plan-action:after, .price-3-col.featured .plan-action:after {
			border-top-color: <?php print storefy_darken($mainColor,30);?>;
		}
		.dt-pricing-table .price-4-col .btn-active,
		.dt-pricing-table .price-3-col .btn-active {
		  background-color: <?php print $mainColor;?>;
		}
		.dt-pricing-table .price-4-col .btn-active:hover,
		.dt-pricing-table .price-3-col .btn-active:hover {
		  background-color: <?php print storefy_darken($mainColor,20);?>;
		}
		.mejs-container .mejs-controls .mejs-horizontal-volume-current,
		.mejs-container .mejs-controls .mejs-time-loaded {
		  background-color: <?php print $mainColor;?> !important;
		}

		.select.select-theme-default .select-options .select-option:hover, .select.select-theme-default .select-options .select-option.select-option-highlight {background: <?php print $mainColor;?>;}

		footer .dt_widget_portfolio_posts .post-item figure figcaption {
		  background: rgba(<?php print $rgb50dcolor;?>, 0.6);
		}
		.sidebar .dt_widget_portfolio_posts .portfolio_wrapper .post-item figure figcaption {
		  background: rgba(<?php print $rgb50dcolor;?>, 0.6);
		}
		.dt_widget_featured_posts .post-item figure figcaption {
		  background: rgba(<?php print $rgb50dcolor;?>, 0.6);
		}


		.dt-iconboxes.layout-7.hover-this:hover i{
		  border-color: <?php print storefy_darken($mainColor,35);?> !important;	
		}
		.dt-iconboxes.layout-7 i,
		.dt-iconboxes.layout-8 i {
		  color: <?php print $mainColor;?>;	
		}

		@media (max-width: 768px) {
		  #footer-left {
		    border-bottom: solid 1px <?php print storefy_darken($mainColor,60);?>;
		  }
		}
		.dt-iconboxes-4.hover-this:hover { 
			background-color: <?php print storefy_darken($mainColor,20);?>; 
		}

		.sidebar .woocommerce.widget_product_tag_cloud .tagcloud .tag:hover,
		footer .woocommerce.widget_product_tag_cloud .tagcloud .tag:hover {
		  background-color: <?php print $mainColor;?>;
		}

		.border-color-primary 
		{
		  border-color: <?php print $mainColor;?>;
		}

		.woocommerce .stars a:hover:after { color: <?php print $mainColor;?>; }
		
		.box-main-color .img-blank {
		  background-color: <?php print $mainColor;?>;
		}
		.link-color-primary 
		{
		  color: <?php print $mainColor;?>;
		}
		
		.background-color-primary,
		.dt-icon-square.primary-color, 
		.dt-icon-circle.primary-color, 
		.dt-icon-ghost.primary-color, 
		.sidebar .widget_text .social-circled li:hover, 
		footer .container .widget_text .social-circled li:hover, 
		#featured-work-navbar #featured-filter.dt-featured-filter li.active a, 
		.owl-custom-pagination .owl-page.active i, 
		.wpb_wrapper .wpb_content_element .wpb_accordion_wrapper .ui-state-default .ui-icon:after, 
		.wpb_wrapper .wpb_content_element .wpb_accordion_wrapper .wpb_accordion_header.ui-accordion-header-active,  
		#sequence ul li .btn-cta:after, .dt-iconboxes-4, .dt-iconboxes.hover-this .dt-section-icon:hover, 
		.dt-iconboxes-2.hover-this:hover .dt-section-icon i.hi-icon, .dt-iconboxes-2.hover-this:hover i, 
		.dt-iconboxes.layout-3.hover-this .dt-section-icon:hover, .dt-iconboxes-4.hover-this:hover .dt-section-icon, 
		.no-touch .dt-iconboxes-5.hover-this:hover .hi-icon-effect-5 .hi-icon, 
		.dt-iconboxes.layout-6.hover-this:hover, 
		.dt-iconboxes.layout-6:hover, 
		.dt-iconboxes.layout-3.hover-this .dt-section-icon:hover {
		  background: none repeat scroll 0 0 <?php print $mainColor;?>;
		}
		.bulat2 {
		  background: none repeat scroll 0 0 <?php print $mainColor;?>;
		}
		#featured-work-navbar #featured-filter.dt-featured-filter li.active {
		  border: 1px solid <?php print $mainColor;?> !important;
		}
		.no-touch .dt-iconboxes-5.hover-this:hover .hi-icon-effect-5 .hi-icon {
		  background-color: <?php print $mainColor;?>;
		  border-color: <?php print $mainColor;?>;
		}
		.container .owl-theme .owl-controls .owl-page span,
		.container .owl-theme .owl-custom-pagination:not(.pagination-type-text) .owl-page span {
		  background-color: <?php print $mainColor;?>;
		  border-color: <?php print $mainColor;?>; 
		}
		.owl-theme .owl-custom-pagination.pagination-type-text .owl-page.active span{
			border-bottom-color: <?php print $mainColor;?>; 
		}
		.owl-theme .owl-controls .owl-page.active span,
		.owl-theme .owl-custom-pagination:not(.pagination-type-text) .owl-page.active span {
		  border-color: <?php print $mainColor;?>; 
		}
		.container .carousel-content .carousel-indicators li {
		  	background-color: <?php print $mainColor;?>;
		  	border-color: <?php print $mainColor;?>; 
		}
		.container .carousel-content .carousel-indicators .active {
		  	border-color: <?php print $mainColor;?>; 
		}
		.dt-iconboxes.hover-this .dt-section-icon:hover {
		  	border-color: <?php print $mainColor;?>;
		}
		.dt_vertical_tab .vertical-nav-tab > li > div i { color: <?php print $mainColor;?>; }
		.wpb_wrapper .wpb_content_element .wpb_accordion_wrapper .ui-state-active .ui-icon:after {
			color: <?php print $mainColor;?>;
		}
		.wpb_wrapper .wpb_content_element .wpb_tabs_nav li.ui-tabs-active {
			background: none repeat scroll 0 0 <?php print $mainColor;?>;
		}

		.btn.btn-link { color: <?php print $mainColor;?>; }
		.btn.btn-link:hover { color: <?php print $mainColor;?>; }
		
		.btn.btn-rounded { color: <?php print $mainColor;?>; border-color: <?php print $mainColor;?>; }

		footer .widget-title h3:after { border-top: 2px solid <?php print $mainColor;?>; }

		.woocommerce div.product .woocommerce-tabs #reviews #comments .comment_container .comment-text .meta .datePublished {
			color: <?php print $mainColor;?>;
		}

		.woocommerce div.product .woocommerce-tabs #reviews #comments .comment_container .comment-text .meta .datePublished,
		.dtcareers .career-isotope-job-field i,
		.dt_report_pre_title { color : <?php print $mainColor;?>; }

		.dt_report_button a { background-color : <?php print $mainColor;?>; }
		.dt_report_button a:hover { background-color : <?php print storefy_darken($mainColor,30);?>; }
		.dt_report_pagination .page-numbers.current { background-color: <?php print $mainColor;?>; }
		.dt_report_pagination .page-numbers:hover { background-color: <?php print $mainColor;?>; }

		.eg-portfolio-element-5 {background-color: <?php print $mainColor;?>!important;}
		.eg-portfolio-element-5:hover {background-color: <?php print storefy_darken($mainColor,10);?>!important;}

		.widget a:hover{ color: <?php print $mainColor;?>; }
		.flex-control-paging li a.flex-active, .flex-control-paging li a:hover {
  			background: <?php print $mainColor;?>!important;
		}

		.dt-timeline .time-item:hover .center-line i { background: <?php print $mainColor;?>; }
		.dt-timeline .time-item:hover .content-line { border-color: <?php print $mainColor;?>; }
		.dt-timeline .time-item:hover .content-line:before { border-color: <?php print $mainColor;?>; }
		.dt-media .select-target { background-color: <?php print $mainColor;?>; }
		
		.horizontal-wp-custom-menu li.current-menu-item { background-color: <?php print $mainColor;?>; }
		.horizontal-wp-custom-menu .widget_nav_menu ul { border-top-color: <?php print $mainColor;?>!important; }

		.dt-icon.primary-color { color: <?php print $mainColor;?>; }
		.products .type-product .button:hover,
		.products .type-product .woocommerce_after_shop_loop_item_title .button:hover
	 	{ 
			background-color: <?php print storefy_darken($mainColor,10);?>; 
		}


		.dt-shop-category .owl-carousel-navigation .btn-owl { background-color: <?php print $mainColor;?>; }
		.dt-shop-category .owl-carousel-navigation .btn-owl:hover { background-color: <?php print storefy_darken($mainColor,10);?>!important; }
		.widget_rss .rsswidget { color: <?php print $mainColor;?>; }
		.dt-pricing-table .plan-price { color: <?php print $mainColor;?>; }
		.wplc-color-bg-1 { background-color: <?php print $mainColor;?>!important; }

		.section-heading-triple-dots:after, .section-heading-triple-dashes:after, .section-heading-triple-square-dots:after { color: <?php print $mainColor;?>; }
		.section-heading-horizontal-line-fullwidth:before, .section-heading-horizontal-line-fullwidth:after, .section-heading-horizontal-line:before, .section-heading-horizontal-line:after { background-color: <?php print $mainColor;?>; }
<?php
	$cssline=ob_get_contents();
	ob_end_clean();

	return $cssline;
}
}

if(!function_exists('get_redux_custom_headings_color')){
	function get_redux_custom_headings_color($color=''){
	if(empty($color) && ''!==$color)
		return '';

	ob_start();
?>
	h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6,
	.woocommerce table.shop_table th, 
	.woocommerce-page table.shop_table th,
	.woocommerce .cart-collaterals .cart_totals h2, 
	.woocommerce .cart-collaterals .cart_totals h2, 
	.woocommerce-page .cart-collaterals .cart_totals h2, 
	.woocommerce-page .cart-collaterals .cart_totals h2, 
	.woocommerce table.shop_table td.actions .update_cart:hover,
	.woocommerce .shop_table td.actions .update_cart:hover,
	.woocommerce table.shop_table td.actions .update_cart:focus,
	.woocommerce .shop_table td.actions .update_cart:focus
 { color: <?php print $color;?>; }

	.blog .postcontent table thead th, .single .postcontent table thead th,
	.page .postcontent table thead th, .section-comment table thead th,
	.blog .postcontent table tbody tr:first-child th, .single .postcontent table tbody tr:first-child th,
	.page .postcontent table tbody tr:first-child th, .section-comment table tbody tr:first-child th
	{
   		background-color: <?php print $color;?>;
	}

	.page .postcontent table tbody tr:first-child th{
		background: none;
	}

<?php 

	$cssline=ob_get_contents();
	ob_end_clean();

	return $cssline;

}
}

if(!function_exists('get_redux_custom_secondary_color')){
function get_redux_custom_secondary_color($color='') {

	if(empty($color) && ''!==$color)
		return '';

	ob_start();

	$mainColor=$color;

    @list($r, $g, $b) = sscanf($mainColor, "#%02x%02x%02x");
    $rgbcolor=$r.','.$g.','.$b;
?>
		
		.secondary_color_bg { background-color: <?php print $mainColor;?>; }
		.secondary_color_text { color: <?php print $mainColor;?>; }
		.secondary_color_border { border-color: <?php print $mainColor;?>; }

		.secondary_color_button, .btn-color-secondary {
		  background-color: <?php print $mainColor;?>;
		}
		.secondary_color_button:hover, .btn-color-secondary:hover {
		  background-color: <?php print storefy_darken($mainColor,20);?>!important;
		}
		.background-color-secondary,
		.dt-icon-circle.secondary-color,
		.dt-icon-ghost.secondary-color,
		.dt-icon-square.secondary-color,
		#sequence ul.sequence-canvas li .slide-title:after,
		:selection,
		::selection,
		::-moz-selection {
		  background: <?php print $mainColor;?>;
		}
		.woocommerce.widget_product_tag_cloud li:hover {
		  background-color: <?php print $mainColor;?>;
		}
		.woocommerce ul.products li.product .onsale:after,
		.woocommerce-page ul.products li.product .onsale:after,
		.woocommerce span.onsale:after,
		.woocommerce-page span.onsale:after {
		  border-bottom: 40px solid <?php print $mainColor;?>;
		}

		.dt-iconboxes a,
		h1 a:hover,
		h2 a:hover,
		h3 a:hover,
		h4 a:hover,
		h5 a:hover,
		h6 a:hover,
		h1 a:focus,
		h2 a:focus,
		h3 a:focus,
		h4 a:focus,
		h5 a:focus,
		h6 a:focus,
		.portfolio-type-text .portfolio-item .portfolio-termlist a,
		footer .widget_recent_comments a:hover,
		.sidebar a:hover, 
		.sidebar .dt-widget-twitter .sequence-twitter a,
		.widget_recent_comments a:hover,
		.share-button label span, 
		.post-masonry li.isotope-item .isotope-inner .comment-count i:before,
		.post-masonry li.isotope-item .post-info .author a,
		.dt-icon.secondary-color,
		.widget_tag_cloud .tagcloud .tag a:hover{ color: <?php print $mainColor;?>; }

		.dt-section-head header i {
		  background: <?php print $mainColor;?>;
		}
		.progress_bars i {
		  background-color: <?php print $mainColor;?>;
		}

		.box-secondary-color .img-blank {
		  background-color: <?php print $mainColor;?>;
		}
		.bulat1 {
		  background: none repeat scroll 0 0 <?php print $mainColor;?>;
		}

<?php
	$cssline=ob_get_contents();
	ob_end_clean();

	return $cssline;
}
}

if(!function_exists('get_redux_custom_footer_bg_color')){
function get_redux_custom_footer_bg_color($color='') {

	if(empty($color) && ''!==$color)
		return '';

	ob_start();

	$footer_bg_color = $color;

    @list($r, $g, $b) = sscanf($footer_bg_color, "#%02x%02x%02x");
    $rgbcolor=$r.','.$g.','.$b;
?>
		.tertier_color_bg {background-color: <?php print $footer_bg_color;?>; }
<?php
	$cssline=ob_get_contents();
	ob_end_clean();

	return $cssline;
}
}

if(!function_exists('get_redux_custom_footer_font_color')){
function get_redux_custom_footer_font_color($color='') {

	if(empty($color) && ''!==$color)
		return '';

	ob_start();

	$footer_font_color = $color;

    @list($r, $g, $b) = sscanf($footer_font_color, "#%02x%02x%02x");
    $rgbcolor=$r.','.$g.','.$b;
?>
		.footer-left { color: <?php print $footer_font_color;?>; }
		.footer-right { color: <?php print $footer_font_color;?>; }
		footer a { color: <?php print $footer_font_color;?>; }
		footer .widget-title { color: <?php print $footer_font_color;?>; }
		footer .container .widget_text .social-circled li,
		footer .container .widget_text .social-circled li:last-child,
		footer .woocommerce ul.cart_list li,
		footer .woocommerce ul.product_list_widget li,
		footer .woocommerce-page ul.cart_list li,
		footer .woocommerce-page ul.product_list_widget li,
		footer .woocommerce.widget_product_categories li,
		footer .widget_tag_cloud .tagcloud .tag,
		footer .dt_widget_accordion .panel-heading,
		footer .dt_widget_accordion .panel-body,
		footer .widget_categories ul li,
		footer .widget_recent_entries ul li,
		footer .widget_recent_comments ul li,
		footer .widget_rss ul li,
		footer .widget_meta ul li,
		footer .widget_nav_menu ul li,
		footer .widget_archive ul li,
		footer .widget_text ul li,
		footer .woocommerce.widget_product_tag_cloud .tagcloud .tag {
		  border-color: rgba(<?php print $rgbcolor;?>, 0.4);
		}

		footer .widget_text ul.list-inline-icon li {
		  border: 1px solid rgba(<?php print $rgbcolor;?>, 0.4);
		}

		footer .widget_search {
		  color: <?php print $footer_font_color;?>;
		}

		footer .widget_search [name="s"] {
		  border: 1px solid rgba(<?php print $rgbcolor;?>, 0.4);
		  color: <?php print $footer_font_color;?>;
		}

		footer .select-target.select-theme-default {
	  		border: 1px solid rgba(<?php print $rgbcolor;?>, 0.4);
		}

		footer .dt_widget_accordion .panel-heading {
		  color: <?php print $footer_font_color;?>;
		}
		
		footer .widget_recent_comments a {
		  color: rgba(<?php print $rgbcolor;?>, 0.4);
		}

		footer .woocommerce.widget_product_search [name="s"] {
		  border: 1px solid rgba(<?php print $rgbcolor;?>, 0.4);
		}
<?php
	$cssline=ob_get_contents();
	ob_end_clean();

	return $cssline;
}

}

if(!function_exists('get_redux_mainmenu_style')){
	function get_redux_mainmenu_style($args=array()) {

		$line_height=isset($args['dt-menu-height']) ? intval($args['dt-menu-height']) : 0;

		ob_start();

		if(!empty($line_height)):
	?>
		section.top-head, .main-navigation-container,.left-navigation-menu .toggle-menu { min-height: <?php print $line_height;?>px; }
		.main-navigation-container{ padding: <?php print ($line_height - 64)/2;?>px 0;}
	<?php
		endif;

	$header_color=( isset($args['header-color']['color']) && $args['header-color']['color'] !='' ) ? storefy_hex2rgba($args['header-color']['color'],$args['header-color']['alpha']) : "";

	if($header_color=='rgba(0,0,0,0)'){
		$header_color = "transparent";
	}

	if (!empty($header_color)) {?>
		section.top-head { background-color: <?php print $header_color;?> }
	<?php }

	$header_font_color=isset($args['header-font-color']) ? $args['header-font-color'] : "";

	if (!empty($header_font_color)) {?>
		.main-menu li.menu-item > a,
		.main-menu li.page_item > a,
		.main-menu .sub-menu li.menu-item:hover,
		.main-menu .children li.menu-item:hover,
		.main-menu .sub-menu li.page_item:hover,
		.main-menu .children li.page_item:hover,
		.main-menu .sub-menu li.menu-item:focus,
		.main-menu .children li.menu-item:focus,
		.main-menu .sub-menu li.page_item:focus,
		.main-menu .children li.page_item:focus,
		.main-menu .sub-menu li.menu-item:hover > a,
		.main-menu .children li.menu-item:hover > a,
		.main-menu .sub-menu li.page_item:hover > a,
		.main-menu .children li.page_item:hover > a,
		.main-menu .sub-menu li.menu-item:focus > a,
		.main-menu .children li.menu-item:focus > a,
		.main-menu .sub-menu li.page_item:focus > a,
		.main-menu .children li.page_item:focus > a,
		.main-menu-right li.menu-item > a,
		.left-navigation-menu, .left-navigation-menu a,
		.left-navigation-menu .main-menu > li:hover > a,
		.left-navigation-menu .main-menu > li:focus > a,
		.widget_shopping_cart_content .product_list_widget li a,
		.woocommerce-page .widget_shopping_cart_content .product_list_widget li a,
		.woocommerce .widget_shopping_cart_content ul.product_list_widget li a,
		.woocommerce-page .widget_shopping_cart_content ul.product_list_widget li a,
		.main-menu .expand-menu,
		.mobile .main-menu-wrapper .main-menu li.menu-item:hover > a,
		.mobile .main-menu-wrapper .main-menu li.page_item:hover > a,
		.mobile .main-menu-wrapper .main-menu li.menu-item:focus > a,
		.mobile .main-menu-wrapper .main-menu li.page_item:focus > a
		 {
		  color: <?php print $header_font_color;?>;
		}

		.left-navigation-menu .toggle-menu .menu-bar span,
		.mobile .toggle-main-menu .menu-bar span{
		 background: <?php print $header_font_color;?>;
		}

	<?php } 

		$header_sticky_bg_color=( isset($args['header-color-sticky']['color']) && $args['header-color-sticky']['color'] !='' ) ? storefy_hex2rgba($args['header-color-sticky']['color'],$args['header-color-sticky']['alpha']) : "";

		if($header_sticky_bg_color=='rgba(0,0,0,0)'){
			$header_sticky_bg_color = "transparent";
		}

		if (!empty($header_sticky_bg_color)) {
			print ".top-head.sticky { background-color: ".$header_sticky_bg_color."; }";
		}

		$header_font_color_sticky=isset($args['header-font-color-sticky']) ? $args['header-font-color-sticky'] : "";

	if (!empty($header_font_color_sticky)) {?>
		.sticky .main-menu > li.menu-item > a,
		.sticky .main-menu > li.page_item > a,
		.sticky .main-menu .sub-menu li.menu-item:hover,
		.sticky .main-menu .sub-menu li.page_item:hover,
		.sticky .main-menu .sub-menu li.menu-item:focus,
		.sticky .main-menu .sub-menu li.page_item:focus,
		.sticky .main-menu .sub-menu li.menu-item:hover > a,
		.sticky .main-menu .sub-menu li.page_item:hover > a,
		.sticky .main-menu .sub-menu li.menu-item:focus > a,
		.sticky .main-menu .sub-menu li.page_item:focus > a,
		.sticky .main-menu .children li.page_item:focus > a,
		.sticky .main-menu-right li.menu-item > a,
		.sticky .left-navigation-menu, .left-navigation-menu a,
		.sticky .left-navigation-menu .main-menu > li:hover > a,
		.sticky .left-navigation-menu .main-menu > li:focus > a,
		.sticky .widget_shopping_cart_content .product_list_widget li a,
		.sticky .woocommerce-page .widget_shopping_cart_content .product_list_widget li a,
		.sticky .woocommerce .widget_shopping_cart_content ul.product_list_widget li a,
		.sticky .woocommerce-page .widget_shopping_cart_content ul.product_list_widget li a,
		.sticky .main-menu .expand-menu,
		.sticky .mobile .main-menu-wrapper .main-menu li.menu-item:hover > a,
		.sticky .mobile .main-menu-wrapper .main-menu li.page_item:hover > a,
		.sticky .mobile .main-menu-wrapper .main-menu li.menu-item:focus > a,
		.sticky .mobile .main-menu-wrapper .main-menu li.page_item:focus > a
		 {
		  color: <?php print $header_font_color_sticky;?>;
		}
	<?php } 
		$cssline=ob_get_contents();
		ob_end_clean();
		return $cssline;
	}
}

if(!function_exists('get_redux_custom_page_loader')){
	function get_redux_custom_page_loader($args=array()) {
		$cssline="";

		if ($args['page_loader']==1) {
			$cssline.=".modal_preloader { background-color: ".$args['page_loader_background']."; }";
			$cssline.=".ball_1 { background-color: ".$args['page_loader_ball_1']."; }";
			$cssline.=".ball_2 { background-color: ".$args['page_loader_ball_2']."; }";
			$cssline.=".ball_3 { background-color: ".$args['page_loader_ball_3']."; }";
			$cssline.=".ball_4 { background-color: ".$args['page_loader_ball_4']."; }";
		}

		return $cssline;
	}
}

if(!function_exists('get_redux_custom_sticky_sidebar')){
	function get_redux_custom_sticky_sidebar($args) {

	ob_start();
	?>
		@media(min-width: 768px) {
			#floatMenu {
				<?php print (!empty($args['dt_scrollingsidebar_position']) && !empty($args['dt_scrollingsidebar_margin']))?$args['dt_scrollingsidebar_position'].":".intval($args['dt_scrollingsidebar_margin'])."px;".($args['dt_scrollingsidebar_position']=='left'?"right:auto;":""):"";
				print (!empty($args['dt_scrollingsidebar_top_margin']))?"top: ".intVal($args['dt_scrollingsidebar_top_margin'])."px;":"";
				print ($args['dt_scrollingsidebar_bg_type'] && !empty($args['dt_scrollingsidebar_bg_color']))?"background-color: ".$args['dt_scrollingsidebar_bg_color'].";":"";?>;
			}
		}
	<?php
		$cssline=ob_get_contents();
		ob_end_clean();

		return $cssline;
	}
}

function get_redux_heading_style($args){

	$cssline="";

	if (isset($args['dt-logo-width']) && !empty($args['dt-logo-width'])) {
		$cssline.="section.heading .header-logo img { max-width: ".$args['dt-logo-width']."px; }";
	}

	if(isset($args['header-background-color']) && !empty($args['header-background-color'] ) && $args['header-background-color']['color']!='' ){

		$header_bg_color = storefy_hex2rgba($args['header-background-color']['color'],$args['header-background-color']['alpha']);
		if($header_bg_color=='rgba(0,0,0,0)'){
			$header_bg_color="transparent";
		}

		$cssline.="section.heading,section.heading .heading-search input,.main-menu .sub-menu, .main-menu .children,".
				".main-menu-right .sub-menu .cart-popup, .main-menu-right .children .cart-popup,.left-navigation-menu .main-menu,".
				".mobile .main-menu-wrapper .main-menu,.mobile .main-menu-wrapper .main-menu .sub-menu-container,".
				"#top-bar ul.topbar-menu .sub-menu { background-color:".$header_bg_color.";}";


	}

	if(isset($args['header-text-color']) && !empty($args['header-text-color'])){
		$cssline.="section.heading,section.heading a,".
		"section.heading .heading-search .select-target.select-theme-default,".
		"#top-bar ul.topbar-menu .sub-menu li.menu-item a,#top-bar ul.topbar-menu .sub-menu li.menu-item:hover a{ color:".$args['header-text-color'].";}";

		$cssline.="section.heading .heading-search input.search-field::-moz-placeholder { color:".$args['header-text-color'].";}";
		$cssline.="section.heading .heading-search input.search-field::-webkit-placeholder { color:".$args['header-text-color'].";}";

	}

	if(isset($args['header-icons-color']) && !empty($args['header-icons-color'])){
		$cssline.="section.heading .navigation_button_item i { color:".$args['header-icons-color'].";}";
	}


	return $cssline;
}

if(!function_exists('get_redux_custom_topbar')){
	function get_redux_custom_topbar($args) {
		$cssline = "";

		if (is_array($args['topbar-background-color']) 
			&& isset($args['topbar-background-color']['color']) 
			&& $args['topbar-background-color']['color'] !='' ){

		      	if($args['topbar-background-color']['color']=='transparent' || 
		      		(isset($args['topbar-background-color']['rgba']) &&  $args['topbar-background-color']['rgba']=='rgba(0,0,0,0)')){

		      		$cssline.="#top-bar { background-color: transparent; }";

		      	}
		      	else{

					$colourstr = $args['topbar-background-color']['color'];
					$colourstr = str_replace('#','',$colourstr);
			      	$rhex = substr($colourstr,0,2);
			      	$ghex = substr($colourstr,2,2);
			      	$bhex = substr($colourstr,4,2);

			      	$r = hexdec($rhex);
			      	$g = hexdec($ghex);
			      	$b = hexdec($bhex);

			      	$a = $args['topbar-background-color']['alpha'];

			      	$cssline.="#top-bar { background-color: rgba(".$r.",".$g.",".$b.",".$a."); }";
		      		
		      	}

		}

		$cssline.="#top-bar, #top-bar a {color:".$args['topbar-font-color'].";}";

		if (isset($args['topbar-height']) && intval($args['topbar-height'])) {
			$cssline.="#top-bar { min-height: ".$args['topbar-height']."px; }";
			$cssline.="#top-bar ul.topbar-menu { line-height: ".$args['topbar-height']."px; }";
		}

		return $cssline;
	}
}

if(!function_exists('get_redux_blog_type_masonry')){
	function get_redux_blog_type_masonry($args){
		$masonry_column=min(max(1,intval($args['masonry_column'])),4);
		$masonry_column_tablet=min(max(1,intval($args['masonry_column_tablet'])),3);
		$masonry_column_mobile=min(max(1,intval($args['masonry_column_mobile'])),2);

		$desktop_column=floor(100/$masonry_column);
		$tablet_column=floor(100/$masonry_column_tablet);
		$mobile_column=floor(100/$masonry_column_mobile);

		$cssline=".grid li {
			width: ".$desktop_column."%;
		}";

		$cssline.="@media screen and (min-width: 601px) and (max-width: 900px) {
			.grid li {
				width: ".$tablet_column."%;
			}
		}";

		$cssline.="@media screen and (max-width: 600px) {
			.grid li {
				width: ".$mobile_column."%;
			}
		}";

		return $cssline;
	}
}

if(!function_exists('get_redux_body_text_color')){

	function get_redux_body_text_color($body_text_color){
		$cssline="";

		$cssline.= ".woocommerce nav.woocommerce-pagination ul li { border-color: ".$body_text_color."; }";
		$cssline.=".dtcareers .career-item,.dtcareers .career-item .career-isotope-button{ border-color: ".$body_text_color.";}";
		$cssline.=".menu-leftvc #dt-menu .sub-nav a { color: ".$body_text_color."; }";
		$cssline.=".author_date_tags a { color: ".$body_text_color."; }";
		$cssline.=".author_date_tags a:hover { color: ".storefy_darken($body_text_color,10)."; }";

		return $cssline;	
	}
}

if(!function_exists('storefy_style_compile')){

function storefy_style_compile($storefy_config=array(),$css="",$write=true){

	global $wp_filesystem;


	if(function_exists('icl_register_string')){
		icl_register_string('storefy', 'left-top-bar-text', $storefy_config['dt-left-top-bar-text']);
		icl_register_string('storefy', 'right-top-bar-text', $storefy_config['dt-right-top-bar-text']);
		icl_register_string('storefy', 'footer-text', $storefy_config['footer-text']);
	}

	$cssline=(isset($storefy_config['primary-color']))?get_redux_custom_primary_color($storefy_config['primary-color']):"";
	$cssline.=(isset($storefy_config['secondary-color']))?get_redux_custom_secondary_color($storefy_config['secondary-color']):"";
	$cssline.=(isset($storefy_config['headings-color']))?get_redux_custom_headings_color($storefy_config['headings-color']):"";
	$cssline.=get_redux_custom_primary_font($storefy_config['primary-font']);
	$cssline.=get_redux_custom_secondary_font($storefy_config['secondary-font']);

	$cssline.=get_redux_custom_section_font($storefy_config['section-font']);

	$cssline.=get_redux_custom_quote_font($storefy_config['tertiary-font']);

	$cssline.=(isset($storefy_config['footer-color']))?get_redux_custom_footer_bg_color($storefy_config['footer-color']):"";
	$cssline.=(isset($storefy_config['footer-font-color']) && '#ffffff'!=$storefy_config['footer-font-color'])?get_redux_custom_footer_font_color($storefy_config['footer-font-color']):"";

	$cssline.=get_redux_heading_style($storefy_config);

	$cssline.=get_redux_body_style($storefy_config);

	$cssline.=get_redux_boxed_layout($storefy_config);
	$cssline.=get_redux_custom_sticky_sidebar($storefy_config);

	$cssline.=get_redux_mainmenu_style($storefy_config);

	if(isset($storefy_config['heading-style']) && $storefy_config['heading-style']!=='none'){
		$cssline.="h1,h2,h3,h4,h5,h6,.breadcrumbs{text-transform:".$storefy_config['heading-style']."}";
	}

	$cssline.=get_redux_custom_page_loader($storefy_config);
	$cssline.=isset($storefy_config['blog_type']) && $storefy_config['blog_type']=='masonry' ? get_redux_blog_type_masonry($storefy_config) : "";
	$cssline.=(isset($storefy_config['css-code']) && !empty($storefy_config['css-code']))?"\n/* custom css generate from your custom css code*/\n".$storefy_config['css-code']:"";	
	$cssline.=(isset($storefy_config['topbar-background-color']))?get_redux_custom_topbar($storefy_config):"";

	$cssline.=isset($storefy_config['body_text_color']) && !empty($storefy_config['body_text_color']) ? get_redux_body_text_color($storefy_config['body_text_color']) : "";

	$blog_id="";
	if ( is_multisite()){
		$blog_id="-site".get_current_blog_id();
	}

	if(!$write){
		return $css.$cssline;
	}

	$filename = get_template_directory() . '/css/customstyle'.$blog_id.'.css';

	$notes="/* ================================================ */\n"
				."/* don't touch this style auto generating by system */\n"
				."/* ================================================ */\n";

	if ( !$wp_filesystem->put_contents( $filename, $notes.$cssline) ) {
		$error = $wp_filesystem->errors;

		if('empty_hostname'==$error->get_error_code()){
			$wp_filesystem=new WP_Filesystem_Direct(array());
			if($wp_filesystem){
				if(!$wp_filesystem->put_contents( $filename, $notes.$cssline)){
						$error = $wp_filesystem->errors;
						return new WP_Error('fs_error', esc_html__('Filesystem error','redux-framework'), $error);
				}

			}else{
				return $css;
			}


		}else{

			return $css;
		}
	}
	return $css.$cssline;
}
}

if(!function_exists('storefy_save_license')){


function storefy_save_license($config=array()){

	$template=get_template();
	update_option("detheme_license_$template",$config['detheme_license']);
}

}

add_action( 'redux-saved-storefy_config' ,'storefy_save_license' ); 
add_action('redux-compiler-storefy_config','storefy_style_compile',2);

/* wpml translation */


if(!function_exists('storefy_load_admin_script')){

	function storefy_load_admin_script(){
		wp_enqueue_script('detheme-admin-script', DethemeReduxFramework::$_url. 'assets/js/dashboard.js',array('jquery'));
	}
}

add_action( 'redux/page/storefy_config/enqueue','storefy_load_admin_script' );

add_action('theme_option_name_update','storefy_style_compile');

function storefy_theme_update_complete($theme,$hook_extra){

	if('theme'==$hook_extra['type'] && 'update'==$hook_extra['action'] && $theme->skin->theme == get_template()){
		$option_name=apply_filters('theme_option_name','theme_config');
		$theme_config=get_option($option_name);
		do_action('theme_option_name_update',$theme_config);
	}
}

add_action('upgrader_process_complete','storefy_theme_update_complete',1,2);

function get_storefy_options(){

	global $DethemeReduxFramework;

	if(!is_object($DethemeReduxFramework)){

      $DethemeReduxFramework= new DethemeReduxFramework();
	
	    $args['opt_name']           = 'storefy_config'; 
	    $args['database']           = ''; 
	    $args['global_variable']    = '';

	    $DethemeReduxFramework->args= $args;
	}

	$theme_config=$DethemeReduxFramework->get_options();

	$new_theme_config=apply_filters('detheme_options_config',$theme_config);

	return $new_theme_config;

}


function get_storefy_option($key="",$default=false){
	$options=get_storefy_options();

	if(isset($options[$key]))
		return $options[$key];
	return $default? $default : false;
}

function get_storefy_career_field($fields=array()){

	$config=get_storefy_options();

	if(!isset($config['career_fields']) || !is_array($config['career_fields']))
		return $fields;

	$new_fields=array();

	foreach ($config['career_fields'] as $k=>$field) {

		if(empty($field['label']))
			continue;

		 $metaname=sanitize_key($field['label']);
		 $new_fields[$metaname]=$field;


	}
	return $new_fields;
}

add_filter('dtcareer_job_fields','get_storefy_career_field');
?>
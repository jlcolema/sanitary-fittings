<?php
defined('ABSPATH') or die();
/**
 * left topbar menu
 *
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */

$menu=get_storefy_option('dt-left-top-bar-menu');

if(!empty($menu)):

      $menuParams=array(
                  'menu'=>$menu,
                  'echo' => false,
                  'container_id'=>'dt-topbar-menu-left',
                  'menu_class'=>'topbar-menu',
                  'container'=>'div',
                  'before' => '',
                  'after' => '',
                  'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                  'fallback_cb'=>false,
                  'theme_location'=>'left-menu',
                  'walker'  => new storefy_topbarmenu_walker()
                  );

      $menu=wp_nav_menu($menuParams);

      if ($menu) {
?>
      <div class="left-menu">
            <?php print $menu;?>
      </div>
<?php }?>
<?php endif;?>

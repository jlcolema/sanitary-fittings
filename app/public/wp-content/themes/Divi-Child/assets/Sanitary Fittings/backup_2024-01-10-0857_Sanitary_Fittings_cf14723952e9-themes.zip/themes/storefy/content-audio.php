<?php
defined('ABSPATH') or die();
/**
 * The default template for displaying content audio post format
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */
?>

<?php 
	$imageurl = "";
	$sharepos = 'sharepos';

	/* Get Image from featured image */
	$thumb_id = get_post_thumbnail_id($post->ID);
	$featured_image = wp_get_attachment_image_src($thumb_id,'full',false); 
	if (isset($featured_image[0])) {
		$imageurl = $featured_image[0];
	}

	$alt_image = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);

?>

<?php if (is_single()) : 


	$content=get_the_content(' ');
	//Find video shotcode in content
	$pattern = get_shortcode_regex();

	$hasaudioshortcode = false;

	$content=preg_replace_callback('/'. $pattern .'/s',
		function($matches){

			global $storefy_audioshortcode;
			static $id = 0;
			$id++;

			if($matches[2]=='audio') {

				if($id==1){
					$storefy_audioshortcode=$matches[0];
				}

			}
			return $matches[0];

		}
	,$content,-1,$matches_count);

	$content = apply_filters( 'the_content', do_shortcode($content));
	$content = str_replace( ']]>', ']]&gt;', $content );

	$hasaudioshortcode = storefy_get_global_var('storefy_audioshortcode');
?>

				<div class="row">
					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

						<div class="col-xs-12">

						<?php   if ($hasaudioshortcode) { ?>											
							<div class="postimage">
							<?php if ($imageurl!="") { ?>
								<img class="img-responsive blog_image" alt="<?php echo esc_attr($alt_image); ?>" src="<?php echo esc_url($imageurl); ?>">
							<?php } else { ?>
								<div class="postaudio tertier_color_bg">
									<i class="icon-note-beamed"></i>
								</div>
							<?php } ?>
		                		<?php
		                			//Display video 
		               				echo do_shortcode($hasaudioshortcode);
		                		?>
							</div>
						<?php		$sharepos = '';
								}  ?>							

							<div class="postcontent">
								<?php get_template_part('pagetemplates/postinfo'); ?>
						
								<h2 class="blog-post-title"><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_title();?></a></h2>

								<?php get_template_part('pagetemplates/postinfotag'); ?>

		                		<?php print $content;

									wp_link_pages( storefy_get_link_pages_args() );
		                		?>

								<?php get_template_part('pagetemplates/postmetabottom_detail'); ?>
							</div>

							<?php get_template_part('pagetemplates/postaboutcomment'); ?>
						</div>

					</article>
				</div><!--div class="row"-->


<?php else : 
	$content=get_the_content(' ');
	//Find video shotcode in content
	$pattern = get_shortcode_regex();

	$hasaudioshortcode = false;

	$content=preg_replace_callback('/'. $pattern .'/s',
		function($matches){

			global $storefy_audioshortcode;
			static $id = 0;
			$id++;

			if($matches[2]=='audio') {

				if($id==1){
					$storefy_audioshortcode=$matches[0];
				}

			}
			else{
				return $matches[0];
			}
			return " ";

		}
	,$content,-1,$matches_count);

	$content = apply_filters( 'the_content', storefy_remove_shortcode_from_content($content));
	$content = str_replace( ']]>', ']]&gt;', $content );
	
	$hasaudioshortcode = storefy_get_global_var('storefy_audioshortcode');

	?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<div class="row">
				<div class="col-xs-12">
					<?php get_template_part('pagetemplates/postinfo'); ?>
					<h2 class="blog-post-title"><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_title();?></a></h2>
					<?php get_template_part('pagetemplates/postinfotag'); ?>
				</div>
			</div>
<?php    if ($hasaudioshortcode) { ?>											
			<div class="row">
				<div class="col-xs-12">
					<div class="postimage">
					<?php if ($imageurl!="") { ?>
						<img class="img-responsive blog_image" alt="<?php echo esc_attr($alt_image); ?>" src="<?php echo esc_url($imageurl); ?>">
					<?php } ?>
                		<?php
                			//Display audio 
               				echo do_shortcode($hasaudioshortcode);
                		?>
					</div>
				</div>
			</div>
<?php
		} 
?>											

			<div class="row">
				<div class="col-xs-12">			
					<div class="postcontent">
						<?php 
							print get_the_excerpt();
						?>
					</div>
					<?php get_template_part('pagetemplates/postmetabottom'); ?>

				</div>
			</div> 
			</article>

<?php endif; ?>
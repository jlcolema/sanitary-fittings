jQuery(document).ready(function($){
	$('.toggle-mob-menu').click(function(e){
		e.preventDefault();
		$(this).toggleClass('on');
		$('body').toggleClass('menu-on');
		$('#mob-menu').slideToggle();
	});
	$('#pgc-w5e452fae82f12-0-2 h3, #pgc-w5e452fae82f12-0-1 h3, #pgc-w5e452fae82f12-0-0 h3, #pgc-w5e455af4d3fa0-0-0 h3, #pgc-w5e455af4d3fa0-0-1 h3, #pgc-w5e455af4d3fa0-0-2 h3, footer .widget h5.widget-title').click(function(){
		$(this).parent().find('> div').slideToggle();
		$(this).toggleClass('on');
	});
	/* $('#mob-menu a:after').click(function(){
		$(this).closest('li').addClass('open');
	});
	$('#mob-menu .expand-menu').click(function(){
		$(this).closest('li').removeClass('open');
	}); */
	$( ".variations_form" ).on( "woocommerce_variation_select_change", function () {
	    var price = $('.woocommerce-variation-price').html();
	    $('.vi-woo-product-price').html(price);
	});
	$( ".single_variation_wrap" ).on( "show_variation", function ( event, variation ) {
	    var price = $('.woocommerce-variation-price').html();
	    $('.vi-woo-product-price').html(price);
	});
	$('.woocommerce-tabs.wc-tabs-wrapper > div').show();
	$('.accordian-title').click(function(){
		var elem = $(this).parent().find('.accordian-content');
		if(! elem.hasClass('on') ){
			//$('.accordian-title').removeClass('on');
			$(this).addClass('on');
			///$('.accordian-content').slideUp();
			//$('.accordian-content').removeClass('on');
			elem.addClass('on');
			elem.slideDown();
		}
		else{
			$(this).removeClass('on');
			elem.removeClass('on');
			elem.slideUp();
		}
	});
	$('.woocommerce div.product .woocommerce-tabs .panel:first-child').find('.accordian-title, .accordian-content').addClass('on');
	$('.woocommerce-cart-notice > a').removeClass('button');
	var expf = $('#additional_expedite_field').detach();
	expf.insertAfter('#ship-to-different-address');

	$('.woocommerce-product-gallery__image > a').attr('data-lightbox', 'woo-image');

	$('#menu-main-navigation > li.menu-item-has-children > a').click(function(e){
		e.preventDefault();
		if($(this).parent('li').hasClass('open-it'))
			$('#menu-main-navigation > li.menu-item-has-children').removeClass('open-it');
			//$(this).parent('li').removeClass('open-it');
		else{
			$('#menu-main-navigation > li.menu-item-has-children').removeClass('open-it');
			$(this).parent('li').addClass('open-it');
		}
	});
	
});
jQuery(window).on('load', function(){
	jQuery('#billing_address_2').attr('placeholder', 'Apartment, suite, unit, etc. (opt.)');
	jQuery('#shipping_address_2').attr('placeholder', 'Apartment, suite, unit, etc. (opt.)');
});
jQuery(window).on('load resize', function(){
	var maxW = jQuery(window).width();
	if(maxW < 481){
		if(jQuery('.banner-products').length){
			jQuery('.banner-products').slick({
				dots: true,
				infinite: false,
				prevArrow: "<div class='slick-prev'><i class='simple-line-icon-arrow-left-circle'></i></div>",
	            nextArrow: "<div class='slick-next'><i class='simple-line-icon-arrow-right-circle'></i></div>",
			});
		}
	}
	if(maxW < 768){
		jQuery('.woocommerce-Tabs-panel .accordian-title').removeClass('on');
		jQuery('.woocommerce-Tabs-panel .accordian-content').removeClass('on');
		jQuery('.product-content-container table').addClass('table-responsive');
	}
	var maxH = 0;
	jQuery('.equal-height > div').height('auto');
	jQuery('.equal-height > div').each(function(){
		console.log(jQuery(this).height());
		if(jQuery(this).height() > maxH) maxH = jQuery(this).height();
	});
	jQuery('.equal-height > div').height(maxH);
});


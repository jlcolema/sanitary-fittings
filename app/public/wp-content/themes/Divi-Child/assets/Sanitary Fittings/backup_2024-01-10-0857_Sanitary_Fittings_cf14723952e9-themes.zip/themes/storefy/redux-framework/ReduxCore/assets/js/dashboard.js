jQuery(document).ready(function($){
	'use strict';

  var 
  $select = $('select#dt-left-top-bar-select'),
  $menusource = $('#storefy_config-dt-left-top-bar-menu').closest('.form-table tr'),
  $textsource = $('#storefy_config-dt-left-top-bar-text').closest('.form-table tr'),
  $devider1 = $('#storefy_config-devider-1').closest('.form-table tr'),
  $devider2 = $('#storefy_config-devider-2').closest('.form-table tr'),
  $rselect = $('select#dt-right-top-bar-select'),
  $rmenusource = $('#storefy_config-dt-right-top-bar-menu').closest('.form-table tr'),
  $rtextsource = $('#storefy_config-dt-right-top-bar-text').closest('.form-table tr'),
  $showtopbar=$('#storefy_config-showtopbar .cb-enable,#storefy_config-showtopbar .cb-disable'),
  $backgroundImage = $('#storefy_config-dt-banner-image').closest('.form-table tr'),
  $backgroundVideo = $('#storefy_config-dt-banner-video').closest('.form-table tr'),
  $backgroundColor = $('#storefy_config-banner-color').closest('.form-table tr'),
  $background=$('select#dt-show-banner-page-select'),
  $scrollsidebgcolor = $('#storefy_config-dt_scrollingsidebar_bg_color').closest('.form-table tr'),
  $pagebackground=$('#storefy_config-header-background-type .cb-enable,#storefy_config-header-background-type .cb-disable'),
  $pagebackgroundColor = $('#storefy_config-header-color').closest('.form-table tr'),
  $shopbackgroundColor = $('#storefy_config-dt-shop-banner-image').closest('.form-table tr'),
  $showfooterwidget=$('#storefy_config-showfooterwidget .cb-enable,#storefy_config-showfooterwidget .cb-disable'),
  $footerwidget=$('#storefy_config-dt-footer-widget-column').closest('.form-table tr'),
  $showfooterpage=$('#storefy_config-showfooterpage .cb-enable,#storefy_config-showfooterpage .cb-disable'),
  $footerpage=$('#storefy_config-footerpage').closest('.form-table tr'),
  $footertext=$('#storefy_config-footer-text').closest('.form-table tr'),
  $footertextposition=$('#storefy_config-dt-footer-position').closest('.form-table tr'),
  $footerwidget=$('#storefy_config-dt-footer-widget-column').closest('.form-table tr'),
  $showfooterwidgetcountainer=$('#storefy_config-showfooterwidget').closest('.form-table tr'),
  $footercolor=$('#storefy_config-footer-color').closest('.form-table tr'),
  $footerfontcolor=$('#storefy_config-footer-font-color').closest('.form-table tr'),
  $showfooterarea=$('#storefy_config-showfooterarea .cb-enable,#storefy_config-showfooterarea .cb-disable'),
  $postfooterpage=$('#storefy_config-postfooterpage').closest('.form-table tr');

  var $page_loader =$('#storefy_config-page_loader .cb-enable,#storefy_config-page_loader .cb-disable'),
  $page_loader_background=$('#storefy_config-page_loader_background').closest('.form-table tr'),
  $page_loader_ball_1=$('#storefy_config-page_loader_ball_1').closest('.form-table tr'),
  $page_loader_ball_2=$('#storefy_config-page_loader_ball_2').closest('.form-table tr'),
  $page_loader_ball_3=$('#storefy_config-page_loader_ball_3').closest('.form-table tr'),
  $page_loader_ball_4=$('#storefy_config-page_loader_ball_4').closest('.form-table tr');

  var $scrollingsidebar =$('#storefy_config-dt_scrollingsidebar_on .cb-enable,#storefy_config-dt_scrollingsidebar_on .cb-disable'),
  $scrollsidebgtype = $('#storefy_config-dt_scrollingsidebar_bg_type .cb-enable,#storefy_config-dt_scrollingsidebar_bg_type .cb-disable'),
  $scrollingsidebar_bg_type=$('#storefy_config-dt_scrollingsidebar_bg_type').closest('.form-table tr'),
  $scrollingsidebar_bg_color=$('#storefy_config-dt_scrollingsidebar_bg_color').closest('.form-table tr'),
  $scrollingsidebar_top_margin=$('#storefy_config-dt_scrollingsidebar_top_margin').closest('.form-table tr'),
  $scrollingsidebar_position=$('#storefy_config-dt_scrollingsidebar_position').closest('.form-table tr'),
  $scrollingsidebar_margin=$('#storefy_config-dt_scrollingsidebar_margin').closest('.form-table tr');

  var $boxed_layout = $('[name="storefy_config[boxed_layout_activate]"]'),
  $boxed_layout_boxed_background_image=$('#storefy_config-boxed_layout_boxed_background_image').closest('.form-table tr'),
  $boxed_layout_boxed_background_color=$('#storefy_config-boxed_layout_boxed_background_color').closest('.form-table tr'),
  $boxed_layout_stretched=$('#storefy_config-boxed_layout_stretched').closest('.form-table tr');

  var $dtshowheader =$('#storefy_config-dt-show-header .cb-enable,#storefy_config-dt-show-header .cb-disable'),
  $dtshowheader_child=$('#storefy_config-dt-show-header').closest('.form-table tr');

  var 
  $bgmenuimage=$('#storefy_config-dt-menu-image').closest('.form-table tr'),
  $bgmenuimagehorizontal=$('#storefy_config-dt-menu-image-horizontal').closest('.form-table tr'),
  $bgmenuimagesize=$('#storefy_config-dt-menu-image-size').closest('.form-table tr'),
  $bgmenuimagevertical=$('#storefy_config-dt-menu-image-vertical').closest('.form-table tr'),
  $stickylogo=$('#storefy_config-dt-logo-image-transparent').closest('.form-table tr'),
  $stickylogomargin=$('#storefy_config-dt-logo-top-margin-reveal').closest('.form-table tr'),
  $logotoppadding=$('#storefy_config-dt-logo-top-padding').closest('.form-table tr');

  var $pagebackgroundsticky=$('#storefy_config-header-background-transparent-active .cb-enable,#storefy_config-header-background-transparent-active .cb-disable'),
  $pagebackgroundstickyColor = $('#storefy_config-header-color-transparent').closest('.form-table tr'),
  $pagebackgroundstickyrow = $('#storefy_config-header-background-transparent-active').closest('.form-table tr');


  /* sticky menu */
  var $stickymenu =$('#storefy_config-dt-sticky-menu .cb-enable,#storefy_config-dt-sticky-menu .cb-disable'),
  $headercolorsticky=$('#storefy_config-header-color-sticky').closest('.form-table tr'),
  $headerfontcolorsticky=$('#storefy_config-header-font-color-sticky').closest('.form-table tr');


    $stickymenu.live('click',function(e){
    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){

        $stickylogo.fadeIn('fast');
        $stickylogomargin.fadeIn('fast');
        $headercolorsticky.fadeIn('fast');
        $headerfontcolorsticky.fadeIn('fast');
        $pagebackgroundstickyrow.fadeIn('fast');
        $pagebackgroundsticky.trigger('change');
      }

    }else{
      if($(this).hasClass('selected')){
        $stickylogo.fadeOut('fast');
        $stickylogomargin.fadeOut('fast');
        $headercolorsticky.fadeOut('fast');
        $headerfontcolorsticky.fadeOut('fast');
        $pagebackgroundstickyrow.fadeOut('fast');
        $pagebackgroundstickyColor.fadeOut('fast');
      }
    }

  }).live('change',function(e){

    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){

       $stickylogo.fadeIn('fast');
       $stickylogomargin.fadeIn('fast');
       $headercolorsticky.fadeIn('fast');
       $headerfontcolorsticky.fadeIn('fast');
       $pagebackgroundstickyrow.fadeIn('fast');
       $pagebackgroundsticky.trigger('change');
      }
    }else{


      if($(this).hasClass('selected')){
        $stickylogo.fadeOut('fast');
        $stickylogomargin.fadeOut('fast');
        $headercolorsticky.fadeOut('fast');
        $headerfontcolorsticky.fadeOut('fast');
        $pagebackgroundstickyrow.fadeOut('fast');
        $pagebackgroundstickyColor.fadeOut('fast');
      }
    }

  });

  $background.live('change',function(){

    var background = $(this).val();
    switch ( background ) {
      case 'image':
        $backgroundImage.fadeIn('slow');
        $backgroundColor.fadeOut('slow');
        $backgroundVideo.fadeOut('slow');
        break;
      case 'color':
        $backgroundColor.fadeIn('fast');
        $backgroundImage.fadeOut('slow');
        $backgroundVideo.fadeOut('slow');
        break;
      case 'video':
        $backgroundVideo.fadeIn('fast');
        $backgroundColor.fadeOut('slow');
        $backgroundImage.fadeOut('slow');
        break;
      default:
        $backgroundColor.fadeOut('slow');
        $backgroundImage.fadeOut('slow');
        $backgroundVideo.fadeOut('slow');
      }

  });

  /* Background Color */
/*  $pagebackground.live('click',function(e){

    e.preventDefault();

    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $pagebackgroundColor.fadeIn('fast');
      }

    }else{
      if($(this).hasClass('selected')){
        $pagebackgroundColor.fadeOut('fast');
      }
    }
  }).
  live('change',function(e){
    e.preventDefault();

    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $pagebackgroundColor.fadeIn('fast');
      }

    }else{
      if($(this).hasClass('selected')){
        $pagebackgroundColor.fadeOut('fast');
      }
    }
  });

  $pagebackgroundsticky.live('click',function(e){

    e.preventDefault();

    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $pagebackgroundstickyColor.fadeIn('fast');
      }

    }else{
      if($(this).hasClass('selected')){
        $pagebackgroundstickyColor.fadeOut('fast');
      }
    }
  }).
  live('change',function(e){
    e.preventDefault();

    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $pagebackgroundstickyColor.fadeIn('fast');
      }

    }else{
      if($(this).hasClass('selected')){
        $pagebackgroundstickyColor.fadeOut('fast');
      }
    }
  });


  $scrollsidebgtype.live('click',function(e){

    e.preventDefault();

    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $scrollingsidebar_bg_color.fadeIn('fast');
      }

    }else{
      if($(this).hasClass('selected')){
        $scrollingsidebar_bg_color.fadeOut('fast');
      }
    }
  }).
  live('change',function(e){
    e.preventDefault();

    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $scrollingsidebar_bg_color.fadeIn('fast');
      }

    }else{
      if($(this).hasClass('selected')){
        $scrollingsidebar_bg_color.fadeOut('fast');
      }
    }
  });

 $showfooterwidget.live('click',function(e){


    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
          $footerwidget.fadeIn('fast');
      }

    }else{
      if($(this).hasClass('selected')){

          $footerwidget.fadeOut('fast');
      }
    }

  }).live('change',function(e){
    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
          $footerwidget.fadeIn('fast');
      }
    }else{
      if($(this).hasClass('selected')){

          $footerwidget.fadeOut('fast');
      }
    }

  });

  $showfooterpage.live('click',function(e){

    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
          $footerpage.fadeIn('fast');$postfooterpage.fadeIn('fast');
      }

    }else{
      if($(this).hasClass('selected')){

          $footerpage.fadeOut('fast');$postfooterpage.fadeOut('fast');
      }
    }

  }).live('change',function(e){
    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
          $footerpage.fadeIn('fast');$postfooterpage.fadeIn('fast');
      }
    }else{
      if($(this).hasClass('selected')){

          $footerpage.fadeOut('fast');$postfooterpage.fadeOut('fast');
      }
    }

  });

 $showfooterarea.live('click',function(e){
    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $footertext.fadeIn('fast');
        $footerwidget.fadeIn('fast');
        $showfooterwidgetcountainer.fadeIn('fast');
        $footercolor.fadeIn('fast');
        $footerfontcolor.fadeIn('fast');  
        $footertextposition.fadeIn('fast');
      }

    }else{
      if($(this).hasClass('selected')){
        $footertext.fadeOut('fast');
        $footerwidget.fadeOut('fast');
        $showfooterwidgetcountainer.fadeOut('fast');
        $footercolor.fadeOut('fast');
        $footerfontcolor.fadeOut('fast');  
        $footertextposition.fadeOut('fast');
      }
    }

  }).live('change',function(e){
    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $footertext.fadeIn('fast');
        $footerwidget.fadeIn('fast');
        $showfooterwidgetcountainer.fadeIn('fast');
        $footercolor.fadeIn('fast');
        $footerfontcolor.fadeIn('fast');  
        $footertextposition.fadeIn('fast');
      }
    }else{
      if($(this).hasClass('selected')){
        $footertext.fadeOut('fast');
        $footerwidget.fadeOut('fast');
        $showfooterwidgetcountainer.fadeOut('fast');
        $footercolor.fadeOut('fast');
        $footerfontcolor.fadeOut('fast');  
        $footertextposition.fadeOut('fast');
      }
    }

  });

 $page_loader.live('click',function(e){
    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $page_loader_ball_1.fadeIn('fast');
        $page_loader_ball_2.fadeIn('fast');
        $page_loader_ball_3.fadeIn('fast');
        $page_loader_ball_4.fadeIn('fast');
        $page_loader_background.fadeIn('fast');
      }

    }else{
      if($(this).hasClass('selected')){
        $page_loader_ball_1.fadeOut('fast');
        $page_loader_ball_2.fadeOut('fast');
        $page_loader_ball_3.fadeOut('fast');
        $page_loader_ball_4.fadeOut('fast');
        $page_loader_background.fadeOut('fast');
      }
    }

  }).live('change',function(e){
    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $page_loader_ball_1.fadeIn('fast');
        $page_loader_ball_2.fadeIn('fast');
        $page_loader_ball_3.fadeIn('fast');
        $page_loader_ball_4.fadeIn('fast');
        $page_loader_background.fadeIn('fast');
      }
    }else{
      if($(this).hasClass('selected')){
        $page_loader_ball_1.fadeOut('fast');
        $page_loader_ball_2.fadeOut('fast');
        $page_loader_ball_3.fadeOut('fast');
        $page_loader_ball_4.fadeOut('fast');
        $page_loader_background.fadeOut('fast');
      }
    }

  });

   $scrollingsidebar.live('click',function(e){
    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $scrollingsidebar_bg_type.fadeIn('fast');
        $scrollingsidebar_bg_color.fadeIn('fast');
        $scrollingsidebar_top_margin.fadeIn('fast');
        $scrollingsidebar_position.fadeIn('fast');
        $scrollingsidebar_margin.fadeIn('fast');
        $scrollsidebgtype.trigger('change');
      }

    }else{
      if($(this).hasClass('selected')){
        $scrollingsidebar_bg_type.fadeOut('fast');
        $scrollingsidebar_bg_color.fadeOut('fast');
        $scrollingsidebar_top_margin.fadeOut('fast');
        $scrollingsidebar_position.fadeOut('fast');
        $scrollingsidebar_margin.fadeOut('fast');
      }
    }

  }).live('change',function(e){
    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $scrollingsidebar_bg_type.fadeIn('fast');
        $scrollingsidebar_bg_color.fadeIn('fast');
        $scrollingsidebar_top_margin.fadeIn('fast');
        $scrollingsidebar_position.fadeIn('fast');
        $scrollingsidebar_margin.fadeIn('fast');
        $scrollsidebgtype.trigger('change');
      }
    }else{
      if($(this).hasClass('selected')){
        $scrollingsidebar_bg_type.fadeOut('fast');
        $scrollingsidebar_bg_color.fadeOut('fast');
        $scrollingsidebar_top_margin.fadeOut('fast');
        $scrollingsidebar_position.fadeOut('fast');
        $scrollingsidebar_margin.fadeOut('fast');
      }
    }

  });
*/

   $boxed_layout.live('change',function(e){
    e.preventDefault();

    var this_value = $(this).val();

    if( this_value && this_value!='0' ) {
        $boxed_layout_boxed_background_image.fadeIn('fast');
        $boxed_layout_boxed_background_color.fadeIn('fast');
        $boxed_layout_stretched.fadeIn('fast');
    }
    else{
        $boxed_layout_boxed_background_image.fadeOut('fast');
        $boxed_layout_boxed_background_color.fadeOut('fast');
        $boxed_layout_stretched.fadeOut('fast');
    }
  });

   if($boxed_layout.length){
      $boxed_layout.each(function(){

          if($(this).prop("checked")){
            $(this).trigger('change');
            return;
          }
      });
   }


/*  $dtshowheader.live('click',function(e){
    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
         $dtshowheader_child.siblings().fadeIn('fast');
         $pagebackground.trigger('change');
      }

    }else{
      if($(this).hasClass('selected')){
        $dtshowheader_child.siblings().fadeOut('fast');
      }
    }

  }).live('change',function(e){

    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){
        $dtshowheader_child.siblings().fadeIn('fast');
         $pagebackground.trigger('change');
      }
    }else{
      if($(this).hasClass('selected')){
        $dtshowheader_child.siblings().fadeOut('fast');
      }
    }

  });
*/

  $select.live('change',function(){

    var this_value = $(this).val();

    switch ( this_value ) {
      case 'text':
        $menusource.fadeOut('fast');
        $textsource.fadeIn('slow');
        break;
      case 'menu':
      case 'icon':
        $textsource.fadeOut('fast');
        $menusource.fadeIn('slow');
        break;
      default:
        $textsource.fadeOut('fast');
        $menusource.fadeOut('slow');
    }
   });

  $rselect.live('change',function(){

    var this_value = $(this).val();

    switch ( this_value ) {
      case 'text':
        $rmenusource.fadeOut('fast');
        $rtextsource.fadeIn('slow');
        break;
      case 'menu':
      case 'icon':
        $rtextsource.fadeOut('fast');
        $rmenusource.fadeIn('slow');
        break;
      default:
        $rtextsource.fadeOut('fast');
        $rmenusource.fadeOut('slow');
    }


   });


  $showtopbar.live('click',function(e){

    var $showtopbar_child=$('#storefy_config-showtopbar').closest('.form-table tr');

    e.preventDefault();
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){

        $showtopbar_child.siblings().fadeIn('fast');
        $select.trigger('change');
        $rselect.trigger('change');

      }

    }else{
      if($(this).hasClass('selected')){

        $showtopbar_child.siblings().fadeOut('fast');
        $devider1.fadeOut('fast');
        $devider2.fadeOut('fast');
      }
    }

  }).live('change',function(e){

    e.preventDefault();

    var $showtopbar_child=$('#storefy_config-showtopbar').closest('.form-table tr');
    if($(this).hasClass('cb-enable')){
      if($(this).hasClass('selected')){

        $showtopbar_child.siblings().fadeIn('fast');
        $select.trigger('change');
        $rselect.trigger('change');

      }
    }else{
      if($(this).hasClass('selected')){

        $showtopbar_child.siblings().fadeOut('fast');
        $devider1.fadeOut('fast');
        $devider2.fadeOut('fast');
      }
    }

  });

   $showtopbar.trigger('change');

  /* blog type */
/*  var $blog_type =$('select#blog_type-select'),
  $masonry_column=$('#storefy_config-masonry_column').closest('.form-table tr'),
  $masonry_column_tablet=$('#storefy_config-masonry_column_tablet').closest('.form-table tr'),
  $masonry_column_mobile=$('#storefy_config-masonry_column_mobile').closest('.form-table tr');

  $blog_type.live('change',function(){

    var blog_type = $(this).val();

    if(blog_type=='masonry'){
      $masonry_column.fadeIn('fast');
      $masonry_column_tablet.fadeIn('fast');
      $masonry_column_mobile.fadeIn('fast');

    }
    else{
      $masonry_column.fadeOut('fast');
      $masonry_column_tablet.fadeOut('fast');
      $masonry_column_mobile.fadeOut('fast');

    }
  });

/*
  $blog_type.trigger('change');


   $dtshowheader.trigger('change');
   $stickymenu.trigger('change');
   $page_loader.trigger('change');
   $showfooterwidget.trigger('change');
   $scrollingsidebar.trigger('change');
   $showfooterpage.trigger('change');
   $showfooterarea.trigger('change');

*/
 });

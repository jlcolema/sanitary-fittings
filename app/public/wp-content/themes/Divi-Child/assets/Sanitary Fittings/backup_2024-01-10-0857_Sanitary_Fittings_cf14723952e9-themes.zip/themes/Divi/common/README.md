# Common

- Anything here should be pure and not rely on anything from VB, TB, Core, so it can be reused wherever, even outside Divi.
- Only external dependencies allowed.

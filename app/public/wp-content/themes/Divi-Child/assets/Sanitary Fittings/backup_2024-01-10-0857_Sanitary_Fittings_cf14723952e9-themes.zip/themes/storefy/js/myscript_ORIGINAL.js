var $ = jQuery.noConflict();
(function( window, $, undefined ){

  'use strict';

  var $event = $.event,
      dispatchMethod = $.event.handle ? 'handle' : 'dispatch',
      resizeTimeout;

  $event.special.smartresize = {
    setup: function() {
      $(this).bind( "resize", $event.special.smartresize.handler );
    },
    teardown: function() {
      $(this).unbind( "resize", $event.special.smartresize.handler );
    },
    handler: function( event, execAsap ) {
      // Save the context
      var context = this,
          args = arguments;

      // set correct event type
      event.type = "smartresize";


      if ( resizeTimeout ) { clearTimeout( resizeTimeout ); }
      resizeTimeout = setTimeout(function() {
        $event[ dispatchMethod ].apply( context, args );
      }, execAsap === "execAsap"? 0 : 100 );
    }
  };

  $.fn.smartresize = function( fn ) {
    return fn ? this.bind( "smartresize", fn ) : this.trigger( "smartresize", ["execAsap"] );
  };

})( window, jQuery );




jQuery(document).ready(function($){

  "use strict";

//  setbodyclass();

/* --- Parallax Background Function--- */

    var dtParallax=function() {

        "use strict";
        var $window = $(window);
        var minwidthparallax = 768;

        $('body[data-type="background"],section[data-type="background"],div[data-type="background"]').each(function(){

            var $bgobj = $(this); // assigning the object
            $window.scroll(function() {

               if ($(this).width()>minwidthparallax) {
                    var position=$bgobj.position();
                    var yPos = (($(document).scrollTop() - position.top) / $bgobj.data('speed'));
                    // Put together our final background position
                    var coords = '50% '+ yPos + 'px';
       
                   // Move the background
                    $bgobj.css({ backgroundPosition: coords });
                }
            }); 
        });    


    }

    dtParallax();

    //dtCounter();

    var setFooterWidget=function(){


        if ($('#footer-right .border-left').length) {

            var $item=$('#footer-right .border-left:first');
            var $col=$item.hasClass('col-2')?2:$item.hasClass('col-3')?3:$item.hasClass('col-4')?4:1;
            var rowHeight=$item.outerHeight(true);

            $('.border-left').matchHeight();
        }

    };

    
    if($('#menusearchform').length){
      var windowWidth = $(window).width();

     $( ".search_btn" ).click(function() {
        if (windowWidth>991) {
          $(this).parents('form').find(".popup_form").fadeToggle( "fast", "swing" );
          return false;
        }
      });


    $('body').click(function(e){
      if (windowWidth>991) {
        var $searchform=$('.popup_form');
        if(! ($searchform.has(e.target).length || $(e.target).is('.popup_form input'))){
          $searchform.fadeOut('fast','swing');
        }
      }
    });

    }

    if ($('.social-share-link').length) {
        $('.social-share-link').each(function () {
            $(this).click(function (event) {
                event.preventDefault();
                var idtobedisplay = $(this).siblings('.list-social-icons').attr('id');

                $('.list-social-icons').each(function () {
                  if (idtobedisplay!=$(this).attr('id')) {
                    $(this).fadeOut();
                  }
                });

                $(this).siblings('.list-social-icons').toggle(200);
            });
        });
    }

    function dtCounto() {
        if ($('.dt-counto').length) {
            $('.dt-counto').each(function () {
              $(this).appear(function () {
                var $to = $(this).data('to'),$oldvalue=$(this).text(),$from = $(this).data('from');

                if($oldvalue){
                  $to =parseFloat($oldvalue);
                }

                $(this).countTo({
                    from: $from,
                    to: $to,
                    speed: 1500,
                    refreshInterval: 50,
                    onUpdate:function(value){
                      $(this).text(value.toFixed(0));
                    }
                });

              }, {
                  accX: 0,
                  accY: -200
              })

            });

        }
    }

    dtCounto();


    /*
     * add to cart quantity  updated_wc_div
     */

     function storefy_quantity_btn_init(){

      if($('.cart .quantity input[type=number]').length){

        $('.cart .quantity input[type=number]').each(function(){
          var inputbtn=$(this),container=inputbtn.closest('.quantity'),step=inputbtn.data('step') ? parseInt(inputbtn.data('step')) : 1,
          min_val=inputbtn.data('min') ? parseInt(inputbtn.data('min')) : 1,max_val=inputbtn.data('max') ? parseInt(inputbtn.data('max')) : 100;
          var decrease_btn=container.find('.quantity-decrease'),increase_btn=container.find('.quantity-increase');

          decrease_btn.click(function(e){
            e.preventDefault();
            var curval=parseInt(inputbtn.val());

            if((curval - step) < min_val ){
              inputbtn.val(min_val);
            }
            else{
              inputbtn.val(curval - step );
            }

            inputbtn.trigger('change');

          });

          increase_btn.click(function(e){
            e.preventDefault();
            var curval=parseInt(inputbtn.val());
            if((curval + step) > max_val ){
              inputbtn.val(max_val);
            }
            else{
              inputbtn.val(curval + step );
            }

            inputbtn.trigger('change');
            
          });

        });

      }
    }

    storefy_quantity_btn_init();

    $( document.body ).on( 'updated_wc_div',function(){
      storefy_quantity_btn_init();
    });

    /*
     * shop show number
     */
    if($('.woocommerce-ordering [name="product_per_page"]').length){
      $('.woocommerce-ordering [name="product_per_page"]').each(function(){
        $(this).change(function(e){
          return $(this).closest('form').submit();
        });
      });
    }

    /*
     * Shop layered_nav filter
     */

     if($('.woocommerce .widget_layered_nav ul').length){
        $('.woocommerce .widget_layered_nav ul').each(function(){

          var $filter_content=$(this),$container=$filter_content.closest('.widget_layered_nav');
          var $search_field=$('<input class="search-layered" placeholder="'+storefy_i18nLocale.search_filter+'"/>');
          var $options=$('.wc-layered-nav-term', $filter_content);

          $filter_content.before($search_field);
          $search_field.wrap('<div class="search-layered-container"></div>');

          $search_field.on('keyup',function(e){

            var $value=$(this).val();
            if($value.length < 3) {
              
              $options.show();
              return;
            }

            showList(escapeRegExp($value),$options);
          });

        });

        function escapeRegExp(string){
          return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
        }

        function showList(searchvalue,reff){

            reff.each(function(i, el){

              var str= $(el).text().toString().toLowerCase();
              var pattern= searchvalue.toString().toLowerCase();

                if(str.match(pattern)){
                  $(reff.get( i )).show();
                } 
                else{
                    $(reff.get( i )).hide();
                }

            });
        }
     }

    // product thumbnails

    if($('.product-image-container .thumbnails img').length){

      var mainImage = $('.woocommerce-main-image');
      $('.product-image-container .thumbnails > a').each(function(){
          var thumb= $(this);

          thumb.on('click',function(e){
            e.preventDefault();

            $(this).closest('.thumbnails').find('a').removeClass('current');
            $(this).addClass('current');
            var img= $('img', $(this)), img_url= img.attr('url');

            if(img_url && img_url !=''){

              mainImage.attr('url',img_url);
              mainImage.find('img').attr('src',img_url);
              mainImage.find('img').attr('srcset','');
            }

          });

      });


    } 

    // prepare mobile menu
    //leftbar-menu

    if($('.left-navigation-menu .main-menu').length){

      var shop_menu= $('.left-navigation-menu .main-menu'),shop_menu_child= shop_menu.clone(),
          mega_min_height= shop_menu.outerHeight();
      shop_menu.find('.dt-megamenu .sub-menu').css('min-height',mega_min_height);

      var shop_menu_mobile= $('<li class="menu-item menu-item-has-children hidden-dekstop">');
        shop_menu_mobile.append($('<a href="javascript:;"><span>'+storefy_i18nLocale.shop_legend_text+'</span></a>'));

        shop_menu_child.find('.sub-menu-container').addClass('indent-right');

        shop_menu_child.removeClass('main-menu').addClass('sub-menu');
        shop_menu_child.appendTo(shop_menu_mobile);
        shop_menu_child.wrap('<div class="sub-menu-container"></div>');

        shop_menu_mobile.prependTo($('.main-menu-wrapper .main-menu'));
    }

    //topbar-menu

    if($('.topbar-menu').length){

      var other_menu_mobile= $('<li class="menu-item menu-item-has-children hidden-dekstop">'),
        other_menu_child= $('<div class="sub-menu-container"></div>');

        $('.topbar-menu').each(function(e){
          var other_menu = $(this).clone();
          other_menu.find('.sub-menu-container').addClass('indent-right');

          other_menu_child.append(other_menu.children());


        });

        other_menu_mobile.append($('<a href="javascript:;"><span>'+storefy_i18nLocale.other_label_menu+'</span></a>'));
        other_menu_child.appendTo(other_menu_mobile);
        other_menu_mobile.appendTo($('.main-menu-wrapper .main-menu'));

    }
  

    /*
     * left menu height 
     */

    if($('.left-navigation-menu .toggle-menu')){
      var bar_menu_height= $('.main-navigation-container').outerHeight();
      var bar_toggle = $('.left-navigation-menu .toggle-menu');
      bar_toggle.css('min-height',bar_menu_height);

      bar_toggle.on('click',function(e){
        e.preventDefault();
        $('.left-navigation-menu .main-menu').toggleClass('show');

        if($('.left-navigation-menu .main-menu').hasClass('show')){
          $('.left-navigation-menu .toggle-menu').addClass('opened');
        }else{
          $('.left-navigation-menu .toggle-menu').removeClass('opened');
        }
      });

    }

    /* 
     * main menu 
     */
   
   $(window).resize(function(){
      if($(window).width() <= 768){
        $('body').addClass('mobile');
      }
      else{
        $('body').removeClass('mobile');
      }

      if($('body').hasClass('menu-sticky')){
        storefyStickyMenu();
      }

   });
    
   function storefyStickyMenu(){
        var menuYpositon = $('.top-head').offset().top;
        var menuOffset = $('body').hasClass('admin-bar') && $('#wpadminbar').css('position') =='fixed' ? $('#wpadminbar').outerHeight() : 0;

        $(window).scroll(function(){

          if(($(window).scrollTop() + menuOffset  ) > menuYpositon ){
            $('.top-head').addClass('sticky').css('top',menuOffset);
            $('.left-navigation-menu .main-menu').addClass('hide');
          }
          else{
            $('.top-head').removeClass('sticky');
            $('.left-navigation-menu .main-menu').removeClass('hide');
          }

        });
   }
   

  if($('.toggle-main-menu,.toggle-mobile-menu').length){
    $('.toggle-main-menu,.toggle-mobile-menu').unbind('click').click(function(e){
      e.preventDefault();
      var $toggle= $(this),$target= $('.main-menu-wrapper');

      if($target.hasClass('opened')){
        $target.removeClass('opened');
      }
      else{
        $target.addClass('opened');
        $toggle.removeClass('opened');
      }

      $('body').click(function(event){
            if ($('.main-menu-wrapper').hasClass('opened') && !$(event.target).is(".toggle-main-menu *,.main-menu-wrapper .main-menu *")){
              $target.removeClass('opened');
            }
      });

    });
  }

    if($('.menu-item.menu-item-has-children,.page_item.page_item_has_children').length){
        $('.menu-item.menu-item-has-children,.page_item.page_item_has_children').each(function(i, e){
          var $menu_item = $(this), $child = $menu_item.find('> .sub-menu-container');
          var $back_btn= $child.find('> .expand-menu');
          if($back_btn.length < 1){
            $back_btn=$('<label class="expand-menu" title="'+storefy_i18nLocale.back_label_menu+'">'+storefy_i18nLocale.back_label_menu+'</label>');
            $child.prepend($back_btn);
          }

          $back_btn.unbind('click').click(function(e){
            e.preventDefault();

            var menu= $(this).closest('.menu-item-has-children,.page_item_has_children');
            menu.removeClass('open');
            menu.data('closed',true);

          });

          $menu_item.click(function(e){

            if(!$('body').hasClass('mobile')) return;

            if(e.clientX < 200 ) return;

            e.preventDefault();

            if(! $(this).data('closed')){
              $(this).addClass('open');
            }
            else{
              $(this).data('closed', false);
            }

          });
        });

     }


    // Equal Heights
      try{

         $('.dt-iconboxes.layout-6').matchHeight();
         $('.dt-iconboxes-4.layout-4').matchHeight(); 
         $('.equal-height:not(.skip-equal),.same-height:not(.skip-equal)').matchHeight();
         $('.dt-partner .partner-item').matchHeight();
         $('.woocommerce .products > li:not(.skip-equal),.woocommerce-page .products > li:not(.skip-equal)').matchHeight();

         setTimeout(function(){
          $('[data-equal-with]').each(function() {
                var item = $(this),selector = item.attr('data-equal-with') || item.data('equal-with');
                 if(selector!=''){
                  var maxHeight = $(selector).innerHeight();
                  item.outerHeight(maxHeight);

                  console.log('maxHeight:'+maxHeight);
                 }
           });},1000);

      }
      catch(err){}

        if($('.wooscarcity-loop-products').length){

        var loop=$('.wooscarcity-loop-products');
        var loopTyping=loop.find('.loop-tool');

        loopTyping.each(function(e){

          var btn=$(this);

          btn.on('change',function(){


          });

        });

      }


    // Sticky Menu

     try{

      if ($("#head-page.sticky").length) {
        $("#head-page.adminbar-not-here").sticky({ topSpacing: 0 });
        $("#head-page.adminbar-is-here").sticky({ topSpacing: 32 });
      }

    }
    catch(err){}


    $(window).smartresize(function(){

      if($('.product-soldbar').length){

        $('.product-soldbar').each(function(){
          var stockbar= $(this), barwidth= stockbar.data('percent') ? stockbar.data('percent') : 0;
          var barcolor=$('.barcolor', stockbar);

          if(!$('.barcolor', stockbar).length){
              barcolor=$('<span class="barcolor"></span>');
              barcolor.appendTo(stockbar);
          }

          barcolor.css('width', barwidth+'%');
        });
      }

        setFooterWidget();

      // Full Screen Slider

      $('.slide-bg').css({
          marginLeft: - ($(window).width() - $('.slide-frame').outerWidth())/2,
          height: ($(window).height()),
          width : ($(window).width()) + 200
      }); 
   });


  $(".social-share-button-group li a").click(function(event) {
    if ($(this).attr('href')) {
      event.preventDefault();
      popup_social($(this).attr('href'), {url: $(this).data('url'), u: $(this).data('url')});
    }
  });
  // Cart Popup
 

  $(".cart-click").click(function() {
      if($(window).width() >480 ){
          $( ".popup_form" ).fadeOut("fast", "swing");
          $('.md-modal').removeClass('md-show');

          if ($(".dt-menu-left .cart-popup").length>0) {
            if($(window).width() >767 ){
              $(".dt-menu-left .cart-popup").css('right',$(".dt-menu-left").width()-$(".dt-menu-left .bag").position().left-60);
            } else {
              $(".dt-menu-left .cart-popup").css('right',0);
            } 
          }

          if ($(".dt-menu-center .cart-popup").length>0) {
            if($(window).width() >767 ){
              $(".dt-menu-center .cart-popup").css('right',$(".dt-menu-center").width()-$(".dt-menu-center .bag").position().left-60);
            } else {
              $(".dt-menu-center .cart-popup").css('right',0);
            } 
          }

          return false;
      }
  });


  $('body').on('added_to_cart',function(e, fragments, data){
      var item_count = (fragments['cart_content_count']) ? fragments['cart_content_count'] : 0;
      var cart_total = (fragments['cart_total']) ? fragments['cart_total'] : 0;
        $('.cart-menu .item_count').html(item_count);
      }).click(function(event){
      
        if (!$(event.target).is(".cart-popup,.cart-popup *,.popup_form, .popup_form *")) {
        }
  });

    // scroll to anchor 

     var url_test=location.hash;

     if(url_test!=''){
        lets_Scroll($(url_test));
     }


    $("a[href*='#']:not([href='#'])").unbind('click').on("click", function(e) {

        if($(this).closest('.woocommerce-tabs').length || $(this).data('toggle')=='tab' || $(this).data('toggle')=='collapse' || $(this).data('slide')=='next' || $(this).data('slide')=='prev'
          || $(this).is('.woocommerce-review-link') || $(this).is('.ui-tabs-anchor') || typeof $(this).data('vc-container')=='string' || $(this).closest('.vc_tta-tabs-list').length || $(this).closest('.wpb_accordion_section').length || $(this).closest('.nav-tabs').length){
          return;
        }
        if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {

            var target = $(this.hash);
            if(target.length){
              e.preventDefault();
              lets_Scroll(target);
            }
        }

    });


    function lets_Scroll(target){

           var scroll,navbar=$('#head-page'),offset=0;
           var ua = window.navigator.userAgent;
           var msie = ua.indexOf("MSIE ");

            var target = target.length ? target : $("[id=" + this.hash.slice(1) + "]");
            scroll = target.offset().top;

            if(navbar.length){
               offset=navbar.outerHeight(true)+parseInt($('html').css('margin-top'));
            }

            if (target.length) {

                if (typeof document.body.style.transitionProperty === 'string' && !msie) {

                    var avail = $(document).height() - $(window).height();

                    if (scroll > avail) {
                        scroll = avail;
                    }


                    $("body").css({
                        "margin-top" : ( $(window).scrollTop() - scroll + offset) + "px",
                        "transition" : "1s ease-in-out"
                    }).data("transitioning", true);

                } else {
                    $("html, body").animate({
                        scrollTop: scroll-offset
                    }, 1000);
                    return;
                }
            }

        $("body").on("transitionend webkitTransitionEnd msTransitionEnd oTransitionEnd", function (e) {
        if (e.target == e.currentTarget && $(this).data("transitioning") === true) {
            $(this).removeAttr("style").data("transitioning", false);
            $("html, body").scrollTop(scroll-offset);
             return;
          }
        });
    }


  /* navigation button */
  if($('.navigation_button_item').length){

      var navigation_column_width=100 / $('.navigation_button_item').length;

      $('.navigation_button_item').each(function(){
          $(this).click(function(e){
              e.preventDefault();

              if($(window).width() > 768) return;
              var $row_parent=$(this).closest('.navigation_button');
              $row_parent.find('.navigation_button_item').removeClass('navigation_active');
              $(this).addClass('navigation_active');

          });

      });


  }

  $( ".search_btn" ).click(function(event) {
      event.preventDefault();
      $(".search_btn").parent().removeClass('sub_open');
      $(this).parent().toggleClass('sub_open');  
    });

  /* woocommerce cart coupon */

  $( document.body ).on( 'click', 'a.showcoupon-oncart', function(e){

    e.preventDefault();
    $( '.coupon' ).slideToggle( 400, function() {
      $( '.coupon' ).find( ':input:eq(0)' ).focus();
    });
  } );


    /* responsive iframe */

  $("#storefy-search-link").click(function(event) {
    event.preventDefault();
    $(this).closest("form").submit();
  });

  $(window).resize();
  $(document).scroll();


}); //jQuery(document).ready 

function uncheckboxes(nav){
  var navarray = document.getElementsByName(nav);
  for(var i = 0; i < navarray.length; i++){
    navarray[i].checked = false
  }     
}

function popup_social(url, params) {
    var k, popup, qs, v;

    if (params == null) {
      params = {};
    }
    popup = {
      width: 500,
      height: 350
    };

    popup.top = (screen.height / 2) - (popup.height / 2);
    popup.left = (screen.width / 2) - (popup.width / 2);
    qs = ((function() {
      var _results;
      _results = [];
      for (k in params) {
        v = params[k];
        _results.push("" + k + "=" + v);
      }
      return _results;
    }).call(this)).join('&');
    if (qs) {
      qs = "?" + qs;
    }

    return window.open(url + qs, 'targetWindow', "toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,left=" + popup.left + ",top=" + popup.top + ",width=" + popup.width + ",height=" + popup.height);

};

//=================== STICKY Menu when scroll up =====================

(function($) { "use strict";
jQuery(document).ready(function($){
  //"use strict";
  //if you change this breakpoint in the style.css file, don't forget to update this value as well
  //var MQL = 1170;
  var MQL = 0;

  //primary navigation slide-in effect
  if($(window).width() > MQL) {
    var headerHeight = $('.stickyonscrollup').height();
    $(window).on('scroll',
    {
          previousTop: 0
      }, 
      function () {
        var currentTop = $(window).scrollTop();
        //check if user is scrolling up
        if (currentTop < this.previousTop ) {
          //if scrolling up...
          if (currentTop > 0 && $('.stickyonscrollup').hasClass('is-fixed')) {
            $('.stickyonscrollup').addClass('is-visible');
            $('.stickyonscrollup').parent().addClass('is-sticky');
          } else {
            $('.stickyonscrollup').removeClass('is-visible is-fixed');
            $('.stickyonscrollup').parent().removeClass('is-sticky');
          }
        } else {
          //if scrolling down...
          $('.stickyonscrollup').removeClass('is-visible');
          $('.stickyonscrollup').parent().removeClass('is-sticky');
          if( currentTop > headerHeight && !$('.stickyonscrollup').hasClass('is-fixed')) $('.stickyonscrollup').addClass('is-fixed');
        }
        this.previousTop = currentTop;
    });
  }

});
 })(jQuery); 

<?php defined('ABSPATH') or die();?>
<?php if(is_rtl()):?>
	<div class="social-share-button-group">
		<div><a href="<?php print esc_html('https://www.facebook.com/sharer/sharer.php');?>" data-url="<?php echo esc_url(get_permalink()); ?>"><span class="post-share storefy-facebook"></span></a></div>
		<div><a href="<?php print esc_html('https://twitter.com/intent/tweet');?>" data-url="<?php echo esc_url(get_permalink()); ?>"><span class="post-share storefy-twitter"></span></a></div>
		<div><a href="<?php print esc_html('https://plus.google.com/share');?>" data-url="<?php echo esc_url(get_permalink()); ?>"><span class="post-share storefy-google-plus"></span></a></div>
	</div>
	<span class="share-label"><i class="storefy-plus"></i></span>
<?php else:?>
	<span class="share-label"><i class="storefy-plus"></i></span>
	<div class="social-share-button-group">
		<div><a href="<?php print esc_html('https://www.facebook.com/sharer/sharer.php');?>" data-url="<?php echo esc_url(get_permalink()); ?>"><span class="post-share storefy-facebook"></span></a></div>
		<div><a href="<?php print esc_html('https://twitter.com/intent/tweet');?>" data-url="<?php echo esc_url(get_permalink()); ?>"><span class="post-share storefy-twitter"></span></a></div>
		<div><a href="<?php print esc_html('https://plus.google.com/share');?>" data-url="<?php echo esc_url(get_permalink()); ?>"><span class="post-share storefy-google-plus"></span></a></div>
	</div>
<?php endif;?>
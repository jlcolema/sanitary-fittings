jQuery(document).ready(function($){
	$('.woocommerce-product-gallery__image > a').attr('data-lightbox', 'woo-image');
	var woocommerce_form = $( '.woocommerce-cart form' );
	woocommerce_form.on('change', '.qty', function(){
		form = $(this).closest('form');

		// emulates button Update cart click
		$("<input type='hidden' name='update_cart' id='update_cart' value='1'>").appendTo(form);

		// get the form data before disable button...
		formData = form.serialize();

		// disable update cart and proceed to checkout buttons before send ajax request
		$("input[name='update_cart']").val('Updating…').prop('disabled', true);
		$("a.checkout-button.wc-forward").addClass('disabled').html('Updating…');
		$(form).addClass('blockUI blockOverlay')

		// update cart via ajax
		$.post( form.attr('action'), formData, function(resp) {
			// get updated data on response cart
			var shop_table = $('table.shop_table.cart', resp).html();
			var cart_totals = $('.cart-collaterals .cart_totals', resp).html();

			// replace current data by updated data
			$('.woocommerce-cart table.shop_table.cart')
				.html(shop_table)
				.find('.qty')
				//.before('<input type="button" value="-" class="minus">')
				//.after('<input type="button" value="+" class="plus">');
			$('.woocommerce-cart .cart-collaterals .cart_totals').html(cart_totals);
			$(form).removeClass('blockUI blockOverlay')
		});
	}).on('click','.quantity .qty-decrease', function() {
		var current = $(this).next('.qty').val();
		current--;
		$(this).next('.qty').val(current).trigger('change');
	}).on('click','.quantity .qty-increase', function() {
		var current = $(this).prev('.qty').val();
		current++;
		$(this).prev('.qty').val(current).trigger('change');
	})

	$( '.woocommerce-cart' ).on( 'click', "a.checkout-button.wc-forward.disabled", function(e) {
		e.preventDefault();
	});

	var woocommerce_form_pdp = $( '.single-product form.cart' );
	woocommerce_form_pdp.on('click', '.quantity .qty-increase', function(){
		var current = $(this).prev('.qty').val();
		current++;
		$(this).prev('.qty').val(current);
	}).on('click', '.quantity .qty-decrease', function(){
		var current = $(this).next('.qty').val();
		current--;
		$(this).next('.qty').val(current);
	});
});
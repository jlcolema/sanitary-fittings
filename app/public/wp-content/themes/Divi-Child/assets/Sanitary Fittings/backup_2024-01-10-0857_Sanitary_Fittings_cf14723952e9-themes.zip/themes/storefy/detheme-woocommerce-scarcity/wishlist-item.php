<?php
/**
 * @author  Detheme
 * @package Woscarcity/Templates
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;


// Ensure visibility
if ( ! $product || ! $product->is_visible() ) {
	return;
}

?>
<td class="wishlist-action">
	<a class="remove-btn" href="<?php print esc_url(wooscarcity_get_wishlist_link($product->id, false));?>">×</a>
</td>
<td class="wishlist-image">
<div>
<?php
	woocommerce_template_loop_product_thumbnail();
?>
</div></td>
<td class="wishlist-product-name">
<?php printf( '<a href="%s">%s</a>', esc_url( $product->get_permalink() ),$product->get_title());?>	
</td>
<td class="wishlist-product-price"><?php woocommerce_template_loop_price();?></td>
<td class="wishlist-product-stock"><?php echo apply_filters( 'woocommerce_product_stock', $product->stock_status ); ?></td>
<td class="wishlist-product-add-to-cart"><?php	woocommerce_template_loop_add_to_cart(array('btn_label'=>esc_html( $product->single_add_to_cart_text())));?></td>

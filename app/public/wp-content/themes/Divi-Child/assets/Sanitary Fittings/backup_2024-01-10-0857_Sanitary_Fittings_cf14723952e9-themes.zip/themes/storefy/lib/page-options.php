<?php 
defined('ABSPATH') or die();

add_filter('detheme_options_config','storefy_theme_configuration');

function storefy_theme_configuration($storefy_config){

	$storefy_config['body_background']=$storefy_config['body_tag']=$storefy_config['body_bg_class']="";
	$post_id=get_the_id();

	if(!in_array($post_type=get_post_type(),storefy_post_use_sidebar_layout()) && isset($storefy_config['layout_'.$post_type])){
		$storefy_config['layout']=$storefy_config['layout_'.$post_type];
	}

	$sidebars=wp_get_sidebars_widgets();

	if(!isset($sidebars['storefy-scrolling-sidebar']) || !count($sidebars['storefy-scrolling-sidebar'])){
	    $storefy_config['dt_scrollingsidebar_on']=false;
	}

	if(is_front_page()){

		$post_id = get_option('page_on_front');

		if(function_exists('is_shop') && is_shop()){
			 $post_id=get_option( 'woocommerce_shop_page_id');

		}
		if($post_id){

			 $storefy_config['page-title']=get_the_title($post_id);
			
			if(get_post_meta( $post_id,'_hide_loader', true )){
				$storefy_config['page_loader']=false;
			}


			if($hide_title=get_post_meta( $post_id, '_hide_title', true )){
				$storefy_config['dt-show-title-page']=false;
			}

			$page_background=get_post_meta( $post_id,'_page_background', true );
			$background_style=get_post_meta( $post_id, '_background_style', true );
			$page_background_color=get_post_meta( $post_id,'_page_background_color', true );

			$background=detheme_getBackgroundStyle($page_background,$background_style,$page_background_color);

			if($background){

				$storefy_config['body_background']="body{".$background['css']."}";
				$storefy_config['body_tag']=($background_style!='default')?esc_attr($background['body']):
				($storefy_config['body_background_style']=='parallax'|| $storefy_config['body_background_style']=='parallax_all')?" data-speed=\"3\" data-type=\"background\" ":"";
				$storefy_config['body_bg_class'] = $background['class'];

			}

		}
		else{
			 //$storefy_config['page-title']=get_bloginfo('name');
		}



	}
	elseif(is_page()){

		$storefy_config['page-title']=the_title('','',false);

		if(get_post_meta( $post_id,'_hide_loader', true )){
			$storefy_config['page_loader']=false;
		}


		if($hide_title=get_post_meta( $post_id, '_hide_title', true )){
			$storefy_config['dt-show-title-page']=false;
		}

		$page_background=get_post_meta( $post_id,'_page_background', true );
		$background_style=get_post_meta( $post_id, '_background_style', true );
		$page_background_color=get_post_meta( $post_id,'_page_background_color', true );

		$background=detheme_getBackgroundStyle($page_background,$background_style,$page_background_color);

		if($background){

			$storefy_config['body_background']="body{".$background['css']."}";
			$storefy_config['body_tag']=($background_style!='default')?esc_attr($background['body']):
			($storefy_config['body_background_style']=='parallax'|| $storefy_config['body_background_style']=='parallax_all')?" data-speed=\"3\" data-type=\"background\" ":"";
			$storefy_config['body_bg_class'] = $background['class'];
		}
	}
	elseif(is_category()){


		$storefy_config['page-title']=sprintf(esc_html__('Category : %s','storefy'), single_cat_title( ' ', false ));

	}
	elseif(is_archive()){
		if(is_tag()){
			$title=sprintf(esc_html__('Tag : %s','storefy'), single_tag_title( ' ', false ));
		}
		elseif(is_tax()){
			$title=single_tag_title( ' ', false );
		}
		elseif(function_exists('is_shop') && is_shop()){

			if (!empty($storefy_config['dt-shop-title-page'])) {
				$title = $storefy_config['dt-shop-title-page'];
			} else {
				$title=woocommerce_page_title(false);	
			}


			$post_id=get_option( 'woocommerce_shop_page_id');

			if(get_post_meta( $post_id,'_hide_loader', true )){
				$storefy_config['page_loader']=false;
			}


			if($hide_title=get_post_meta( $post_id, '_hide_title', true )){
				$storefy_config['dt-show-title-page']=false;
				add_filter('woocommerce_show_page_title',create_function('','return false;'));
			}

			$page_background=get_post_meta( $post_id,'_page_background', true );
			$background_style=get_post_meta( $post_id, '_background_style', true );
			$page_background_color=get_post_meta( $post_id,'_page_background_color', true );

			$background=detheme_getBackgroundStyle($page_background,$background_style,$page_background_color);

			if($background){

				$storefy_config['body_background']="body{".$background['css']."}";
				$storefy_config['body_tag']=($background_style!='default')?esc_attr($background['body']):
				($storefy_config['body_background_style']=='parallax'|| $storefy_config['body_background_style']=='parallax_all')?" data-speed=\"3\" data-type=\"background\" ":"";
				$storefy_config['body_bg_class'] = $background['class'];

			}

		}	
		else{

			$title=sprintf((is_rtl()?esc_html__('%s : Archive','storefy'):esc_html__('Archive : %s','storefy')), single_month_title( ' ', false ));

		}

		$storefy_config['page-title']=$title;

	}
	elseif(is_search()){
			$storefy_config['page-title']=esc_html__('Search','storefy');
	}
	elseif(is_home()){
		 $post_id=get_option( 'page_for_posts');
		 $title=get_the_title($post_id);
		 $storefy_config['page-title']=$title;

		if(get_post_meta( $post_id,'_hide_loader', true )){
			$storefy_config['page_loader']=false;
		}


		if($hide_title=get_post_meta( $post_id, '_hide_title', true )){
			$storefy_config['dt-show-title-page']=false;
		}


		$page_background=get_post_meta( $post_id,'_page_background', true );
		$background_style=get_post_meta( $post_id, '_background_style', true );
		$page_background_color=get_post_meta( $post_id,'_page_background_color', true );

		$background=detheme_getBackgroundStyle($page_background,$background_style,$page_background_color);

		if($background){

			$storefy_config['body_background']="body{".$background['css']."}";
			$storefy_config['body_tag']=($background_style!='default')?esc_attr($background['body']):
			($storefy_config['body_background_style']=='parallax'|| $storefy_config['body_background_style']=='parallax_all')?" data-speed=\"3\" data-type=\"background\" ":"";
			$storefy_config['body_bg_class'] = $background['class'];

		}
	}
	elseif(is_404()){
		$page_background=get_post_meta( $post_id,'_page_background', true );
		$background_style=get_post_meta( $post_id, '_background_style', true );
		$page_background_color=get_post_meta( $post_id,'_page_background_color', true );

		$background=detheme_getBackgroundStyle($page_background,$background_style,$page_background_color);

		if($background){

			$storefy_config['body_background']="body{".$background['css']."}";
			$storefy_config['body_tag']=($background_style!='default')?esc_attr($background['body']):
			($storefy_config['body_background_style']=='parallax'|| $storefy_config['body_background_style']=='parallax_all')?" data-speed=\"3\" data-type=\"background\" ":"";
			$storefy_config['body_bg_class'] = $background['class'];

		}
	}
	elseif(function_exists('is_product')  && (is_product() || is_product_category())){

		$storefy_config['page-title']=isset($storefy_config['dt-shop-title-page'])?$storefy_config['dt-shop-title-page']:"";

	}
	else{


		$post_id=get_the_ID();
		$post_type=get_post_type();
		$storefy_config['page-title']=the_title('','',false);

		if($post_id && in_array($post_type, array_keys(get_detheme_page_attributes()))){

			$storefy_config['dt-show-title-page']=!get_post_meta( $post_id, '_hide_title', true ) && (isset($storefy_config[$post_type.'-title']) && (bool)$storefy_config[$post_type.'-title']);

			if(get_post_meta( $post_id,'_hide_loader', true )){
				$storefy_config['page_loader']=false;
			}

		}
	}



	return $storefy_config;
}


if(is_single()){
	storefy_set_post_views(get_the_ID()); 
}


function detheme_getBackgroundStyle($image_id="",$background_style="",$background_color=""){

	$featured_img_fullsize_url = wp_get_attachment_image_src( $image_id, 'full' );
	$css_background=$parallax=$backgroundclass="";

	if($featured_img_fullsize_url){

		$css_background="background-image:url('".esc_url($featured_img_fullsize_url[0])."') !important;";

		switch($background_style){
		    case'parallax':
		        //$parallax=" data-speed=\"3\" data-type=\"background\" ";
		        $backgroundclass="bg_parallax";
		        break;
		    case'parallax_all':
		        //$parallax=" data-speed=\"3\" data-type=\"background\" ";
		        $backgroundclass="bg_parallax_all";
		        break;
		    case'cover':
		        $parallax="";
		        $backgroundclass="bg_cover";
		        break;
		    case'cover_all':
		        $parallax="";
		        $backgroundclass="bg_cover_all";
		        break;
		    case'no-repeat':
		        $parallax="";
		        $backgroundclass="bg_no_repeat";
		        break;
		    case'repeat':
		        $parallax="";
		        $backgroundclass="bg_repeat";
		        break;
		    case'contain':
		        $parallax="";
		        $backgroundclass="bg_contain";
		        break;
		    case 'fixed':
		        $parallax="";
		        $backgroundclass="bg_fixed";
		        break;
		}

		//$css_background.=$backgroundclass;
	}

	if(!empty($background_color)){
		$css_background.="\n"."background-color:".esc_url($background_color)."!important;";
	}

	if(empty($css_background)) return false;

	return array('css'=>$css_background,'body'=>$parallax,'class'=>$backgroundclass);
}

function storefy_body_class( $classes ){

  $classes = ( array ) $classes ;

  $classes[] = 'dt_custom_body';
  $classes[] = esc_attr(get_storefy_option('body_bg_class'));

  if(is_storefy_home(get_post())){
    $classes[]="home";
  }


  if(get_storefy_option( 'boxed_layout_activate' , false)){
	  	$classes[] = "boxed" == get_storefy_option( 'boxed_layout_activate', false) ? "boxed" : "wide";

	  	if(get_storefy_option( 'boxed_layout_stretched', false) ){
		  	$classes[] = "stretched";
		}
  }

  if(get_storefy_option('dt-sticky-menu')){
		  	$classes[] = "menu-sticky";
  }

  return $classes;
}

add_filter( 'body_class', 'storefy_body_class' );


function storefy_post_class($classes=array(), $class="", $post_id=0){

	if(is_single()){
		$classes[]='blog';
		$classes[]='single-post';

		if( !(function_exists('is_product') && is_product())){
			$classes[]='content';
		}
	}

	return $classes;
}

add_filter( 'post_class', 'storefy_post_class');

?>
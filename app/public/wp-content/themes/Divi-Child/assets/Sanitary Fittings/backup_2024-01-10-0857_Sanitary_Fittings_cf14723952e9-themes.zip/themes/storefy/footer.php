<?php
defined('ABSPATH') or die();
/**
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 * @version 1.0
 */
?>
<?php 
do_action('storefy_before_footer_section');
//showfooterarea
if(get_storefy_option('showfooterarea')){
	get_footer('footerarea');
}
do_action('storefy_after_footer_section');
?>
</div>
<?php wp_footer(); ?>
</body>
</html>
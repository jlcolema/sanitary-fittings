<?php
/**
 *
 * @author  Detheme
 * @package Woscarcity/Templates
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product, $woocommerce_loop;

// Store loop count we're currently on
if ( empty( $woocommerce_loop['loop'] ) ) {
	$woocommerce_loop['loop'] = 0;
}

// Ensure visibility
if ( ! $product || ! $product->is_visible() ) {
	return;
}

// Increase loop count
$woocommerce_loop['loop']++;

// Extra post classes
$classes = array();
?>
<div <?php post_class( $classes ); ?>>
<a class="single_remove_from_compare_button" href="<?php print esc_url(wooscarcity_get_compare_link($product->id,false));?>">×</a>
<div class="compare-product-head">
<?php

	echo '<h3><a href="' . get_the_permalink() . '" class="woocommerce-compare-loop-link">'.get_the_title().'</a></h3>';
	woocommerce_template_loop_product_thumbnail();
	woocommerce_template_loop_rating();
	woocommerce_template_loop_price();
	woocommerce_template_loop_add_to_cart(array('btn_label'=>esc_html( $product->single_add_to_cart_text())));
?>
</div>
</div>

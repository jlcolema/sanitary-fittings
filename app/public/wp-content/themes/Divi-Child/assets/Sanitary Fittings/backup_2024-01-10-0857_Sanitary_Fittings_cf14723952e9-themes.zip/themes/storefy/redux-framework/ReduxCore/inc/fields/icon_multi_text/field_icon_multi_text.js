/* global redux_change */

(function($){
    "use strict";
    $.redux.icon_multi_text = $.group || {};
    $(document).ready(function () {
        $.redux.icon_multi_text();
    });

    $.redux.icon_multi_text = function(){
		$('.redux-icon-multi-text-remove').live('click', function() {
			redux_change($(this));
			$(this).prev('input[type="text"]').val('');
			$(this).parent().slideUp('medium', function(){
				$(this).remove();
			});
		});

/*		
		$('.redux-icon-multi-text-add').click(function(){
			var number = parseInt($(this).attr('data-add_number'));
			var id = $(this).attr('data-id');
			var name = $(this).attr('data-name');
			var oldnum=$('#'+id+' li').length;

			for (var i = 0; i < number; i++) {
				var new_input = $('#'+id+' li:last-child').clone(true);

				//new_input.find('.icon-selection-preview').remove();
				$('#'+id+' li:last-child').before(new_input);

				new_input.removeAttr('style');
				new_input.find('.regular-text,.icon-field').val('');
				new_input.find('.icon-field').val('fontellopicker-picture');
				new_input.find('.icon-field').attr('name' , name+'['+oldnum+'][icon]');
				new_input.find('.regular-text').each(function(){
					var labelName=$(this).data('field');
					$(this).attr('name', name+'['+(i+oldnum)+']['+labelName+']');
				});
			}

		});
*/

		$('.redux-icon-multi-text-add').click(function(){
			var number = parseInt($(this).attr('data-add_number'));
			var id = $(this).attr('data-id');
			var name = $(this).attr('data-name');
			
			var new_input = $('#'+id+' li:last-child').clone(true);

			//new_input.find('.icon-selection-preview').remove();
			$('#'+id+' li:last-child').removeAttr('style');
			new_input.insertBefore('#'+id+' li:last-child');
			//$('#'+id+' li:last-child').before(new_input);

			var oldnum=$('#'+id+' li').length;

			new_input.find('.regular-text,.icon-field').val('');
			new_input.find('.icon-field').val('fontellopicker-picture');
			new_input.find('.icon-field').attr('name' , name+'['+oldnum+'][icon]');
			new_input.find('.regular-text').each(function(){
				//console.log($(this));
				var labelName=$(this).data('field');
				$(this).attr('name', name+'['+oldnum+']['+labelName+']');
			});

			$('.input-group').remove();
			$('<span href="javascript:;" class="redux-icon-multi-text-edit"></span>').insertBefore('.redux-icon-multi-text-remove');
			//new_input.find('redux-icon-multi-text-remove').before('<span href="javascript:;" class="redux-icon-multi-text-edit"></span>');
		/*

			$('#'+id+' li .redux-icon-multi-text-remove').each(function(){
				$(this).before('<span href="javascript:;" class="redux-icon-multi-text-edit form-control"></span>');
			});
			$('.redux-icon-multi-text-remove').each(function(){
				console.log($(this).before('<span href="javascript:;" class="redux-icon-multi-text-edit form-control"></span>'));
			});
		*/
			//$('.redux-icon-multi-text-edit').remove();
			//$('.input-group').remove();
			//$('redux-icon-multi-text-remove').before

			var options={
	            icons:new Array('listicon-ok','listicon-ok-circled2','listicon-checked','listicon-check','listicon-check-empty','listicon-check-fat','simple-line-icon-user','simple-line-icon-people','simple-line-icon-user-female','simple-line-icon-user-follow','simple-line-icon-user-following','simple-line-icon-user-unfollow','simple-line-icon-login','simple-line-icon-logout','simple-line-icon-emotsmile','simple-line-icon-phone','simple-line-icon-call-end','simple-line-icon-call-in','simple-line-icon-call-out','simple-line-icon-map','simple-line-icon-location-pin','simple-line-icon-direction','simple-line-icon-directions','simple-line-icon-compass','simple-line-icon-layers','simple-line-icon-menu','simple-line-icon-list','simple-line-icon-options-vertical','simple-line-icon-options','simple-line-icon-arrow-down','simple-line-icon-arrow-left','simple-line-icon-arrow-right','simple-line-icon-arrow-up','simple-line-icon-arrow-up-circle','simple-line-icon-arrow-left-circle','simple-line-icon-arrow-right-circle','simple-line-icon-arrow-down-circle','simple-line-icon-check','simple-line-icon-clock','simple-line-icon-plus','simple-line-icon-minus','simple-line-icon-close','simple-line-icon-event','simple-line-icon-exclamation','simple-line-icon-organization','simple-line-icon-trophy','simple-line-icon-screen-smartphone','simple-line-icon-screen-desktop','simple-line-icon-plane','simple-line-icon-notebook','simple-line-icon-mustache','simple-line-icon-mouse','simple-line-icon-magnet','simple-line-icon-energy','simple-line-icon-disc','simple-line-icon-cursor','simple-line-icon-cursor-move','simple-line-icon-crop','simple-line-icon-chemistry','simple-line-icon-speedometer','simple-line-icon-shield','simple-line-icon-screen-tablet','simple-line-icon-magic-wand','simple-line-icon-hourglass','simple-line-icon-graduation','simple-line-icon-ghost','simple-line-icon-game-controller','simple-line-icon-fire','simple-line-icon-eyeglass','simple-line-icon-envelope-open','simple-line-icon-envelope-letter','simple-line-icon-bell','simple-line-icon-badge','simple-line-icon-anchor','simple-line-icon-wallet','simple-line-icon-vector','simple-line-icon-speech','simple-line-icon-puzzle','simple-line-icon-printer','simple-line-icon-present','simple-line-icon-playlist','simple-line-icon-pin','simple-line-icon-picture','simple-line-icon-handbag','simple-line-icon-globe-alt','simple-line-icon-globe','simple-line-icon-folder-alt','simple-line-icon-folder','simple-line-icon-film','simple-line-icon-feed','simple-line-icon-drop','simple-line-icon-drawer','simple-line-icon-docs','simple-line-icon-doc','simple-line-icon-diamond','simple-line-icon-cup','simple-line-icon-calculator','simple-line-icon-bubbles','simple-line-icon-briefcase','simple-line-icon-book-open','simple-line-icon-basket-loaded','simple-line-icon-basket','simple-line-icon-bag','simple-line-icon-action-undo','simple-line-icon-action-redo','simple-line-icon-wrench','simple-line-icon-umbrella','simple-line-icon-trash','simple-line-icon-tag','simple-line-icon-support','simple-line-icon-frame','simple-line-icon-size-fullscreen','simple-line-icon-size-actual','simple-line-icon-shuffle','simple-line-icon-share-alt','simple-line-icon-share','simple-line-icon-rocket','simple-line-icon-question','simple-line-icon-pie-chart','simple-line-icon-pencil','simple-line-icon-note','simple-line-icon-loop','simple-line-icon-home','simple-line-icon-grid','simple-line-icon-graph','simple-line-icon-microphone','simple-line-icon-music-tone-alt','simple-line-icon-music-tone','simple-line-icon-earphones-alt','simple-line-icon-earphones','simple-line-icon-equalizer','simple-line-icon-like','simple-line-icon-dislike','simple-line-icon-control-start','simple-line-icon-control-rewind','simple-line-icon-control-play','simple-line-icon-control-pause','simple-line-icon-control-forward','simple-line-icon-control-end','simple-line-icon-volume-1','simple-line-icon-volume-2','simple-line-icon-volume-off','simple-line-icon-calendar','simple-line-icon-bulb','simple-line-icon-chart','simple-line-icon-ban','simple-line-icon-bubble','simple-line-icon-camrecorder','simple-line-icon-camera','simple-line-icon-cloud-download','simple-line-icon-cloud-upload','simple-line-icon-envelope','simple-line-icon-eye','simple-line-icon-flag','simple-line-icon-heart','simple-line-icon-info','simple-line-icon-key','simple-line-icon-link','simple-line-icon-lock','simple-line-icon-lock-open','simple-line-icon-magnifier','simple-line-icon-magnifier-add','simple-line-icon-magnifier-remove','simple-line-icon-paper-clip','simple-line-icon-paper-plane','simple-line-icon-power','simple-line-icon-refresh','simple-line-icon-reload','simple-line-icon-settings','simple-line-icon-star','simple-line-icon-symbol-female','simple-line-icon-symbol-male','simple-line-icon-target','simple-line-icon-credit-card','simple-line-icon-paypal','simple-line-icon-social-tumblr','simple-line-icon-social-twitter','simple-line-icon-social-facebook','simple-line-icon-social-instagram','simple-line-icon-social-linkedin','simple-line-icon-social-pinterest','simple-line-icon-social-github','simple-line-icon-social-google','simple-line-icon-social-reddit','simple-line-icon-social-skype','simple-line-icon-social-dribbble','simple-line-icon-social-behance','simple-line-icon-social-foursqare','simple-line-icon-social-soundcloud','simple-line-icon-social-spotify','simple-line-icon-social-stumbleupon','simple-line-icon-social-youtube','simple-line-icon-social-dropbox','simple-line-icon-social-vkontakte','simple-line-icon-social-steam','icon-social-android8','icon-social-apple62','icon-social-behance10','icon-social-behance5','icon-social-behance6','icon-social-behance7','icon-social-blogger10','icon-social-blogger11','icon-social-blogger8','icon-social-blogger9','icon-social-deviantart10','icon-social-deviantart6','icon-social-deviantart7','icon-social-deviantart8','icon-social-dribbble13','icon-social-dribbble14','icon-social-ebay6','icon-social-facebook43','icon-social-facebook44','icon-social-facebook45','icon-social-facebook48','icon-social-flickr18','icon-social-flickr19','icon-social-flickr20','icon-social-gdrive','icon-social-google109','icon-social-google110','icon-social-google111','icon-social-google113','icon-social-instagram12','icon-social-instagram13','icon-social-instagram14','icon-social-instagram15','icon-social-linkedin20','icon-social-linkedin21','icon-social-linkedin22','icon-social-linkedin23','icon-social-path4','icon-social-path5','icon-social-paypal14','icon-social-pinterest26','icon-social-pinterest27','icon-social-pinterest28','icon-social-pinterest29','icon-social-share26','icon-social-skype19','icon-social-tumblr21','icon-social-twitter34','icon-social-twitter35','icon-social-twitter36','icon-social-twitter37','icon-social-twitter38','icon-social-twitter39','icon-social-twitter42','icon-social-vimeo21','icon-social-vimeo23','icon-social-wikipedia3','icon-social-windows33','icon-social-wordpress14','icon-social-wordpress15','icon-social-wordpress16','icon-social-youtube28','icon-social-youtube29','icon-social-youtube30','icon-social-youtube31','icon-social-youtube32','icon-social-youtube33','icon-social-youtube34','fontawesome-adjust4','fontawesome-align14','fontawesome-align15','fontawesome-align16','fontawesome-ambulance8','fontawesome-anchor16','fontawesome-android4','fontawesome-angle1','fontawesome-angle2','fontawesome-angle','fontawesome-apple22','fontawesome-archive15','fontawesome-arrow459','fontawesome-arrow460','fontawesome-arrow461','fontawesome-arrow462','fontawesome-arrow463','fontawesome-arrow464','fontawesome-arrow465','fontawesome-arrow466','fontawesome-arrow467','fontawesome-arrowhead5','fontawesome-arrowhead6','fontawesome-arrowheads','fontawesome-asterisk2','fontawesome-ban','fontawesome-bar10','fontawesome-barcode2','fontawesome-beaker2','fontawesome-beer9','fontawesome-bell13','fontawesome-bitbucket','fontawesome-bitcoin','fontawesome-bold14','fontawesome-book95','fontawesome-bookmark10','fontawesome-bookmark9','fontawesome-branch','fontawesome-briefcase11','fontawesome-bug6','fontawesome-building8','fontawesome-bull1','fontawesome-bullseye','fontawesome-calendar51','fontawesome-calendar52','fontawesome-camera46','fontawesome-camera47','fontawesome-caret4','fontawesome-caret5','fontawesome-caret6','fontawesome-center5','fontawesome-certificate6','fontawesome-check29','fontawesome-check30','fontawesome-check31','fontawesome-checkered2','fontawesome-chevron17','fontawesome-chevron18','fontawesome-chevron19','fontawesome-chevron20','fontawesome-chevron21','fontawesome-chevron22','fontawesome-chevron23','fontawesome-chevron24','fontawesome-circle33','fontawesome-circle34','fontawesome-circular56','fontawesome-cloud106','fontawesome-cloud107','fontawesome-code10','fontawesome-code11','fontawesome-coffee18','fontawesome-cog2','fontawesome-cogs3','fontawesome-collapse2','fontawesome-comment32','fontawesome-comment33','fontawesome-comments16','fontawesome-compass41','fontawesome-computer74','fontawesome-copy10','fontawesome-correct8','fontawesome-couple35','fontawesome-credit40','fontawesome-crop4','fontawesome-cross41','fontawesome-css3','fontawesome-curved8','fontawesome-cut18','fontawesome-dashboard2','fontawesome-delivery7','fontawesome-desktop14','fontawesome-dot','fontawesome-double28','fontawesome-double29','fontawesome-double30','fontawesome-double31','fontawesome-double32','fontawesome-download62','fontawesome-download63','fontawesome-dribbble4','fontawesome-dropbox13','fontawesome-earth17','fontawesome-edit24','fontawesome-eject14','fontawesome-envelope4','fontawesome-envelope5','fontawesome-euro29','fontawesome-exchange1','fontawesome-exclamation8','fontawesome-exclamation9','fontawesome-expand16','fontawesome-external1','fontawesome-external2','fontawesome-eye50','fontawesome-eye51','fontawesome-facebook25','fontawesome-facebook26','fontawesome-facetime','fontawesome-fast13','fontawesome-female76','fontawesome-fighter2','fontawesome-file27','fontawesome-file28','fontawesome-film28','fontawesome-filter10','fontawesome-finger6','fontawesome-fire16','fontawesome-fire17','fontawesome-flag28','fontawesome-flickr8','fontawesome-fluffy1','fontawesome-folder64','fontawesome-folder65','fontawesome-folder66','fontawesome-font2','fontawesome-font3','fontawesome-fork9','fontawesome-forward8','fontawesome-four29','fontawesome-foursquare5','fontawesome-frown','fontawesome-fullscreen4','fontawesome-gamepad1','fontawesome-gift49','fontawesome-github10','fontawesome-github11','fontawesome-github12','fontawesome-gittip','fontawesome-glass8','fontawesome-google25','fontawesome-google26','fontawesome-great11','fontawesome-group41','fontawesome-half14','fontawesome-hand34','fontawesome-hand35','fontawesome-hand40','fontawesome-hdd','fontawesome-heart74','fontawesome-heart75','fontawesome-horizontal9','fontawesome-hostpital','fontawesome-hotel17','fontawesome-html4','fontawesome-inbox12','fontawesome-increase','fontawesome-indent1','fontawesome-information34','fontawesome-information35','fontawesome-instagram3','fontawesome-italicize','fontawesome-keyboard13','fontawesome-left32','fontawesome-legal1','fontawesome-lemon3','fontawesome-leter','fontawesome-letter15','fontawesome-level','fontawesome-light45','fontawesome-lightning14','fontawesome-link15','fontawesome-linkedin10','fontawesome-linkedin9','fontawesome-linux3','fontawesome-list28','fontawesome-list29','fontawesome-list30','fontawesome-listing1','fontawesome-location28','fontawesome-lock24','fontawesome-long3','fontawesome-long4','fontawesome-long5','fontawesome-long6','fontawesome-magic7','fontawesome-male93','fontawesome-map25','fontawesome-maxcdn','fontawesome-medkit','fontawesome-meh','fontawesome-microphone27','fontawesome-microphone28','fontawesome-minus18','fontawesome-minus19','fontawesome-minus20','fontawesome-minus21','fontawesome-minus22','fontawesome-mobile29','fontawesome-money10','fontawesome-moon18','fontawesome-move14','fontawesome-music66','fontawesome-music67','fontawesome-musical32','fontawesome-nine10','fontawesome-numbered4','fontawesome-ok2','fontawesome-ok3','fontawesome-open94','fontawesome-open95','fontawesome-open96','fontawesome-open97','fontawesome-paper47','fontawesome-paper48','fontawesome-paste2','fontawesome-pause14','fontawesome-pencil30','fontawesome-photo33','fontawesome-picture13','fontawesome-pinterest12','fontawesome-pinterest13','fontawesome-plane12','fontawesome-plant16','fontawesome-play39','fontawesome-play40','fontawesome-play41','fontawesome-play42','fontawesome-plus25','fontawesome-plus26','fontawesome-plus27','fontawesome-power27','fontawesome-printing1','fontawesome-puzzle12','fontawesome-qr2','fontawesome-question22','fontawesome-question23','fontawesome-quote2','fontawesome-reduced','fontawesome-refresh36','fontawesome-refresh37','fontawesome-remove10','fontawesome-remove11','fontawesome-renren','fontawesome-reorder','fontawesome-reply8','fontawesome-reply9','fontawesome-resize4','fontawesome-retweet2','fontawesome-rewind25','fontawesome-right28','fontawesome-right29','fontawesome-road16','fontawesome-rounded30','fontawesome-rss25','fontawesome-rss26','fontawesome-rupee1','fontawesome-save8','fontawesome-screenshot','fontawesome-search19','fontawesome-share13','fontawesome-share14','fontawesome-share15','fontawesome-shield36','fontawesome-shopping69','fontawesome-sign3','fontawesome-sign4','fontawesome-signal22','fontawesome-sitemap1','fontawesome-skype9','fontawesome-small143','fontawesome-small144','fontawesome-smile','fontawesome-sort10','fontawesome-sort11','fontawesome-sort12','fontawesome-sort13','fontawesome-sort14','fontawesome-sort6','fontawesome-sort7','fontawesome-sort8','fontawesome-sort9','fontawesome-speech59','fontawesome-spinner8','fontawesome-square62','fontawesome-stack10','fontawesome-stack11','fontawesome-star60','fontawesome-star61','fontawesome-star62','fontawesome-step1','fontawesome-step','fontawesome-stethoscope6','fontawesome-strikethrough1','fontawesome-suitcase24','fontawesome-sun32','fontawesome-superscript','fontawesome-table21','fontawesome-tag32','fontawesome-tags2','fontawesome-tasks','fontawesome-telephone65','fontawesome-telephone66','fontawesome-terminal7','fontawesome-text59','fontawesome-text60','fontawesome-text61','fontawesome-text62','fontawesome-thin24','fontawesome-thumbs25','fontawesome-thumbs26','fontawesome-thumbs27','fontawesome-thumbs28','fontawesome-ticket6','fontawesome-time7','fontawesome-tint','fontawesome-trash29','fontawesome-trello','fontawesome-trophy3','fontawesome-tumblr10','fontawesome-tumblr11','fontawesome-turkish1','fontawesome-twitter15','fontawesome-twitter16','fontawesome-two121','fontawesome-u1','fontawesome-umbrella16','fontawesome-underline2','fontawesome-undo5','fontawesome-unlink','fontawesome-unlock3','fontawesome-upload39','fontawesome-upload40','fontawesome-usd','fontawesome-user77','fontawesome-user78','fontawesome-vertical5','fontawesome-vertical6','fontawesome-video91','fontawesome-vimeo10','fontawesome-vintage27','fontawesome-vk','fontawesome-volume28','fontawesome-volume29','fontawesome-warning18','fontawesome-weibo','fontawesome-wheelchair2','fontawesome-white66','fontawesome-windows20','fontawesome-x21','fontawesome-xing4','fontawesome-xing5','fontawesome-yen18','fontawesome-youtube13','fontawesome-youtube14','fontawesome-youtube15','fontawesome-zoom27','fontawesome-zoom28'),
	            onUpdate:function(e){
	                var par=this.closest('li'),fieldinput=par.find('.icon-field'),preview=par.find('.icon-selection-preview i');
	                fieldinput.val(e);
	                if(!preview.length){
	                    preview=$('<i/>');
	                    preview.prependTo(par);
	                    preview.wrap('<div class="icon-selection-preview"></div>');

	                }
	                preview.removeClass().addClass(e);
	            }
	        };

	        try{
				//new_input.find('.redux-icon-multi-text-edit').iconPicker(options);
				//$("#<?php print $this->field['id'];?>-ul li .redux-icon-multi-text-edit").iconPicker(options);
	        	$('#'+id+' li .redux-icon-multi-text-edit').iconPicker(options);
	        	//new_input.find('.redux-icon-multi-text-edit').iconPicker(options);
	        }
	        catch(err){
	        }



		}); //$('.redux-icon-multi-text-add').click

    };
})(jQuery);
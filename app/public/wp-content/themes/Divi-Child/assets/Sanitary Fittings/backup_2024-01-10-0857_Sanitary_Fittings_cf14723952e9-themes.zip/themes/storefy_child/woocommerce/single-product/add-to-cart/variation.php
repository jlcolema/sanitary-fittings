<?php
/**
 * Single variation display
 *
 * This is a javascript-based template for single variations (see https://codex.wordpress.org/Javascript_Reference/wp.template).
 * The values will be dynamically replaced after selecting attributes.
 *
 * @see 	https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.5.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;
?>


<script type='text/javascript'>
function ShowMore()
{
$('#view_more_section').toggle();
$('#view_more_button').toggle();
$('#view_less_button').toggle(); 
//begin
$( ".more-values" ).each(function( index ) {
var custom_attribute_value = $(this).text();
if(custom_attribute_value=='')
{  				
	$(this).closest('.spec-row').hide();
} 
});
//end
//begin
$( ".drawing_url" ).each(function( index ) {
    var custom_attribute_href = $(this).attr("href");
	if(custom_attribute_href==''){
    	$(this).closest('.spec-row').hide();
	}
	if(custom_attribute_href.includes('request')){
	    $(this).text("Request Drawing");
	}
});
//end
}
function ShowLess()
{
$('#view_more_section').toggle();
$('#view_more_button').toggle();
$('#view_less_button').toggle();    
}
</script>

<script type="text/template" id="tmpl-variation-template">



<div class="spec-row"></div>
<div class="spec-row" style="border-bottom:0px;">
<div class="spec-name">Description</div>
<div class="spec-value">{{{ data.variation.variation_description }}}</div>
</div>
<div class="spec-row" style="border-bottom:0px;">
<div class="spec-name">SKU</div>
<div class="spec-value"><span itemprop="sku">{{{ data.variation.sku }}}</span></div>
</div>

<div class="spec-row">
<div class="spec-name">Availability</div>
<div class="spec-value" style="color:#f78e1e;">{{{ data.variation.text_field }}}</div>
</div>

<div id="view_more_section">
	
<div class="spec-row">
<div class="spec-name">Sanitary Size</div>
<div class="spec-value more-values" style="color:#000000;">{{{ data.variation.sanitary_size }}}</div>
</div>
<div class="spec-row">
<div class="spec-name">For Hose Id</div>
<div class="spec-value more-values" style="color:#000000;">{{{ data.variation.for_hose_id }}}</div>
</div>
<div class="spec-row">
<div class="spec-name">Flange OD</div>
<div class="spec-value more-values" style="color:#000000;">{{{ data.variation.flange_od }}}</div>
</div>
<div class="spec-row">
<div class="spec-name">Tube ID</div>
<div class="spec-value more-values" style="color:#000000;">{{{ data.variation.tube_id }}}</div>
</div>
<div class="spec-row">
<div class="spec-name">Wall Thickness</div>
<div class="spec-value more-values" style="color:#000000;">{{{ data.variation.wall_thickness }}}</div>
</div>
<div class="spec-row">
<div class="spec-name">Length</div>
<div class="spec-value more-values" style="color:#000000;">{{{ data.variation.pipe_size_length }}}</div>
</div>
<div class="spec-row" style="border-bottom:0px;">
<div class="spec-name">Weight</div>
<div class="spec-value more-values" style="color:#000000;">{{{ data.variation.weight }}} lbs.</div>
</div>
<div class="spec-row">
<div class="spec-name">Temp. Rating</div>
<div class="spec-value more-values" style="color:#000000;">{{{ data.variation.temperature_rating }}}</div>
</div>
<div class="spec-row">
<div class="spec-name">Pressure Rating</div>
<div class="spec-value more-values" style="color:#000000;">{{{ data.variation.pressure_rating }}}</div>
</div>
<div class="spec-row">
<div class="spec-name">Material</div>
<div class="spec-value more-values"  style="color:#000000;">{{{ data.variation.material }}}</div>
</div>
<div class="spec-row">
<div class="spec-name">Surface Finish</div>
<div class="spec-value more-values"  style="color:#000000;">{{{ data.variation.surface_finish }}}</div>
</div>
<div class="spec-row">
<div class="spec-name">Specification</div>
<div class="spec-value more-values"  style="color:#000000;">{{{ data.variation.specification }}}</div>
</div>
<div class="spec-row">
<div class="spec-name">Certification</div>
<div class="spec-value more-values"  style="color:#000000;">{{{ data.variation.certification }}}</div>
</div>
<div class="spec-row">
<div class="spec-name">Line Drawing</div>
<div class="spec-value more-values" style="color:#f78e1e;"><a class="drawing_url" href="{{{ data.variation.drawing_url }}}" target="_blank" onclick="gtag('event', 'PDF', {'event_category' : 'Download','event_label' : '{{{ data.variation.sku }}}'});">Download</a></div>
</div>
</div>
<a id="view_more_button" style="font-size:16px;" onclick="ShowMore();gtag('event', 'ViewMore', {'event_category' : 'View More Details','event_label' : '{{{ data.variation.sku }}}'});">View More Details</a>
<a id="view_less_button" style="display:none;font-size:16px;" onclick="ShowLess();">View Less Details</a>

	
	<div class="woocommerce-variation-price">
		{{{ data.variation.price_html }}}
	</div>

	<div class="woocommerce-variation-availability">
		{{{ data.variation.availability_html }}}
	</div>
	

</script>



<script type="text/template" id="tmpl-unavailable-variation-template">
	<p><?php _e( 'Please call for pricing and availability.', 'woocommerce' ); ?></p>
</script>
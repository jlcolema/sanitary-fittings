<?php
/**
 *
 * @author  Detheme
 * @package Woscarcity/Templates
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div class="loop-product-countdown">
<span class="countdown-label">
	<?php esc_html_e('This Sale Product Ends in','storefy');?>
</span>
<div class="wooscarcity loop-sale-countdown <?php print current_action();?>"><div id="countdown_<?php print esc_html($product_id);?>" class="wooscarcity-countdown" data-compact="<?php print $is_compact ? "true":"false";?>" data-until="<?php print esc_html($until);?>"></div></div>
</div>
<?php
defined('ABSPATH') or die();
/**
 * Display woocommerce product search result 
 *
 * Used for search.
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */
global $product;

// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>
<div class="woocommerce product-result">
<ul class="products">
<li <?php post_class(); ?>>
<?php do_action( 'storefy_woocommerce_before_shop_loop_item' );?>
<div class="product-loop-container">
<div class="before-product-loop-item">	
<?php
	storefy_woocommerce_template_loop_product_thumbnail();
?>
</div>
<div class="after-product-loop-item">
	<div class="after-product-loop-item-left">
<?php 

	woocommerce_template_loop_product_link_open();
	woocommerce_template_loop_product_title();
	woocommerce_template_loop_product_link_close();
?>
	<div class="blog-post-type" style="display:none;"><?php esc_html_e('product','Storefy');?></div>
<?php	storefy_woocommerce_template_loop_excerpt();
?>
	</div>
	<div class="after-product-loop-item-right">
<?php

	storefy_wooscarcity_load_loop_sale_countdown();

	woocommerce_template_loop_price();
	storefy_woocommerce_template_loop_add_to_cart(true);

	storefy_woocommerce_loop_stock_get_availability();
	storefy_woocommerce_template_loop_action_button();
	?>
	</div>
</div>
</div>
<?php do_action( 'storefy_woocommerce_after_shop_loop_item' );?>
</li>
</ul>
</div>
<?php
/**
 * @author  Detheme
 * @package Woscarcity/Templates
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div class="wooscarcity woocommerce">
<?php        if ( $products->have_posts() ) : 

$product_id_keys=array();

$rows=array(
    'product-title'=>array(
        'name'=>'product-title',
        'title'=>esc_html__('Products','wooscarcity'),
        'columns'=>array()
        ),
    'product-description'=>array(
        'name'=>'product-description',
        'title'=>esc_html__('Description','wooscarcity'),
        'columns'=>array()
        ),
    'product-availability'=>array(
        'name'=>'product-availability',
        'title'=>esc_html__('Availability','wooscarcity'),
        'columns'=>array()
        ),
    'product-weight'=>array(
        'name'=>'product-weight',
        'title'=>esc_html__('Weight','woocommerce'),
        'columns'=>array()
        ),
    'product-dimensions'=>array(
        'name'=>'product-dimensions',
        'title'=>esc_html__('Dimensions','woocommerce'),
        'columns'=>array()
        )
    );

$row_attributes=array();


while ( $products->have_posts() ) {
    $products->the_post(); 
    $product_id= get_the_ID();

    $product_id_keys[$product_id]=$product_id;

    global $product;

    ob_start();
    wooscarcity_get_template_part( 'compare', 'item' );
    $rows['product-title']['columns'][$product_id]=ob_get_clean();

    ob_start();
    wooscarcity_get_template_part( 'compare', 'description' ); 
    $rows['product-description']['columns'][$product_id]=ob_get_clean();

    ob_start();
    wooscarcity_get_template_part( 'compare', 'stock' ); 
    $rows['product-availability']['columns'][$product_id]=ob_get_clean();

    if ( $product->enable_dimensions_display() ) {

        $rows['product-weight']['columns'][$product_id] = $product->has_weight() ? wc_format_localized_decimal( $product->get_weight() ) . ' ' . esc_attr( get_option( 'woocommerce_weight_unit' ) ) : "-"; 
        $rows['product-dimensions']['columns'][$product_id] = $product->has_dimensions() ? $product->get_dimensions() : "-"; 
    }
    else{
        $rows['product-weight']['columns'][$product_id] = "-"; 
        $rows['product-dimensions']['columns'][$product_id] = "-"; 
    }


    if($attributes = $product->get_attributes()){

        foreach ( $attributes as $attribute ) {



            if ( empty( $attribute['is_visible'] ) ||  ( $attribute['is_taxonomy'] && ! taxonomy_exists( $attribute['name'] )) || $attribute['name']=='product-sku' ) {
                continue;
            } else {

               if(!isset($row_attributes[$attribute['name']])){

                    $row_attributes[$attribute['name']]=array('title' => wc_attribute_label( $attribute['name'] ), 'columns' => array() );
                }

                if ( $attribute['is_taxonomy'] ) {
                    $values = wc_get_product_terms( $product->id, $attribute['name'], array( 'fields' => 'names' ) );
                    $row_attributes[$attribute['name']]['columns'][$product_id]=apply_filters( 'woocommerce_attribute', wpautop( wptexturize( implode( ', ', $values ) ) ), $attribute, $values );


                }
                else{

                    $values = array_map( 'trim', explode( WC_DELIMITER, $attribute['value'] ) );
                    $row_attributes[$attribute['name']]['columns'][$product_id]= apply_filters( 'woocommerce_attribute', wpautop( wptexturize( implode( ', ', $values ) ) ), $attribute, $values );
                }

            }

        }

    }
}
?>
            <?php do_action( "wooscarcity_shortcode_before_compare_products_loop" ); ?>
            <div class="table-responsive">
                <table class="compare-products">
                <?php foreach ($rows as $row) {?>
                    <tr class="<?php print sanitize_html_class($row['name']);?>-row">
                        <th><?php print esc_html($row['title']);?></th>
                        <?php 
                        if(isset($row['columns']) && count($row['columns'])):
                            foreach ($row['columns'] as $product_id => $product_column) {
                                print "<td>".$product_column."</td>";
                            }

                        endif;?>
                    </tr>
                <?php } ?>
                <?php if(count($row_attributes)):?>
                <?php foreach ($row_attributes as $attribute_key => $row_attribute) {?>
                    <tr class="<?php print sanitize_html_class($attribute_key);?>-row">
                        <th><?php print esc_html($row_attribute['title']);?></th>
                        <?php foreach ($product_id_keys as $product_id) {?>
                        <td><?php print isset($row_attribute['columns'][$product_id]) ? $row_attribute['columns'][$product_id] : '-'; ?></td>
                        <?php
                        }
                        ?> 
                    </tr>
                <?php }
                ?>
                <?php endif;?>
                    <?php do_action( "wooscarcity_shortcode_end_compare_products_loop", $products); ?>
                </table>
            </div>
            <?php do_action( "wooscarcity_shortcode_after_compare_products_loop" ); ?>
        <?php 
        woocommerce_reset_loop();
        wp_reset_postdata();
        
        else:
            wc_get_template( 'product-compare/compare-empty.php', compact('products','atts') , WOOSCARCITY_BASENAME."/" , WOOSCARCITY_DIR."/templates/");
        endif;
?>
</div>
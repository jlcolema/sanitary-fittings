<?php
/**
 * My Account page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/my-account.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

wc_print_notices();

/**
 * My Account navigation.
 * @since 2.6.0
* 
 */

/*do_action( 'woocommerce_account_navigation' ); 
*/

?>


<style type="text/css">
.my-a {width:100%; border:1px solid #c0c0c0; margin-bottom:20px;}
.my-a tr td {border:0px !important; text-align:center;}
</style>
<table class="my-a">
<tr>
<td>
<a href="https://sanitaryfittings.us/my-account/orders/">
<img src="https://sanitaryfittings.us/wp-content/uploads/2017/10/package-image.png" width="60" />
</a>
</td>
<td><a href="https://sanitaryfittings.us/my-account/edit-address/">
<img src="/wp-content/uploads/2017/10/address-icon.png" width="60" /></a></td>
<td><a href="https://sanitaryfittings.us/my-account/payment-methods/">
<div style="text-align:center;">
<img src="/wp-content/uploads/2017/10/payment-methods.png" width="60" />
</div></a></td>
<td><a href="https://sanitaryfittings.us/my-account/edit-account/">
<div style="text-align:center;">
<img src="/wp-content/uploads/2017/10/account-details.png" width="60" />
</div></a></td>
</tr>
<tr>
<td><a href="https://sanitaryfittings.us/my-account/orders/" class="ma-order">My Orders</a></td>
<td><a href="https://sanitaryfittings.us/my-account/edit-address/" class="ma-address">Addresses</a></td>
<td><a href="https://sanitaryfittings.us/my-account/payment-methods/" class="ma-payment">Payment Methods</a></td>
<td><a href="https://sanitaryfittings.us/my-account/edit-account/" class="ma-account">Account Details</a></td>
</tr>
</table>
<table width="100%">
<tr>
<td align="center" style="background:#1e73be;"><a href="<?php echo wp_logout_url(); ?>" style="color:#fff;font-weight:bold;font-size:16px;">Logout</a></td>
</tr>
</table>


<div class="woocommerce-MyAccount-content" style="width:100%">
	<?php
		/**
		 * My Account content.
		 * @since 2.6.0
		 */
		do_action( 'woocommerce_account_content' );
	?>
</div>
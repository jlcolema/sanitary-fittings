<?php
defined('ABSPATH') or die();
/**
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */
?>

<?php 
	$imageurl = "";

	/* Get Image from featured image */
	if (isset($post->ID)) {
		$thumb_id = get_post_thumbnail_id($post->ID);
		$featured_image = wp_get_attachment_image_src($thumb_id,'full',false); 
		if (isset($featured_image[0])) {
			$imageurl = $featured_image[0];
		}

		$alt_image = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);
	}
	
?>

<?php 
	if (!is_single()) : ?>

		<div class="container-fluid">
			<div class="row">
<?php
		if ($imageurl!="") {
?>		<div class="col-xs-12">	
			<a href="<?php echo esc_url(get_permalink()); ?>" title="<?php print esc_attr(get_the_title());?>"><img class="img-responsive blog_image" alt="<?php echo esc_attr($alt_image); ?>" src="<?php echo esc_url($imageurl); ?>" /></a>
		</div>
<?php 	}  ?>											
				<div class="col-xs-12">
					<?php get_template_part('pagetemplates/postinfo'); ?>
					<h2 class="blog-post-title"><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_title();?></a></h2>
					<?php get_template_part('pagetemplates/postinfotag'); ?>
					<?php 
						print get_the_excerpt();
					?>
				<?php get_template_part('pagetemplates/postmetabottom','masonry'); ?>
				</div>
			</div>
		</div>
<?php 
	endif; 
?>

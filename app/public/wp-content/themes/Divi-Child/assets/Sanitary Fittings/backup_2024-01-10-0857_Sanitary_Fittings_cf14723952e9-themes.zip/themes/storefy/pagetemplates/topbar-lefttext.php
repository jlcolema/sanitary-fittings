<?php
defined('ABSPATH') or die();
/**
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */

$text=function_exists('icl_t') ? icl_t('storefy', 'left-top-bar-text', get_storefy_option('dt-left-top-bar-text','')):get_storefy_option('dt-left-top-bar-text','');
?>
<div class="left-menu"><div class="topbar-text"><?php print (!empty($text))? do_shortcode($text):"";?></div></div>

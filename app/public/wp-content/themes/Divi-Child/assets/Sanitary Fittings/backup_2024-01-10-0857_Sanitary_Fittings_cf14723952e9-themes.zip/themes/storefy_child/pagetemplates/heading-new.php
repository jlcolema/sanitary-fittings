<?php
defined('ABSPATH') or die();
/**
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */
?>
<section class="heading">
  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <div class="heading-right">
          <?php
          $logo_img = get_storefy_option('dt-logo-image');
          $logo = isset($logo_img['url']) ? $logo_img['url'] : "";
          $logoContent="";
          if(!empty($logo)){
            $alt_image = isset($logo_img['id']) ? get_post_meta($logo_img['id'], '_wp_attachment_image_alt', true) : "";
            $logoContent='<div class="logo-container hidden-xs"><a class="header-logo" href="'.esc_url(home_url('/')).'"><img width="260" height="60" src="'.esc_url(storefy_maybe_ssl_url($logo)).'" alt="'.esc_attr($alt_image).'" /></a></div>';
        }
        else{
            $logo_text=get_storefy_option('dt-logo-text');
            if(empty($logo_text)){
              $logo_text=get_bloginfo('name','raw');
          }
          $blogdescription=get_bloginfo('description','raw');
          $logoContent='<div class="logo-container"><a class="header-logo hidden-md hidden-sm hidden-xs" href="'.esc_url(home_url('/')).'">'.esc_html($logo_text).(!empty($blogdescription)? "<span>".esc_html($blogdescription)."</span>":"" ).'</a></div>';
      }
      print $logoContent;
      ?>
      <div style="display:flex" class="hidden-xs hidden-sm quick-ph">
        <?php vi_load_vc_nav_buttons();?> 
    </div>
    <div class="heading-search mobile-home hidden-md">
        <form method="get" class="heading-search-form" style="margin-left:0px !important;" action="<?php print esc_url( home_url( '/' ) );?>">
          <div class="form-group">
            <?php
            if(get_storefy_option('dt-post-type-search')){
              storefy_search_options();
          }
          ?>
          <input type="search" class="form-control search-field" placeholder="<?php esc_attr_e('Search sanitary fittings','storefy');?>" value="<?php print get_search_query();?>" name="s" title="<?php print esc_attr_x( 'Search for:', 'label','storefy' );?>" />
          <a href="javascript:void(0);" title="<?php echo esc_attr_e('Search','storefy'); ?>" id="storefy-search-link"><span class="icon-magnifier"></span></a>
          <input type="submit"  value="Search">
      </div>
      <input type="hidden" class="searchsubmit" value="<?php print esc_attr_x( 'Search', 'submit button', 'storefy' );?>" />
  </form>
</div>
</div>
</div>
</div>
</div>
</section>

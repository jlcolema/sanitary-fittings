<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.6.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}

$equal_height_type= isset($product->equal_height_type) ? $product->equal_height_type : 0; 
$equal_height_selector= isset($product->equal_height_id) ? $product->equal_height_id : ""; 

$equal_height_tag="";
if(!empty($equal_height_selector)){

	if($equal_height_type=='skip-grouped'){
		$equal_height_tag=' data-mh="'.esc_attr($equal_height_selector).'"';
	}
	elseif($equal_height_type=='skip-target'){
		$equal_height_tag=' data-equal-with="'.esc_attr($equal_height_selector).'"';
	}
}

?>
<li <?php post_class(); echo $equal_height_tag; ?> itemscope itemtype="http://schema.org/Product">
<?php do_action( 'storefy_woocommerce_before_shop_loop_item' );?>
<div class="product-loop-container">
<div class="before-product-loop-item">	
<?php

	storefy_woocommerce_template_loop_product_thumbnail();
	storefy_woocommerce_template_loop_add_to_cart();
?>
</div>
<div class="after-product-loop-item">
<?php 

	woocommerce_template_loop_product_link_open();
	woocommerce_template_loop_product_title();
	woocommerce_template_loop_product_link_close();
	woocommerce_template_loop_rating();

	storefy_wooscarcity_load_loop_sale_countdown();
	
	woocommerce_template_loop_price();
	storefy_woocommerce_loop_stock_get_availability();
	storefy_woocommerce_template_loop_action_button();

	?>
</div>
</div>
<?php do_action( 'storefy_woocommerce_after_shop_loop_item' );?>
</li>

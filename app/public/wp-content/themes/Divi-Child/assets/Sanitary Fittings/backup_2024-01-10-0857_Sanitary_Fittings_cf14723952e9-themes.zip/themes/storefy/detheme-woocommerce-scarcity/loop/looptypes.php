<?php
/**
 * 
  * @author  Detheme
 * @package Woscarcity/Templates
 * @version 1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<ul class="loop-view-type">
	<li class="loop-tool view-grid<?php print $loop_type=='grid' || empty($loop_type) ? " active":"";?>" data-view="grid"><i class="storefy-product-grid"></i></li>
	<li class="loop-tool view-table<?php print $loop_type=='table' ? " active":"";?>" data-view="table"><i class="storefy-product-list1"></i></li>
	<li class="loop-tool view-list<?php print $loop_type=='list' ? " active":"";?>" data-view="list"><i class="storefy-product-list2"></i></li>
</ul>
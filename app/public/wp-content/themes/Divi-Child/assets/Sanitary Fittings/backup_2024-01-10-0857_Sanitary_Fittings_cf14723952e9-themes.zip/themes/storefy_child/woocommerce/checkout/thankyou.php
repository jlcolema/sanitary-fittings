<?php
/**
 * Thankyou page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/thankyou.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<?php if(is_order_received_page()){?>
	<div class="woocommerce-message">
		Order complete.
	</div>
<?php }?>

<style>
h1.page-title{display:none;}
</style>

<div class="woocommerce-order">
	<div class="row">
		<div class="col-md-6 col-lg-6">
			<h2 class="page-title page-title-alt"><?php echo __('Thank you for your order'); ?></h2>
			<?php if ( $order ) : ?>

				<?php if ( $order->has_status( 'failed' ) ) : ?>

					<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed"><?php _e( 'Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.', 'woocommerce' ); ?></p>

					<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed-actions">
						<a href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>" class="button pay"><?php _e( 'Pay', 'woocommerce' ) ?></a>
						<?php if ( is_user_logged_in() ) : ?>
							<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="button pay"><?php _e( 'My account', 'woocommerce' ); ?></a>
						<?php endif; ?>
					</p>

				<?php else : ?>
					<h3 class="order-received-title"><?php echo __('Your order number is ');?> <span><?php echo $order->get_id();?></span></h3>
					<p><?php echo __('An email with your order information will be sent to the email address you provided during checkout. If you have any questions or need assistance, please <a href="'.get_bloginfo('home').'/contact-us">contact us.</a>');?></p>
					<p><?php echo __('We will send an email with your estimated delivery date as soon as possible.');?></p>
					<div class="row">
						<div class="col-md-6 col-lg-6">
							<div class="billing-address order-address">
								<h4><?php echo ('Billing Address');?></h4>
								<address>
								<?php
								echo $order->get_billing_first_name( );
								echo ' '.$order->get_billing_last_name( );
								echo '<br>'.$order->get_billing_company( );
								echo '<br>'.$order->get_billing_address_1( );
								if($order->get_billing_address_2( )) echo '<br>'.$order->get_billing_address_2( );
								echo '<br>'.$order->get_billing_city( );
								echo ', '.$order->get_billing_state( );
								echo ' '.$order->get_billing_postcode( );
								echo '<br>'.$order->get_billing_phone( );
								echo '<br>'.$order->get_billing_email( );
								?>
								</address>
							</div>
						</div>
						<div class="col-md-6 col-lg-6">
							<div class="shipping-address order-address">
								<?php if($order->get_shipping_first_name( )) echo '<h4>' . __('Shipping Address') . '</h4>'; ?>
								<address>
								<?php
								if($order->get_shipping_first_name( )) echo $order->get_shipping_first_name( );
								if($order->get_shipping_last_name( )) echo ' '.$order->get_shipping_last_name( );
								if($order->get_shipping_company( )) echo '<br>'.$order->get_shipping_company( );
								if($order->get_shipping_address_1( )) echo '<br>'.$order->get_shipping_address_1( );
								if($order->get_shipping_address_2( )) echo '<br>'.$order->get_shipping_address_2( );
								if($order->get_shipping_city( )) echo '<br>'.$order->get_shipping_city( );
								if($order->get_shipping_state( )) echo ', '.$order->get_shipping_state( );
								if($order->get_shipping_postcode( )) echo ' '.$order->get_shipping_postcode( );
								?>
								</address>
							</div>
						</div>
					</div>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<div class="col-md-6 col-lg-6">
			<?php if ( $order ) : ?>
				<?php if ( ! $order->has_status( 'failed' ) ) : ?>
					<div class="woocommerce-order-details">
						<?php do_action( 'woocommerce_thankyou', $order->get_id() )?>
					</div>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>


	<?php if ( $order ) : ?>

		<?php if ( $order->has_status( 'failed' ) ) : ?>

			<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed"><?php _e( 'Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.', 'woocommerce' ); ?></p>

			<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed-actions">
				<a href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>" class="button pay"><?php _e( 'Pay', 'woocommerce' ) ?></a>
				<?php if ( is_user_logged_in() ) : ?>
					<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="button pay"><?php _e( 'My account', 'woocommerce' ); ?></a>
				<?php endif; ?>
			</p>

		<?php else : ?>
		

				<?php //echo $order->get_formatted_order_total(); ?></strong>

				<?php if ( $order->get_payment_method_title() ) : ?>
						<?php //echo wp_kses_post( $order->get_payment_method_title() ); ?>
				<?php endif; ?>


		<?php endif; ?>

		
		<?php //; ?>

	<?php else : ?>

		<p class="woocommerce-notice woocommerce-notice--success woocommerce-thankyou-order-received"><?php echo apply_filters( 'woocommerce_thankyou_order_received_text', __( 'Thank you. Your order has been received.', 'woocommerce' ), null ); ?></p>

	<?php endif; ?>

</div>
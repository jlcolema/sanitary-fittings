<?php
defined('ABSPATH') or die();
/**
 * 404 page
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */
get_header();
?>
<div clss='content'>
<div class="nosidebar">
	<div class="container">
		<?php if (get_storefy_option('dt-404-page') && $post = get_post(get_storefy_option('dt-404-page'))) :
		if(get_storefy_option('dt-show-title-page')):?>
		<h1 class="page-title"><?php print wp_kses_data(get_storefy_option('page-title',''));?></h1>
		<?php endif;?>
		<div class="row">
			<div class="col-xs-12">
					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<div class="row">
						<div class="col-xs-12 col-sm-12">
							<div class="postcontent">
<?php
	print do_shortcode($post->post_content);	
?>
							</div>
						</div>
					</div>
					</article>
		</div>
		<?php else:?>
<div class="page-404-wrap">
<h2>404 ERROR</h2>
   <div class="page-404-subheading"><?php esc_html_e('Sorry, this page isn\'t available','storefy');?></div>
    <p><?php esc_html_e('The link you followed is probably broken, or the page has been removed','storefy');?></p>
    <div class="page-404-button"><a href="<?php print esc_url(home_url('/'));?>" class="round-ghost"><?php esc_html_e('BACK TO HOMEPAGE','storefy');?></a></div>
</div>
		<?php endif;?>

	</div><!-- .container -->
</div>
</div><!-- .page -->
</div>

<?php
get_footer();
?>
<?php
defined('ABSPATH') or die();
/**
 * The default template for displaying content: aside
 *
 *
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="row">
				<div class="col-xs-12">


<?php if (is_single()) : ?>
					<div class="postcontent">
					<?php get_template_part('pagetemplates/postinfo'); ?>

						<h2 class="blog-post-title"><?php the_title();?></h2>

						<?php get_template_part('pagetemplates/postinfotag'); ?>

						<?php the_content();

							wp_link_pages( storefy_get_link_pages_args() );
						?>

						<?php get_template_part('pagetemplates/postmetabottom_detail'); ?>
					</div>

					<?php get_template_part('pagetemplates/postaboutcomment'); ?>

<?php else :  ?>

					<?php get_template_part('pagetemplates/postinfo'); ?>
					<h2 class="blog-post-title"><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_title();?></a></h2>
					<?php get_template_part('pagetemplates/postinfotag'); ?>

					<div class="postcontent">
					<?php 
						print get_the_excerpt();
					?>
					</div>

					<?php get_template_part('pagetemplates/postmetabottom'); ?>
<?php endif; ?>
				</div> 
		</div>
</article>

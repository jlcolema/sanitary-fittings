<?php

defined('ABSPATH') or die();



require_once( get_template_directory().'/lib/tgm/class-tgm-plugin-activation.php');

add_action( 'tgmpa_register', 'storefy_register_required_plugins' );



if ( ! isset( $content_width ) ) $content_width = 2000;





function storefy_register_required_plugins() {



	$plugins = array(



		array(

			'name'     				=> esc_html('WPBakery Visual Composer','storefy'), 

			'slug'     				=> 'js_composer', 

			'source'   				=> 'http://detheme.com/repo/mnemonic/plugins/js_composer_5.0.1.zip',

			'required' 				=> true, 

			'version' 				=> '5.0.1',

		),

		array(

			'name'     				=> esc_html('Storefy Visual Composer Add On','storefy'),

			'slug'     				=> 'storefy-vc-addon', 

			'source'   				=> 'http://detheme.com/repo/storefy/plugins/storefy-vc-addon.zip',

			'required' 				=> false,

			'version' 				=> '1.0.2',

		),

		array(

			'name'     				=> esc_html('Detheme Megamenu Plugin','storefy'),

			'slug'     				=> 'dt-megamenu', 

			'source'   				=> esc_url('http://detheme.com/repo/storefy/plugins/dt-megamenu.zip'), 

			'required' 				=> false, 

		),

		array(

			'name'     				=> esc_html('Contact Form 7','storefy'),

			'slug'     				=> 'contact-form-7', 

			'required' 				=> false, 

		),

		array(

			'name'     				=> esc_html('WP Live Chat Support','storefy'),

			'slug'     				=> 'wp-live-chat-support', 

			'required' 				=> false, 

		),

		array(

			'name'     				=> esc_html('WooCommerce - excelling eCommerce','storefy'),

			'slug'     				=> 'woocommerce', 

			'required' 				=> true, 

		),

		array(

			'name'     				=> esc_html('Revolution Slider','storefy'),

			'slug'     				=> 'revslider',

			'source'   				=> 'http://detheme.com/repo/mnemonic/plugins/revslider_v5.3.1.5.zip',

			'required' 				=> true, 

		),

		array(

			'name'     				=> esc_html('Detheme WooCommerce Add-On','storefy'),

			'slug'     				=> 'detheme-woocommerce-scarcity', 

			'source'   				=> 'http://detheme.com/repo/storefy/plugins/detheme-woocommerce-scarcity.zip',

			'required' 				=> true,

		),

		array(

			'name'     				=> esc_html('Storefy Icon Font - Add-on','storefy'),

			'slug'     				=> 'storefy_theme_icons', 

			'source'   				=> esc_url('http://detheme.com/repo/storefy/plugins/storefy_theme_icons.zip'), 

			'required' 				=> false, 

		),

		array(

			'name'     				=> esc_html('Storefy Demo Installer','storefy'),

			'slug'     				=> 'storefy-demo', 

			'source'   				=> esc_url('http://detheme.com/repo/storefy/plugins/storefy-demo.zip'), 

			'required' 				=> false, 

		),

		);





	$config = array(

		'domain'       		=> 'storefy',         			

		'default_path' 		=> '',                         	

		'parent_slug' 		=> 'themes.php', 				

		'menu'         		=> 'install-required-plugins', 	

		'has_notices'      	=> true,                       	

		'is_automatic'    	=> false,					   	

		'message' 			=> ''							

	);



	tgmpa( $plugins, $config );



}



function storefy_startup() {



	global $storefy_revealData, $storefy_Scripts,$storefy_Style, $dt_el_id, $woocommerce_loop;



	$woocommerce_loop = array();

	$dt_el_id = 0;



	$storefy_revealData=array();

	$storefy_Scripts=array();

	$storefy_Style=array();



	$locale = get_locale();



	if((is_child_theme() && !load_textdomain( 'storefy', get_stylesheet_directory() . "/languages/{$locale}.mo")) || !is_child_theme()){

		load_theme_textdomain('storefy',get_template_directory()."/languages");

	}



	add_theme_support('post-thumbnails');

	add_theme_support( 'title-tag' );



	add_theme_support('menus');

	add_theme_support( 'post-formats', array( 'quote', 'video', 'audio', 'gallery', 'link' , 'image' , 'aside' ) );

	add_theme_support( 'automatic-feed-links' );

	add_theme_support( 'woocommerce' );





	register_nav_menus(array(

		'primary' => esc_html__('Top Navigation', 'storefy')

	));





	add_action('wp_head', 'storefy_load_preloader', 10000);

  	add_action('wp_head','storefy_og_generator',2);

	add_action('admin_head','storefy_load_admin_stylesheet');

  	add_action('wp_enqueue_scripts','storefy_define_var_script');



	add_action('wp_enqueue_scripts', 'storefy_enqueue_scripts', 999);



	add_action('wp_enqueue_scripts', 'storefy_print_inline_style', 999);

	//add_action('wp_footer','storefy_load_js_code',99996);

	add_action('wp_enqueue_scripts','storefy_load_js_code',999);

  	

  	add_action('wp_enqueue_scripts','storefy_load_custom_script',99997);

  	add_action('wp_enqueue_scripts','storefy_load_vc_custom_css_style',99999);

  	

	add_action('wp_footer','storefy_load_modal_content',99998);



	// Remove rsd_link action to make page valid HTML

	remove_action('wp_head','rsd_link');



} 



add_action('after_setup_theme','storefy_startup');



function storefy_load_vc_custom_css_style(){

	global $storefy_Style; 



	if(count($storefy_Style)){

		wp_add_inline_style('storefy-style', @implode("",$storefy_Style));

	}	

}





function storefy_load_custom_script(){

	global $storefy_Scripts;



	if(count($storefy_Scripts)){

		wp_add_inline_script('storefy-script', @implode("\n",$storefy_Scripts));

	}

}



function storefy_enqueue_scripts(){

	if(is_admin())

		return;

//wp_enqueue_style( "storefy-theme-style", get_template_directory_uri() . "/css/storefy-main.css");



wp_enqueue_style( "storefy-theme-style", get_template_directory_uri() . "/style.css?ver=6.1");

wp_enqueue_style( "storefy-bootstrap", get_template_directory_uri() . "/css/bootstrap.css");

wp_enqueue_style( "storefy-theme-glyph-icon", get_template_directory_uri() . "/css/glyph/glyph.css");

wp_enqueue_style( "storefy-theme-menuicon", get_template_directory_uri() . "/css/menuicon/flaticon.css");



	if(!defined('IFRAME_REQUEST')){



wp_enqueue_style('storefy-style', get_template_directory_uri() . '/css/storefy.css');



		if(is_rtl()){

			wp_enqueue_style('storefy-rtl-style', get_template_directory_uri() . '/css/storefy-rtl.css',array('storefy-style'));



		}

	}



	if(is_child_theme()){

		wp_enqueue_style('storefy-child-style', get_stylesheet_directory_uri() . '/style.css?ver=6.0');

	}



	$blog_id="";



	if ( is_multisite()){

		$blog_id="-site".get_current_blog_id();

	}



	wp_enqueue_style("storefy-custom-style",get_template_directory_uri() . '/css/customstyle'.$blog_id.'.css');

	wp_enqueue_style( 'styleable-select-style', get_template_directory_uri() . '/css/select-theme-default.css', array(), '0.4.0', 'all' );

	wp_enqueue_style( 'storefy-style-ie', get_template_directory_uri() . '/css/ie9.css', array());

	wp_style_add_data( 'storefy-style-ie', 'conditional', 'IE 9' );



	add_filter( "get_post_metadata",'storefy_check_vc_custom_row',1,3);



	if(function_exists('vc_set_as_theme')){



	    $assetPath=plugins_url( 'js_composer/assets/css','js_composer');



	    $front_css_file = version_compare(WPB_VC_VERSION,"4.2.3",'>=')?$assetPath.'/js_composer.css':$assetPath.'/js_composer_front.css';



	    $upload_dir = wp_upload_dir();



	    if(function_exists('vc_settings')){



	      if ( vc_settings()->get( 'use_custom' ) == '1' && is_file( $upload_dir['basedir'] . '/js_composer/js_composer_front_custom.css' ) ) {

	        $front_css_file = $upload_dir['baseurl'] . '/js_composer/js_composer_front_custom.css';

	      }

	    }

	    else{

	      if ( WPBakeryVisualComposerSettings::get('use_custom') == '1' && is_file( $upload_dir['basedir'] . '/js_composer/js_composer_front_custom.css' ) ) {

	        $front_css_file = $upload_dir['baseurl'] . '/js_composer/js_composer_front_custom.css';

	      }



	    }



	    wp_register_style( 'js_composer_front', $front_css_file, false, WPB_VC_VERSION, 'all' );

	    

	    if ( is_file( $upload_dir['basedir'] . '/js_composer/custom.css' ) ) {

	      wp_register_style( 'js_composer_custom_css', $upload_dir['baseurl'] . '/js_composer/custom.css', array(), WPB_VC_VERSION, 'screen' );

	    }



	    wp_enqueue_style('js_composer_front');

	    wp_enqueue_style('js_composer_custom_css');



	  }



    if (get_storefy_option('blog_type')=='masonry'){

		wp_enqueue_style( 'masonry-component', get_template_directory_uri() . '/css/masonry/component.css', array(), '1.0.0', 'all' );

	}



	$primaryFont=get_storefy_option('primary-font');



	if (isset($primaryFont['font-family']) && isset($primaryFont['google']) && $primaryFont['font-family']!='') {

		if (isset($primaryFont['google']) && $primaryFont['google']) {

			$fontfamily = $primaryFont['font-family'];

			$subsets = (!empty($primaryFont['subsets'])) ? $primaryFont['subsets']: '';

			

			wp_enqueue_style( sanitize_title($fontfamily) , esc_url(storefy_theme_slug_font_url($fontfamily,$subsets)));

		}	

	} 

	else {

		wp_enqueue_style("heboo", esc_url(storefy_theme_slug_font_url('IBM Plex Sans','')));

	}

	



	$secondaryFont=get_storefy_option('secondary-font');



	if (isset($secondaryFont['font-family']) && isset($secondaryFont['google']) && $secondaryFont['font-family']!='') {

		if ($secondaryFont['google']) {

			$fontfamily = $secondaryFont['font-family'];

			$subsets = (!empty($secondaryFont['subsets'])) ? $secondaryFont['subsets'] : '';



			wp_enqueue_style( sanitize_title($fontfamily), esc_url(storefy_theme_slug_font_url($fontfamily,$subsets)));



		}	

	} 

	else {

		wp_enqueue_style("heboo", esc_url(storefy_theme_slug_font_url('IBM Plex Sans','')));

	}

    

    

	$sectionFont=get_storefy_option('section-font');



	if (isset($sectionFont['font-family']) && isset($sectionFont['google']) && $sectionFont['font-family']!='') {



		if ($sectionFont['google']) {

			$fontfamily = $sectionFont['font-family'];

			$subsets = (!empty($sectionFont['subsets'])) ? $sectionFont['subsets'] : '';



			if (!empty($sectionFont['font-weight'])) {

				$fontweight = $sectionFont['font-weight'].','.$sectionFont['font-weight'].'italic';



				wp_enqueue_style( sanitize_title($fontfamily), esc_url(storefy_theme_slug_font_url($fontfamily,$subsets,$fontweight)));

			} else {

				wp_enqueue_style( sanitize_title($fontfamily), esc_url(storefy_theme_slug_font_url($fontfamily,$subsets)));

			}



		}	

	} 

	else {

		wp_enqueue_style("heboo", esc_url(storefy_theme_slug_font_url('IBM Plex Sans','')));

	}

	



	$tertiaryFont=get_storefy_option('tertiary-font');



	if (isset($tertiaryFont['font-family']) && isset($tertiaryFont['google']) && $tertiaryFont['font-family']!='') {

		if ($tertiaryFont['google']) {

			$fontfamily = $tertiaryFont['font-family'];

			$subsets = (!empty($tertiaryFont['subsets'])) ? $tertiaryFont['subsets'] : '';



			wp_enqueue_style( sanitize_title($fontfamily), esc_url(storefy_theme_slug_font_url($fontfamily,$subsets)));

		}	

	} 

	/*

	else {

		wp_enqueue_style("playfair-display-font", esc_url(storefy_theme_slug_font_url('Playfair Display','')));

	}

	*/





/* js script */



    $suffix       = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';



    wp_enqueue_script( 'modernizr' , get_template_directory_uri() . '/js/modernizr.js', array( ), '2.6.2', true );

    wp_enqueue_script( 'bootstrap' , get_template_directory_uri() . '/js/bootstrap.js', array( 'jquery' ), '3.0', true );

    wp_enqueue_script( 'storefy-script' , get_template_directory_uri() . '/js/myscript.js', array( 'jquery','bootstrap'), '1.0', true );



    $menu_title=get_storefy_option('header-left-menu-title');

	$legend_text= !empty($menu_title ) ? (function_exists('icl_t') ? icl_t('storefy', 'header-left-menu-title', $menu_title) : $menu_title ) : esc_html__('shop all categories','storefy');





	wp_localize_script( 'storefy-script', 'storefy_i18nLocale', array(

	  'search_filter'=> esc_html__('Search','storefy'),

	  'back_label_menu'=> esc_html__('Back','storefy'),

	  'other_label_menu'=> esc_html__('Other','storefy'),

	  'shop_legend_text'=> $legend_text,

	) );





    //wp_enqueue_script( 'styleable-select', get_template_directory_uri() . '/js/select'.$suffix.'.js', array(), '0.4.0', true );

//    wp_enqueue_script( 'styleable-select-exec' , get_template_directory_uri() . '/js/select.init.js', array('styleable-select'), '1.0.0', true );

    wp_enqueue_script( 'jquery.appear' , get_template_directory_uri() . '/js/jquery.appear'.$suffix.'.js', array(), '', true );

    wp_enqueue_script( 'jquery.counto' , get_template_directory_uri() . '/js/jquery.counto'.$suffix.'.js', array(), '', true );

	wp_enqueue_script( 'classie',get_template_directory_uri()."/js/classie.js",array(), '1.0', true);

	wp_enqueue_script( 'modal-effects',get_template_directory_uri()."/js/modal_effects.js",array(), '1.0', true);



	if (get_storefy_option('blog_type')=='masonry'){

		wp_enqueue_script( 'modernizr-custom' , get_template_directory_uri() . '/js/masonry/modernizr.custom.js', array(), '1.0', true );

		wp_enqueue_script( 'masonry-pkgd' , get_template_directory_uri() . '/js/masonry/masonry.pkgd.min.js', array(), '1.0', true );

		wp_enqueue_script( 'imagesloaded' , get_template_directory_uri() . '/js/masonry/imagesloaded.js', array(), '1.0', true );

		wp_enqueue_script( 'AnimOnScroll' , get_template_directory_uri() . '/js/masonry/AnimOnScroll.js', array(), '1.0', true );

		wp_enqueue_script( 'masonry-script' , get_template_directory_uri() . '/js/masonry/script.js', array(), '1.0', true );

	}

	if(get_post_type()=='dtcareer'){

			 wp_enqueue_script( 'storefy-career-reply' , get_template_directory_uri() . '/js/career.js', array( 'jquery' ), '3.0', true );

	}

	else{

		if ( is_singular() ) { 

			 wp_enqueue_script( 'storefy-comment-reply' , get_template_directory_uri() . '/js/comment-reply.min.js', array( 'jquery' ), '3.0', true );

		} 

	}



	if(function_exists('vc_set_as_theme')){

	    wp_enqueue_script( 'wpb_composer_front_js' );

	}





}



function storefy_define_var_script(){

	wp_add_inline_script('storefy-script', "var ajaxurl = '".admin_url('admin-ajax.php')."';var themecolor='".get_storefy_option('primary-color','#000000')."';",'before');

}



function storefy_load_modal_content(){



		global $storefy_revealData; 



		if(count($storefy_revealData)) { 

			print @implode("\n",$storefy_revealData);

			print "<div class=\"md-overlay\"></div>";

		}



}



function storefy_load_js_code(){

	if(get_storefy_option('js-code')){

		wp_add_inline_script('storefy-script', get_storefy_option('js-code'));

	}

}



function storefy_check_vc_custom_row($post=null,$object_id, $meta_key=''){

  if('_wpb_shortcodes_custom_css'==$meta_key){



    $meta_cache = wp_cache_get($object_id, 'post_meta');



    $prefooter_custom_css  = storefy_get_page_custom_css_by_ID(get_storefy_option('footerpage'),$object_id);

    $postfooter_custom_css = storefy_get_page_custom_css_by_ID(get_storefy_option('postfooterpage'),$object_id);

    $megamenu_custom_css = storefy_get_nav_megamenu_custom_css($object_id);



    if (isset($meta_cache['_wpb_shortcodes_custom_css'][0])) {

    	return $meta_cache['_wpb_shortcodes_custom_css'][0].$megamenu_custom_css.$prefooter_custom_css.$postfooter_custom_css;

    }

   }

}



function storefy_get_page_custom_css_by_slug($slug,$object_id) {

	if(!isset($slug) || empty($slug) ) return ''; 



	$post = storefy_get_post_by_slug($slug);



	if (!isset($post->ID)) return '';



	if ($object_id!=$post->ID) {

		$meta_cache  = get_post_meta($post->ID);	

	    return $meta_cache['_wpb_shortcodes_custom_css'][0];

	} else {

		return '';

	}

}



function storefy_get_page_custom_css_by_ID($post_id,$object_id) {

	if(!isset($post_id) || empty($post_id) ) return ''; 



	if ($object_id!=$post_id) {

		$meta_cache  = get_post_meta($post_id);	

	    return $meta_cache['_wpb_shortcodes_custom_css'][0];

	} else {

		return '';

	}

}



function storefy_get_nav_megamenu_custom_css($object_id) {

	$nav_menus = wp_get_nav_menus();

	$result = '';



	if ($nav_menus) {

		foreach ($nav_menus as $menu) {

			$menu_items = wp_get_nav_menu_items($menu->term_id);



			foreach ($menu_items as $menu_item) {

				if (isset($menu_item->megamenuContentPages) && !empty($menu_item->megamenuContentPages)) {

					$result .= storefy_get_page_custom_css_by_ID($menu_item->megamenuContentPages,$object_id);

				}



			}

		} //foreach ($nav_menus as $menu)

	} //if ($nav_menus)



	return $result;

}



function storefy_og_generator(){



	if(is_admin())

		return;



	if (!get_storefy_option('meta-og'))

		return;



	$ogimage = "";

	if (function_exists('wp_get_attachment_thumb_url')) {

		$ogimage = wp_get_attachment_thumb_url(get_post_thumbnail_id(get_the_ID())); 

	}



	print '<meta property="og:title" content="'.esc_attr(get_the_title()).'" />'."\n";

	print '<meta property="og:type" content="article"/>'."\n";

	print '<meta property="og:locale" content="'.get_locale().'" />'."\n";

	print '<meta property="og:site_name" content="'.esc_attr(get_bloginfo('name')).'"/>'."\n";

	print '<meta property="og:url" content="'.esc_url(get_permalink()).'" />'."\n";

	print '<meta property="og:description" content="'.esc_attr(str_replace( '[&hellip;]', '&hellip;', strip_tags( get_the_excerpt() ))).'" />'."\n";

	print '<meta property="og:image" content="'.esc_attr($ogimage).'" />'."\n";



}





function storefy_theme_slug_font_url($font_family,$subset,$font_weight='300,300italic,400,400italic,700,700italic') {

	$fonts_url = '';

	 

	/* Translators: If there are characters in your language that are not

	* supported by Open Sans, translate this to 'off'. Do not translate

	* into your own language.

	*/



	if ( !preg_match('/Open Sans/',$font_family )) {

		$font_families = array();

	 

		$font_families[] = $font_family.':'.$font_weight;

		 

		$query_args = array(

			'family' => urlencode( implode( '|', $font_families ) ),

			'subset' => urlencode( $subset ),

		);

		 

		$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );

	}

	 

	return esc_url_raw( $fonts_url );

} 



function storefy_print_inline_style(){



	if(is_admin() || in_array($GLOBALS['pagenow'], array('wp-login.php', 'wp-register.php')))

		return;





	$is_ssl=wp_http_supports( array( 'ssl' ));





	print "<style type=\"text/css\">\n";



	if(get_storefy_option('sandbox-mode')){

  		$customstyle=storefy_Style_compile(get_storefy_options(),"",false);



  		print $customstyle."\n";

  	}





	print get_storefy_option('body_background') ? get_storefy_option('body_background',''):"";



	print "</style>\n";



	/* favicon handle */



	$favicon=get_storefy_option('dt-favicon-image');



	if($favicon && isset($favicon['url']) && ''!=$favicon['url'] && !function_exists('wp_site_icon')){

		$favicon_url=$favicon['url'];

		print "<link rel=\"shortcut icon\" type=\"image/png\" href=\"".esc_url(storefy_maybe_ssl_url($favicon_url))."\">\n";

	}



}







function storefy_load_preloader(){



	if(!get_storefy_option('page_loader') || defined('IFRAME_REQUEST') || is_404() || (defined('DOING_AJAX') && DOING_AJAX) )

		return '';

?>

<script type="text/javascript">

jQuery(document).ready(function ($) {

	'use strict';

    $("body").queryLoader2({

        barColor: "#fff",

        backgroundColor: "none",

        percentage: false,

        barHeight: 0,

        completeAnimation: "fade",

        minimumTime: 500,

        onLoadComplete: function() { $('.modal_preloader').fadeOut(300,function () {$('.modal_preloader').remove();})}

    });

});

</script>

	<?php 

}



function storefy_load_admin_stylesheet(){

	wp_enqueue_style( 'detheme-admin',get_template_directory_uri() . '/lib/css/admin.css', array(), '', 'all' );

}



require_once( get_template_directory().'/lib/webicon.php'); // load detheme icon

require_once( get_template_directory().'/lib/options.php'); // load bootstrap stylesheet and scripts

require_once( get_template_directory().'/lib/custom_functions.php'); // load specific functions

require_once( get_template_directory().'/lib/mainmenu_walker.php'); 

require_once( get_template_directory().'/lib/metaboxes.php'); // load custom metaboxes

require_once( get_template_directory().'/lib/widgets.php'); // load custom widgets

require_once( get_template_directory().'/lib/updater.php'); // load easy update

require_once( get_template_directory().'/lib/fonts.php'); // load detheme font family





if (function_exists('set_vc_is_inline')) {

	set_vc_is_inline(true);

}



if(function_exists('vc_set_as_theme')){

	vc_set_as_theme(true);

}

/*metadata field to woocommerce rest API for orders.*/
add_filter( 'woocommerce_rest_prepare_shop_order_object', 'prefix_wc_rest_prepare_order_object', 10, 3 );
function prefix_wc_rest_prepare_order_object( $response, $object, $request ) {

    if( empty( $response->data ) )
        return $response;

    if ( metadata_exists( 'post', $object->get_id(), 'mtrs_required' ) ) {
        $mtrs_required = get_post_meta( $object->get_id() , 'mtrs_required', true );
    }

    $order = wc_get_order( $object->get_id() );
    if($order->get_customer_note()) {
        $order_note = $order->get_customer_note();
    }

    foreach($response->data['line_items'] as $key => $productItems) {
        $productID = $productItems['product_id'];
        $variationID = $productItems['variation_id'];

        if($variationID != 0) {
            if ( metadata_exists( 'post', $variationID, 'steel_no' ) ) {
                $steel_no = get_post_meta( $variationID , 'steel_no', true );
                if($steel_no) {
                    $response->data['line_items'][$key]['steel_no'] = $steel_no;
                }
            }
        }

    }

    if($mtrs_required) {
        $response->data['line_items'][$key]['mtrs_required'] = $mtrs_required;
    }

    if($order_note) {
        $response->data['line_items'][$key]['additional_order_note'] = $order_note;
    }

    return $response;
}





?>
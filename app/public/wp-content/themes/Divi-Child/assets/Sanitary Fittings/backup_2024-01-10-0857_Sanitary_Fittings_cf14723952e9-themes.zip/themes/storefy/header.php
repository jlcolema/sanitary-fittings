<?php
/**
 * @package WordPress
 * @subpackage Storefy
 * @since Storefy 1.0
*/
defined('ABSPATH') or die();
?>
<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8) ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<?php 
require_once( get_template_directory().'/lib/page-options.php'); ?>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php echo esc_url(bloginfo( 'pingback_url' )); ?>">
<?php wp_head(); ?>

</head>
<body <?php body_class(); print esc_attr(get_storefy_option('body_tag',''));?> data-speed="5" data-type="background">
<div class="paspartu_top"></div>
<div class="paspartu_left"></div>
<div class="paspartu_right"></div>
<div class="paspartu_bottom"></div>	
<div class="paspartu_inner">
<div id="top-bar">
	<div class="container">
		<div class="top-bar-container">
			<div class="left-menu"><div class="topbar-text">Welcome to Worldwide Storify Store</div></div>
			      <div class="right-menu">
      <div id="dt-topbar-menu-right" class="menu-right-menu-container"><ul id="menu-right-menu" class="topbar-menu"><li id="menu-item-340" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-340"><a href="http://storefy-demo.detheme.com/furniture/track-your-order/"><i class="simple-line-icon-location-pin"></i><span>Track Your Order</span></a></li>
<li id="menu-item-341" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-341"><a href="http://storefy-demo.detheme.com/furniture/my-account/"><i class="simple-line-icon-user"></i><span>My Account</span></a></li>
<li id="menu-item-342" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-342"><a href="#"><i class="simple-line-icon-earphones-alt"></i><span>Customer Care</span></a></li>
<li id="menu-item-343" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-343"><a href="#"><i class="simple-line-icon-globe"></i><span>Language</span></a></li>
</ul></div>      </div>
		</div>
	</div>
</div>
<?php get_template_part('pagetemplates/preloader'); ?>
<?php if(get_storefy_option('showtopbar',true)): 
	get_template_part('pagetemplates/top-bar');?>
<?php endif;?>

<?php get_template_part('pagetemplates/heading');?>

<section class="top-head">
<?php 
get_template_part('pagetemplates/main_navigation');
?>
</section>
<?php
storefy_breadcrumb();
?>	
